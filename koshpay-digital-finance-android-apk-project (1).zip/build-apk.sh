#!/usr/bin/env bash
set -e
echo "Building KoshPay Digital Finance Android APK..."
npm install
npm run build
rm -rf android
npx cap add android
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk ../koshpay-digital-finance-v1.0.0.apk
cd ..
echo "SUCCESS! APK created: koshpay-digital-finance-v1.0.0.apk"
