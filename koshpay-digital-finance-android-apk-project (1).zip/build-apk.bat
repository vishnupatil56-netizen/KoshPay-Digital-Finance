@echo off
echo ============================================
echo  KoshPay Digital Finance - Automatic APK Builder
echo ============================================
call npm install
if errorlevel 1 goto err
call npm run build
if errorlevel 1 goto err
if exist android rmdir /s /q android
call npx cap add android
if errorlevel 1 goto err
call npx cap sync android
if errorlevel 1 goto err
cd android
call gradlew.bat assembleDebug
if errorlevel 1 goto err
copy /Y app\build\outputs\apk\debug\app-debug.apk ..\koshpay-digital-finance-v1.0.0.apk
cd ..
echo.
echo SUCCESS! APK created: koshpay-digital-finance-v1.0.0.apk
pause
exit /b 0
:err
echo Build failed. Make sure Node.js, JDK 17, and Android SDK are installed.
pause
exit /b 1
