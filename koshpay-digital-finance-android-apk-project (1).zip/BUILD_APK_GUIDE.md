# KoshPay Digital Finance — Automatic Android APK Build Guide

**Package ID:** `com.koshpay.finance`  
**Version:** `1.0.0` (Build `1`)

## Option 1: Zero-Install Cloud APK Build (GitHub Actions — Automatic)
1. Upload the extracted folder to a GitHub repository.
2. GitHub Actions (`.github/workflows/build-apk.yml`) runs automatically on push (or open **Actions → Build Android APK → Run workflow**).
3. Download `koshpay-digital-finance-v1.0.0.apk` directly from **Artifacts** and install it on your Android phone.

## Option 2: 1-Click Local Automatic Script
**Prerequisites:** Node.js 18+, JDK 17, Android SDK (or Android Studio).
- **Windows:** Double-click `build-apk.bat`
- **Mac / Linux:** Run `chmod +x build-apk.sh && ./build-apk.sh`
This automatically compiles `koshpay-digital-finance-v1.0.0.apk` in the project root folder.

## Option 3: Instant Android Install (No APK Build Needed)
Open the live web app URL in **Google Chrome on Android**, tap **⋮ Menu → Install app / Add to Home screen**.
