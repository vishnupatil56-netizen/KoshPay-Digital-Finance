import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import {
  AppSettings,
  AuditLogEntry,
  BCAuction,
  BCCollection,
  BCGroup,
  BCPayout,
  EMIFrequency,
  EMIPayment,
  EMIScheduleItem,
  ExpenseRecord,
  FinanceDatabase,
  GroupEnrollment,
  InterestType,
  Language,
  LedgerEntry,
  LoanAccount,
  LoanApprovalStatus,
  LoanType,
  LuckyDrawCollection,
  LuckyDrawEntry,
  LuckyDrawGroup,
  Member,
  OtherIncomeRecord,
  PaymentMode,
  ReceiptData,
} from '../types/finance';
import { EMPTY_DATABASE, INITIAL_SEED_DATABASE } from '../data/seedData';
import { generateNextId, todayISO } from '../utils/formatters';
import { calculateLoanSchedule } from '../utils/loanCalculator';

const STORAGE_KEY = 'koshpay_finance_db_v2';
const LANG_KEY = 'koshpay_finance_lang_v2';

export interface ActionResult {
  ok: boolean;
  error?: string;
  receipt?: ReceiptData;
  id?: string;
}

interface DashboardSummary {
  totalAvailableBalance: number;
  totalCollection: number;
  totalPayout: number;
  totalLoanOutstanding: number;
  totalBCCollection: number;
  totalLDCollection: number;
  totalExpenses: number;
  pendingEMI: number;
  pendingMemberPayments: number;
  cashBalance: number;
  bankBalance: number;
  dailyCollection: number;
  monthlyCollection: number;
  profitAndLoss: number;
}

interface FinanceContextValue {
  db: FinanceDatabase;
  lang: Language;
  setLang: (lang: Language) => void;
  isLocked: boolean;
  unlockApp: (pin: string) => boolean;
  lockApp: () => void;
  activeReceipt: ReceiptData | null;
  setActiveReceipt: (receipt: ReceiptData | null) => void;
  ledgerEntries: LedgerEntry[];
  summary: DashboardSummary;
  getNextReceiptNumber: () => string;
  getNextVoucherNumber: () => string;
  getBCLedger: (bcId: string) => {
    totalCollection: number;
    totalPayout: number;
    totalExpenses: number;
    balance: number;
    entries: LedgerEntry[];
  };
  getLuckyDrawLedger: (ldId: string) => {
    totalCollection: number;
    totalPayout: number;
    totalExpenses: number;
    balance: number;
    entries: LedgerEntry[];
  };
  getMemberLedger: (memberId: string) => {
    totalCredit: number;
    totalDebit: number;
    netBalance: number;
    entries: LedgerEntry[];
  };
  getLoanLedger: (loanId: string) => {
    loan: LoanAccount | undefined;
    schedules: EMIScheduleItem[];
    payments: EMIPayment[];
    overdueItems: EMIScheduleItem[];
    nextDueItem: EMIScheduleItem | undefined;
    totalPaid: number;
    remainingPayable: number;
    entries: LedgerEntry[];
    totalDisbursed: number;
    totalCollection: number;
    totalExpenses: number;
    netAccountBalance: number;
  };
  // BC Actions
  addBCGroup: (input: Omit<BCGroup, 'id' | 'createdAt'>) => ActionResult;
  updateBCGroup: (bcId: string, updates: Partial<Omit<BCGroup, 'id' | 'createdAt'>>) => ActionResult;
  softDeleteBCGroup: (bcId: string, reason: string) => ActionResult;
  // Lucky Draw Actions
  addLuckyDrawGroup: (input: Omit<LuckyDrawGroup, 'id' | 'createdAt'>) => ActionResult;
  addLuckyDrawCollection: (input: Omit<LuckyDrawCollection, 'id' | 'receiptNumber' | 'createdAt'>) => ActionResult;
  addLuckyDrawEntry: (input: Omit<LuckyDrawEntry, 'id' | 'voucherNumber' | 'createdAt'>) => ActionResult;
  // Member Actions
  addMember: (
    memberInput: Omit<Member, 'id' | 'createdAt'>,
    enrollmentInput?: {
      groupKind: 'bc' | 'luckydraw';
      groupId: string;
      joiningDate: string;
      monthlyInstallment: number;
      totalInstallments: number;
      memberNumber?: number;
      remarks?: string;
    }
  ) => ActionResult;
  enrollExistingMember: (input: Omit<GroupEnrollment, 'id' | 'createdAt'>) => ActionResult;
  updateMember: (memberId: string, updates: Partial<Omit<Member, 'id' | 'createdAt'>>) => ActionResult;
  deleteMember: (memberId: string, reason: string) => ActionResult;
  transferMember: (input: {
    memberId: string;
    fromEnrollmentId: string;
    toGroupKind: 'bc' | 'luckydraw';
    toGroupId: string;
    transferDate: string;
    reason: string;
  }) => ActionResult;
  // BC Collections, Auctions, Payouts
  addBCCollection: (input: Omit<BCCollection, 'id' | 'receiptNumber' | 'createdAt'>) => ActionResult;
  addBCAuction: (input: Omit<BCAuction, 'id' | 'createdAt'>) => ActionResult;
  addBCPayout: (input: Omit<BCPayout, 'id' | 'voucherNumber' | 'createdAt'>) => ActionResult;
  // Loan & EMI Actions
  addLoanAccount: (input: {
    memberId?: string;
    customerName: string;
    mobile: string;
    address: string;
    loanType: LoanType;
    loanAmount: number;
    interestRate: number;
    interestType: InterestType;
    loanDate: string;
    emiStartDate: string;
    emiFrequency: EMIFrequency;
    totalInstallments: number;
    processingFee: number;
    disbursementMode: PaymentMode;
    loanStatus: LoanApprovalStatus;
    remarks?: string;
  }) => ActionResult;
  updateLoanAccount: (
    loanId: string,
    updates: {
      loanStatus?: LoanApprovalStatus;
      interestRate?: number;
      totalInstallments?: number;
      remarks?: string;
    }
  ) => ActionResult;
  collectEMIPayment: (input: {
    loanId: string;
    paymentDate: string;
    amountPaid: number;
    lateFee: number;
    paymentMode: PaymentMode;
    transactionRef?: string;
    remarks?: string;
  }) => ActionResult;
  // Expense & Income
  addExpense: (input: Omit<ExpenseRecord, 'id' | 'createdAt'>) => ActionResult;
  addOtherIncome: (input: Omit<OtherIncomeRecord, 'id' | 'receiptNumber' | 'createdAt'>) => ActionResult;
  // Settings, Backup & Restore
  updateSettings: (updates: Partial<AppSettings>) => void;
  exportBackupJSON: () => void;
  restoreBackupJSON: (rawJson: string) => ActionResult;
  resetDatabase: (withSeedData: boolean) => void;
}

const FinanceContext = createContext<FinanceContextValue | null>(null);

function loadInitialDb(): FinanceDatabase {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as FinanceDatabase;
      if (parsed && typeof parsed === 'object' && Array.isArray(parsed.members)) {
        return {
          ...EMPTY_DATABASE,
          ...parsed,
          settings: { ...EMPTY_DATABASE.settings, ...(parsed.settings ?? {}) },
        };
      }
    }
  } catch {
    // Fallback to seed
  }
  return INITIAL_SEED_DATABASE;
}

export const FinanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [db, setDb] = useState<FinanceDatabase>(loadInitialDb);
  const [lang, setLangState] = useState<Language>(() => {
    const saved = localStorage.getItem(LANG_KEY);
    return saved === 'mr' ? 'mr' : 'en';
  });
  const [isLocked, setIsLocked] = useState<boolean>(() => db.settings.pinEnabled);
  const [activeReceipt, setActiveReceipt] = useState<ReceiptData | null>(null);

  useEffect(() => {
    try {
      const stamped = {
        ...db,
        settings: { ...db.settings, lastAutoBackupAt: new Date().toISOString() },
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stamped));
    } catch {
      // Ignore quota errors
    }
  }, [db]);

  const setLang = (next: Language) => {
    setLangState(next);
    localStorage.setItem(LANG_KEY, next);
  };

  const unlockApp = (pin: string) => {
    if (pin === db.settings.appPin) {
      setIsLocked(false);
      return true;
    }
    return false;
  };

  const lockApp = () => setIsLocked(true);

  const appendAudit = (
    state: FinanceDatabase,
    action: AuditLogEntry['action'],
    module: AuditLogEntry['module'],
    entityId: string,
    summaryText: string
  ): AuditLogEntry[] => {
    const id = generateNextId('AUD', state.auditLogs.map((a) => a.id), 4);
    return [
      {
        id,
        timestamp: new Date().toISOString(),
        action,
        module,
        entityId,
        summary: summaryText,
      },
      ...state.auditLogs,
    ].slice(0, 200);
  };

  const getAllReceiptNumbers = (state: FinanceDatabase) => [
    ...state.bcCollections.map((c) => c.receiptNumber),
    ...state.luckyDrawCollections.map((c) => c.receiptNumber),
    ...state.emiPayments.map((p) => p.receiptNumber),
    ...state.otherIncomes.map((i) => i.receiptNumber),
  ];

  const getAllVoucherNumbers = (state: FinanceDatabase) => [
    ...state.bcPayouts.map((p) => p.voucherNumber),
    ...state.luckyDrawEntries.map((e) => e.voucherNumber),
  ];

  const getNextReceiptNumber = () => generateNextId('RCP', getAllReceiptNumbers(db), 4);
  const getNextVoucherNumber = () => generateNextId('VCH', getAllVoucherNumbers(db), 4);

  const memberMap = useMemo(() => {
    const m = new Map<string, Member>();
    db.members.forEach((mem) => m.set(mem.id, mem));
    return m;
  }, [db.members]);

  const bcMap = useMemo(() => {
    const m = new Map<string, BCGroup>();
    db.bcGroups.forEach((g) => m.set(g.id, g));
    return m;
  }, [db.bcGroups]);

  const ldMap = useMemo(() => {
    const m = new Map<string, LuckyDrawGroup>();
    db.luckyDrawGroups.forEach((g) => m.set(g.id, g));
    return m;
  }, [db.luckyDrawGroups]);

  const loanMap = useMemo(() => {
    const m = new Map<string, LoanAccount>();
    db.loans.forEach((l) => m.set(l.id, l));
    return m;
  }, [db.loans]);

  // Unified Single-Source-of-Truth Ledger (Prevents Double Counting)
  const ledgerEntries = useMemo<LedgerEntry[]>(() => {
    const entries: LedgerEntry[] = [];

    for (const c of db.bcCollections) {
      const grp = bcMap.get(c.bcGroupId);
      const mem = memberMap.get(c.memberId);
      entries.push({
        id: c.id,
        referenceNumber: c.receiptNumber,
        date: c.collectionDate,
        timestamp: c.createdAt,
        txnType: 'bc_collection',
        direction: 'credit',
        amount: c.totalReceived,
        paymentMode: c.paymentMode,
        book: c.paymentMode === 'Cash' ? 'Cash Book' : 'Bank Book',
        groupKind: 'bc',
        groupId: c.bcGroupId,
        groupName: grp?.name ?? c.bcGroupId,
        memberId: c.memberId,
        memberName: mem?.name ?? c.memberId,
        description: `BC Installment #${c.installmentNumber}`,
        status: 'Completed',
      });
    }

    for (const p of db.bcPayouts) {
      const grp = bcMap.get(p.bcGroupId);
      const mem = memberMap.get(p.winnerMemberId);
      entries.push({
        id: p.id,
        referenceNumber: p.voucherNumber,
        date: p.payoutDate,
        timestamp: p.createdAt,
        txnType: 'bc_payout',
        direction: 'debit',
        amount: p.netPaidAmount,
        paymentMode: p.paymentMode,
        book: p.paymentMode === 'Cash' ? 'Cash Book' : 'Bank Book',
        groupKind: 'bc',
        groupId: p.bcGroupId,
        groupName: grp?.name ?? p.bcGroupId,
        memberId: p.winnerMemberId,
        memberName: mem?.name ?? p.winnerMemberId,
        description: `BC Winner Payout (${p.transactionId || 'Settlement'})`,
        status: p.paymentStatus === 'Paid' ? 'Completed' : 'Pending',
      });
    }

    for (const c of db.luckyDrawCollections) {
      const grp = ldMap.get(c.luckyDrawId);
      const mem = memberMap.get(c.memberId);
      entries.push({
        id: c.id,
        referenceNumber: c.receiptNumber,
        date: c.collectionDate,
        timestamp: c.createdAt,
        txnType: 'luckydraw_collection',
        direction: 'credit',
        amount: c.totalReceived,
        paymentMode: c.paymentMode,
        book: c.paymentMode === 'Cash' ? 'Cash Book' : 'Bank Book',
        groupKind: 'luckydraw',
        groupId: c.luckyDrawId,
        groupName: grp?.name ?? c.luckyDrawId,
        memberId: c.memberId,
        memberName: mem?.name ?? c.memberId,
        description: `Lucky Draw Installment #${c.installmentNumber}`,
        status: 'Completed',
      });
    }

    for (const e of db.luckyDrawEntries) {
      const grp = ldMap.get(e.luckyDrawId);
      const mem = memberMap.get(e.winnerMemberId);
      entries.push({
        id: e.id,
        referenceNumber: e.voucherNumber,
        date: e.paymentDate || e.drawDate,
        timestamp: e.createdAt,
        txnType: 'luckydraw_payout',
        direction: 'debit',
        amount: e.netPrizeAmount,
        paymentMode: e.paymentMode,
        book: e.paymentMode === 'Cash' ? 'Cash Book' : 'Bank Book',
        groupKind: 'luckydraw',
        groupId: e.luckyDrawId,
        groupName: grp?.name ?? e.luckyDrawId,
        memberId: e.winnerMemberId,
        memberName: mem?.name ?? e.winnerMemberId,
        description: `Lucky Draw #${e.drawNumber} Prize`,
        status: e.paymentStatus === 'Paid' ? 'Completed' : 'Pending',
      });
    }

    // Loans: Disbursement (net after processing fee, or principal out + fee in — here we track net cash movement cleanly!)
    for (const l of db.loans) {
      if (l.loanStatus === 'Pending') continue;
      entries.push({
        id: l.id,
        referenceNumber: l.id,
        date: l.loanDate,
        timestamp: l.createdAt,
        txnType: 'loan_disbursement',
        direction: 'debit',
        amount: Math.max(0, l.loanAmount - l.processingFee),
        paymentMode: l.disbursementMode,
        book: l.disbursementMode === 'Cash' ? 'Cash Book' : 'Bank Book',
        groupKind: 'loan',
        groupId: l.id,
        groupName: `${l.loanType} (${l.id})`,
        memberId: l.memberId,
        memberName: l.customerName,
        description: `Loan Disbursed (Net after ₹${l.processingFee} fee)`,
        status: 'Completed',
      });
    }

    for (const ep of db.emiPayments) {
      const loan = loanMap.get(ep.loanId);
      entries.push({
        id: ep.id,
        referenceNumber: ep.receiptNumber,
        date: ep.paymentDate,
        timestamp: ep.createdAt,
        txnType: 'loan_emi',
        direction: 'credit',
        amount: ep.totalReceived,
        paymentMode: ep.paymentMode,
        book: ep.paymentMode === 'Cash' ? 'Cash Book' : 'Bank Book',
        groupKind: 'loan',
        groupId: ep.loanId,
        groupName: loan ? `${loan.loanType} (${loan.id})` : ep.loanId,
        memberId: loan?.memberId,
        memberName: ep.customerName,
        description: ep.isAdvance
          ? `Loan Advance EMI (#${ep.installmentNumber})`
          : `Loan EMI #${ep.installmentNumber}`,
        status: 'Completed',
      });
    }

    for (const exp of db.expenses) {
      const groupName =
        exp.linkedKind === 'bc'
          ? bcMap.get(exp.linkedGroupId ?? '')?.name
          : exp.linkedKind === 'luckydraw'
            ? ldMap.get(exp.linkedGroupId ?? '')?.name
            : exp.linkedKind === 'loan'
              ? exp.linkedGroupId
              : 'General Office';
      entries.push({
        id: exp.id,
        referenceNumber: exp.referenceNumber || exp.id,
        date: exp.expenseDate,
        timestamp: exp.createdAt,
        txnType: 'expense',
        direction: 'debit',
        amount: exp.amount,
        paymentMode: exp.paymentMode,
        book: exp.paymentMode === 'Cash' ? 'Cash Book' : 'Bank Book',
        groupKind: exp.linkedKind,
        groupId: exp.linkedGroupId,
        groupName: groupName ?? 'General Office',
        description: `${exp.category}: ${exp.description}`,
        status: 'Completed',
      });
    }

    for (const inc of db.otherIncomes) {
      entries.push({
        id: inc.id,
        referenceNumber: inc.receiptNumber,
        date: inc.date,
        timestamp: inc.createdAt,
        txnType: 'other_income',
        direction: 'credit',
        amount: inc.amount,
        paymentMode: inc.paymentMode,
        book: inc.paymentMode === 'Cash' ? 'Cash Book' : 'Bank Book',
        groupKind: 'general',
        groupName: 'General Account',
        description: inc.title,
        status: 'Completed',
      });
    }

    return entries.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [db, bcMap, ldMap, memberMap, loanMap]);

  const summary = useMemo<DashboardSummary>(() => {
    const today = todayISO();
    const currentMonthPrefix = today.slice(0, 7);

    let totalCollection = 0;
    let totalPayout = 0;
    let totalExpenses = 0;
    let totalBCCollection = 0;
    let totalLDCollection = 0;
    let cashBalance = 0;
    let bankBalance = 0;
    let dailyCollection = 0;
    let monthlyCollection = 0;

    for (const item of ledgerEntries) {
      if (item.status === 'Pending') continue;
      if (item.direction === 'credit') {
        totalCollection += item.amount;
        if (item.txnType === 'bc_collection') totalBCCollection += item.amount;
        if (item.txnType === 'luckydraw_collection') totalLDCollection += item.amount;
        if (item.date === today) dailyCollection += item.amount;
        if (item.date.startsWith(currentMonthPrefix)) monthlyCollection += item.amount;

        if (item.book === 'Cash Book') cashBalance += item.amount;
        else bankBalance += item.amount;
      } else {
        if (item.txnType === 'expense') totalExpenses += item.amount;
        else totalPayout += item.amount;

        if (item.book === 'Cash Book') cashBalance -= item.amount;
        else bankBalance -= item.amount;
      }
    }

    const totalLoanOutstanding = db.loans
      .filter((l) => l.loanStatus === 'Active' || l.loanStatus === 'Approved')
      .reduce((sum, l) => sum + l.principalOutstanding, 0);

    // Pending EMI (overdue or unpaid installments due up to today)
    const pendingEMI = db.emiSchedules
      .filter((s) => s.status !== 'Paid' && s.dueDate <= today)
      .reduce((sum, s) => sum + Math.max(0, s.emiAmount - s.paidAmount), 0);

    // Pending Member Payments across active BC & Lucky Draw enrollments for current installment #1+
    let pendingMemberPayments = 0;
    for (const enr of db.enrollments) {
      if (enr.status !== 'Active') continue;
      if (enr.groupKind === 'bc') {
        const grp = bcMap.get(enr.groupId);
        if (!grp || grp.isDeleted || grp.status !== 'Active') continue;
        const paidCount = db.bcCollections.filter(
          (c) => c.bcGroupId === enr.groupId && c.memberId === enr.memberId
        ).length;
        if (paidCount === 0) pendingMemberPayments += enr.monthlyInstallment;
      } else {
        const grp = ldMap.get(enr.groupId);
        if (!grp || grp.isDeleted || grp.status !== 'Active') continue;
        const paidCount = db.luckyDrawCollections.filter(
          (c) => c.luckyDrawId === enr.groupId && c.memberId === enr.memberId
        ).length;
        if (paidCount === 0) pendingMemberPayments += enr.monthlyInstallment;
      }
    }

    // Profit & Loss: Processing fees + Loan interest collected + Late fees + Other income (excluding opening capital if labeled capital, or net fee/interest revenue) - Expenses
    const processingFees = db.loans.reduce((s, l) => s + l.processingFee, 0);
    const lateFees =
      db.bcCollections.reduce((s, c) => s + c.lateFee, 0) +
      db.luckyDrawCollections.reduce((s, c) => s + c.lateFee, 0) +
      db.emiPayments.reduce((s, p) => s + p.lateFee, 0);
    const interestCollected = db.emiSchedules
      .filter((s) => s.status === 'Paid')
      .reduce((s, r) => s + r.interestComponent, 0);

    const profitAndLoss = Math.round(
      (processingFees + lateFees + interestCollected - totalExpenses) * 100
    ) / 100;

    return {
      totalAvailableBalance: Math.round((cashBalance + bankBalance) * 100) / 100,
      totalCollection: Math.round(totalCollection * 100) / 100,
      totalPayout: Math.round(totalPayout * 100) / 100,
      totalLoanOutstanding: Math.round(totalLoanOutstanding * 100) / 100,
      totalBCCollection: Math.round(totalBCCollection * 100) / 100,
      totalLDCollection: Math.round(totalLDCollection * 100) / 100,
      totalExpenses: Math.round(totalExpenses * 100) / 100,
      pendingEMI: Math.round(pendingEMI * 100) / 100,
      pendingMemberPayments: Math.round(pendingMemberPayments * 100) / 100,
      cashBalance: Math.round(cashBalance * 100) / 100,
      bankBalance: Math.round(bankBalance * 100) / 100,
      dailyCollection: Math.round(dailyCollection * 100) / 100,
      monthlyCollection: Math.round(monthlyCollection * 100) / 100,
      profitAndLoss,
    };
  }, [ledgerEntries, db, bcMap, ldMap]);

  const getBCLedger = (bcId: string) => {
    const entries = ledgerEntries.filter((e) => e.groupKind === 'bc' && e.groupId === bcId);
    let totalCollection = 0;
    let totalPayout = 0;
    let totalExpenses = 0;
    for (const e of entries) {
      if (e.status === 'Pending') continue;
      if (e.direction === 'credit') totalCollection += e.amount;
      else if (e.txnType === 'expense') totalExpenses += e.amount;
      else totalPayout += e.amount;
    }
    return {
      totalCollection,
      totalPayout,
      totalExpenses,
      balance: totalCollection - totalPayout - totalExpenses,
      entries,
    };
  };

  const getLuckyDrawLedger = (ldId: string) => {
    const entries = ledgerEntries.filter((e) => e.groupKind === 'luckydraw' && e.groupId === ldId);
    let totalCollection = 0;
    let totalPayout = 0;
    let totalExpenses = 0;
    for (const e of entries) {
      if (e.status === 'Pending') continue;
      if (e.direction === 'credit') totalCollection += e.amount;
      else if (e.txnType === 'expense') totalExpenses += e.amount;
      else totalPayout += e.amount;
    }
    return {
      totalCollection,
      totalPayout,
      totalExpenses,
      balance: totalCollection - totalPayout - totalExpenses,
      entries,
    };
  };

  const getMemberLedger = (memberId: string) => {
    const entries = ledgerEntries.filter((e) => e.memberId === memberId);
    let totalCredit = 0;
    let totalDebit = 0;
    for (const e of entries) {
      if (e.status === 'Pending') continue;
      if (e.direction === 'credit') totalCredit += e.amount;
      else totalDebit += e.amount;
    }
    return {
      totalCredit,
      totalDebit,
      netBalance: totalCredit - totalDebit,
      entries,
    };
  };

  const getLoanLedger = (loanId: string) => {
    const today = todayISO();
    const loan = loanMap.get(loanId);
    const schedules = db.emiSchedules
      .filter((s) => s.loanId === loanId)
      .sort((a, b) => a.installmentNumber - b.installmentNumber);
    const payments = db.emiPayments
      .filter((p) => p.loanId === loanId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    const overdueItems = schedules.filter((s) => s.status !== 'Paid' && s.dueDate < today);
    const nextDueItem = schedules.find((s) => s.status !== 'Paid');
    const totalPaid = payments.reduce((sum, p) => sum + p.amountPaid, 0);
    const remainingPayable = loan
      ? Math.max(0, Math.round((loan.principalOutstanding + loan.interestOutstanding) * 100) / 100)
      : 0;
    const entries = ledgerEntries.filter((e) => e.groupKind === 'loan' && e.groupId === loanId);
    let totalDisbursed = 0;
    let totalCollection = 0;
    let totalExpenses = 0;
    for (const e of entries) {
      if (e.status === 'Pending') continue;
      if (e.direction === 'credit') totalCollection += e.amount;
      else if (e.txnType === 'expense') totalExpenses += e.amount;
      else totalDisbursed += e.amount;
    }
    return {
      loan,
      schedules,
      payments,
      overdueItems,
      nextDueItem,
      totalPaid,
      remainingPayable,
      entries,
      totalDisbursed,
      totalCollection,
      totalExpenses,
      netAccountBalance: totalCollection - totalDisbursed - totalExpenses,
    };
  };

  // --- HELPER: ISSUE RECEIPT & RECORD IN HISTORY ---
  const issueReceipt = (
    state: FinanceDatabase,
    partial: Omit<ReceiptData, 'businessName' | 'authorizedSignature'>
  ): { receipt: ReceiptData; nextReceipts: ReceiptData[] } => {
    const receipt: ReceiptData = {
      ...partial,
      businessName: state.settings.businessName,
      authorizedSignature: state.settings.authorizedSignatory,
    };
    return {
      receipt,
      nextReceipts: [receipt, ...state.receipts],
    };
  };

  // --- BC ACTIONS ---
  const addBCGroup: FinanceContextValue['addBCGroup'] = (input) => {
    if (!input.name.trim()) return { ok: false, error: 'BC Group Name is required.' };
    if (
      db.bcGroups.some(
        (g) => !g.isDeleted && g.name.trim().toLowerCase() === input.name.trim().toLowerCase()
      )
    ) {
      return { ok: false, error: 'An active BC group with this name already exists.' };
    }
    const id = generateNextId('BC', db.bcGroups.map((g) => g.id), 3);
    const created: BCGroup = { ...input, id, createdAt: new Date().toISOString() };
    setDb((prev) => ({
      ...prev,
      bcGroups: [...prev.bcGroups, created],
      auditLogs: appendAudit(prev, 'CREATE', 'BC', id, `Created BC group ${created.name}`),
    }));
    return { ok: true, id };
  };

  const updateBCGroup: FinanceContextValue['updateBCGroup'] = (bcId, updates) => {
    const target = db.bcGroups.find((g) => g.id === bcId && !g.isDeleted);
    if (!target) return { ok: false, error: 'BC Group not found.' };
    const now = new Date().toISOString();
    setDb((prev) => ({
      ...prev,
      bcGroups: prev.bcGroups.map((g) => (g.id === bcId ? { ...g, ...updates, updatedAt: now } : g)),
      auditLogs: appendAudit(prev, 'UPDATE', 'BC', bcId, `Modified BC group ${target.name}`),
    }));
    return { ok: true, id: bcId };
  };

  const softDeleteBCGroup: FinanceContextValue['softDeleteBCGroup'] = (bcId, reason) => {
    const target = db.bcGroups.find((g) => g.id === bcId && !g.isDeleted);
    if (!target) return { ok: false, error: 'BC Group not found.' };
    if (!reason.trim()) return { ok: false, error: 'Deletion reason is mandatory for audit.' };
    const now = new Date().toISOString();
    setDb((prev) => ({
      ...prev,
      bcGroups: prev.bcGroups.map((g) =>
        g.id === bcId ? { ...g, isDeleted: true, deletedAt: now, deleteReason: reason.trim() } : g
      ),
      auditLogs: appendAudit(
        prev,
        'SOFT_DELETE',
        'BC',
        bcId,
        `Soft-deleted BC ${target.name}: ${reason.trim()}`
      ),
    }));
    return { ok: true };
  };

  // --- LUCKY DRAW ACTIONS ---
  const addLuckyDrawGroup: FinanceContextValue['addLuckyDrawGroup'] = (input) => {
    if (!input.name.trim()) return { ok: false, error: 'Lucky Draw Name is required.' };
    const id = generateNextId('LD', db.luckyDrawGroups.map((g) => g.id), 3);
    const created: LuckyDrawGroup = { ...input, id, createdAt: new Date().toISOString() };
    setDb((prev) => ({
      ...prev,
      luckyDrawGroups: [...prev.luckyDrawGroups, created],
      auditLogs: appendAudit(prev, 'CREATE', 'LuckyDraw', id, `Created Lucky Draw ${created.name}`),
    }));
    return { ok: true, id };
  };

  const addLuckyDrawCollection: FinanceContextValue['addLuckyDrawCollection'] = (input) => {
    const duplicate = db.luckyDrawCollections.some(
      (c) =>
        c.luckyDrawId === input.luckyDrawId &&
        c.memberId === input.memberId &&
        c.installmentNumber === input.installmentNumber
    );
    if (duplicate) {
      return {
        ok: false,
        error: `Duplicate blocked: Installment #${input.installmentNumber} for this member in this Lucky Draw already exists.`,
      };
    }
    const now = new Date().toISOString();
    const id = generateNextId('LDC', db.luckyDrawCollections.map((c) => c.id), 4);
    const receiptNumber = generateNextId('RCP', getAllReceiptNumbers(db), 4);
    const record: LuckyDrawCollection = { ...input, id, receiptNumber, createdAt: now };

    const grp = ldMap.get(input.luckyDrawId);
    const mem = memberMap.get(input.memberId);

    const { receipt, nextReceipts } = issueReceipt(db, {
      receiptNumber,
      title: 'Lucky Draw Payment Receipt',
      date: input.collectionDate,
      timestamp: now,
      partyName: mem?.name ?? input.memberId,
      partyId: input.memberId,
      groupName: grp?.name ?? input.luckyDrawId,
      paymentType: 'Lucky Draw Collection',
      installmentOrDraw: `Installment #${input.installmentNumber}`,
      breakdown: [
        { label: 'Installment Amount', value: input.installmentAmount },
        ...(input.lateFee > 0 ? [{ label: 'Late Fee (+)', value: input.lateFee }] : []),
      ],
      totalAmount: input.totalReceived,
      paymentMode: input.paymentMode,
      status: 'Paid & Credited',
      remarks: input.remarks,
    });

    setDb((prev) => ({
      ...prev,
      luckyDrawCollections: [...prev.luckyDrawCollections, record],
      receipts: nextReceipts,
      auditLogs: appendAudit(prev, 'CREATE', 'LuckyDraw', id, `Collected ${receiptNumber}`),
    }));
    setActiveReceipt(receipt);
    return { ok: true, id, receipt };
  };

  const addLuckyDrawEntry: FinanceContextValue['addLuckyDrawEntry'] = (input) => {
    if (!input.authorizedBy.trim()) {
      return {
        ok: false,
        error: 'Authorized Draw Officer name/confirmation is required before declaring a winner.',
      };
    }
    const duplicate = db.luckyDrawEntries.some(
      (e) => e.luckyDrawId === input.luckyDrawId && e.drawNumber === input.drawNumber
    );
    if (duplicate) {
      return {
        ok: false,
        error: `Duplicate blocked: Draw #${input.drawNumber} for this Lucky Draw has already been declared.`,
      };
    }
    const now = new Date().toISOString();
    const id = generateNextId('LDE', db.luckyDrawEntries.map((e) => e.id), 4);
    const voucherNumber = generateNextId('VCH', getAllVoucherNumbers(db), 4);
    const record: LuckyDrawEntry = { ...input, id, voucherNumber, createdAt: now };

    const grp = ldMap.get(input.luckyDrawId);
    const mem = memberMap.get(input.winnerMemberId);

    const { receipt, nextReceipts } = issueReceipt(db, {
      receiptNumber: voucherNumber,
      title: 'Lucky Draw Prize Voucher',
      date: input.paymentDate || input.drawDate,
      timestamp: now,
      partyName: mem?.name ?? input.winnerMemberId,
      partyId: input.winnerMemberId,
      groupName: grp?.name ?? input.luckyDrawId,
      paymentType: 'Lucky Draw Prize',
      installmentOrDraw: `Draw #${input.drawNumber} (Auth: ${input.authorizedBy})`,
      breakdown: [
        { label: 'Prize Amount', value: input.prizeAmount },
        ...(input.deduction > 0 ? [{ label: 'Deduction (-)', value: input.deduction, isDeduction: true }] : []),
      ],
      totalAmount: input.netPrizeAmount,
      paymentMode: input.paymentMode,
      status: input.paymentStatus,
      remarks: input.remarks,
    });

    setDb((prev) => ({
      ...prev,
      luckyDrawEntries: [...prev.luckyDrawEntries, record],
      receipts: nextReceipts,
      auditLogs: appendAudit(
        prev,
        'DRAW_AUTHORIZED',
        'LuckyDraw',
        id,
        `Draw #${input.drawNumber} winner ${input.winnerMemberId} authorized by ${input.authorizedBy}`
      ),
    }));
    setActiveReceipt(receipt);
    return { ok: true, id, receipt };
  };

  // --- MEMBER ACTIONS ---
  const addMember: FinanceContextValue['addMember'] = (memberInput, enrollmentInput) => {
    if (!memberInput.name.trim() || !memberInput.mobile.trim()) {
      return { ok: false, error: 'Full Name and Mobile Number are required.' };
    }
    const duplicateMobile = db.members.find(
      (m) => !m.isDeleted && m.mobile.trim() === memberInput.mobile.trim()
    );
    if (duplicateMobile) {
      return { ok: false, error: `Mobile ${memberInput.mobile} already registered (${duplicateMobile.id}).` };
    }
    const now = new Date().toISOString();
    const memberId = generateNextId('MEM', db.members.map((m) => m.id), 4);
    const newMember: Member = { ...memberInput, id: memberId, createdAt: now };

    const nextEnrollments = [...db.enrollments];
    if (enrollmentInput && enrollmentInput.groupId) {
      const enrId = generateNextId('ENR', db.enrollments.map((e) => e.id), 4);
      nextEnrollments.push({
        id: enrId,
        groupKind: enrollmentInput.groupKind,
        groupId: enrollmentInput.groupId,
        memberId,
        memberNumber: enrollmentInput.memberNumber,
        joiningDate: enrollmentInput.joiningDate,
        monthlyInstallment: enrollmentInput.monthlyInstallment,
        totalInstallments: enrollmentInput.totalInstallments,
        status: memberInput.status,
        remarks: enrollmentInput.remarks,
        createdAt: now,
      });
    }

    setDb((prev) => ({
      ...prev,
      members: [...prev.members, newMember],
      enrollments: nextEnrollments,
      auditLogs: appendAudit(prev, 'CREATE', 'Member', memberId, `Registered member ${newMember.name}`),
    }));
    return { ok: true, id: memberId };
  };

  const enrollExistingMember: FinanceContextValue['enrollExistingMember'] = (input) => {
    const exists = db.enrollments.some(
      (e) => e.groupKind === input.groupKind && e.groupId === input.groupId && e.memberId === input.memberId
    );
    if (exists) return { ok: false, error: 'Member is already enrolled in this group.' };
    if (input.memberNumber) {
      const taken = db.enrollments.some(
        (e) => e.groupKind === input.groupKind && e.groupId === input.groupId && e.memberNumber === input.memberNumber
      );
      if (taken) return { ok: false, error: `Token/Member #${input.memberNumber} is already assigned.` };
    }
    const id = generateNextId('ENR', db.enrollments.map((e) => e.id), 4);
    setDb((prev) => ({
      ...prev,
      enrollments: [...prev.enrollments, { ...input, id, createdAt: new Date().toISOString() }],
    }));
    return { ok: true, id };
  };

  const updateMember: FinanceContextValue['updateMember'] = (memberId, updates) => {
    const exists = db.members.some((m) => m.id === memberId);
    if (!exists) return { ok: false, error: 'Member not found.' };
    const now = new Date().toISOString();
    setDb((prev) => ({
      ...prev,
      members: prev.members.map((m) => (m.id === memberId ? { ...m, ...updates, updatedAt: now } : m)),
      enrollments: updates.status
        ? prev.enrollments.map((e) => (e.memberId === memberId ? { ...e, status: updates.status! } : e))
        : prev.enrollments,
      auditLogs: appendAudit(prev, 'UPDATE', 'Member', memberId, `Modified member ${memberId}`),
    }));
    return { ok: true, id: memberId };
  };

  const deleteMember: FinanceContextValue['deleteMember'] = (memberId, reason) => {
    const target = db.members.find((m) => m.id === memberId && !m.isDeleted);
    if (!target) return { ok: false, error: 'Member not found.' };
    if (!reason.trim()) return { ok: false, error: 'Deletion reason is mandatory.' };
    const logId = generateNextId('DEL', db.deletedMemberLogs.map((d) => d.id), 4);
    setDb((prev) => ({
      ...prev,
      members: prev.members.map((m) =>
        m.id === memberId ? { ...m, isDeleted: true, status: 'Inactive' } : m
      ),
      enrollments: prev.enrollments.map((e) =>
        e.memberId === memberId ? { ...e, status: 'Inactive' } : e
      ),
      deletedMemberLogs: [
        ...prev.deletedMemberLogs,
        {
          id: logId,
          memberId: target.id,
          memberName: target.name,
          mobile: target.mobile,
          reason: reason.trim(),
          deletedAt: new Date().toISOString(),
        },
      ],
      auditLogs: appendAudit(prev, 'SOFT_DELETE', 'Member', memberId, `Soft-deleted member: ${reason}`),
    }));
    return { ok: true };
  };

  const transferMember: FinanceContextValue['transferMember'] = (input) => {
    const enr = db.enrollments.find((e) => e.id === input.fromEnrollmentId && e.memberId === input.memberId);
    if (!enr) return { ok: false, error: 'Source enrollment not found.' };
    if (enr.groupKind === input.toGroupKind && enr.groupId === input.toGroupId) {
      return { ok: false, error: 'Source and destination groups cannot be the same.' };
    }
    const targetGroup =
      input.toGroupKind === 'bc' ? bcMap.get(input.toGroupId) : ldMap.get(input.toGroupId);
    if (!targetGroup) return { ok: false, error: 'Destination group not found.' };

    const now = new Date().toISOString();
    const logId = generateNextId('TRF', db.transferLogs.map((t) => t.id), 4);
    const totalInst =
      input.toGroupKind === 'bc'
        ? (targetGroup as BCGroup).totalMembers
        : (targetGroup as LuckyDrawGroup).totalMonths;

    setDb((prev) => ({
      ...prev,
      enrollments: prev.enrollments.map((e) =>
        e.id === input.fromEnrollmentId
          ? {
              ...e,
              groupKind: input.toGroupKind,
              groupId: input.toGroupId,
              monthlyInstallment: targetGroup.monthlyInstallment,
              totalInstallments: totalInst,
              remarks: `Transferred from ${enr.groupId} on ${input.transferDate}`,
            }
          : e
      ),
      transferLogs: [
        ...prev.transferLogs,
        {
          id: logId,
          memberId: input.memberId,
          fromGroupKind: enr.groupKind,
          fromGroupId: enr.groupId,
          toGroupKind: input.toGroupKind,
          toGroupId: input.toGroupId,
          transferDate: input.transferDate,
          reason: input.reason || 'Group Transfer',
          createdAt: now,
        },
      ],
      auditLogs: appendAudit(
        prev,
        'TRANSFER',
        'Member',
        input.memberId,
        `Transferred ${input.memberId} from ${enr.groupId} to ${input.toGroupId}`
      ),
    }));
    return { ok: true, id: logId };
  };

  // --- BC COLLECTION, AUCTION, PAYOUT ---
  const addBCCollection: FinanceContextValue['addBCCollection'] = (input) => {
    const duplicate = db.bcCollections.some(
      (c) =>
        c.bcGroupId === input.bcGroupId &&
        c.memberId === input.memberId &&
        c.installmentNumber === input.installmentNumber
    );
    if (duplicate) {
      return {
        ok: false,
        error: `Duplicate blocked: Installment #${input.installmentNumber} for this member in this BC is already recorded.`,
      };
    }

    const now = new Date().toISOString();
    const id = generateNextId('BCC', db.bcCollections.map((c) => c.id), 4);
    const receiptNumber = generateNextId('RCP', getAllReceiptNumbers(db), 4);
    const record: BCCollection = { ...input, id, receiptNumber, createdAt: now };

    const grp = bcMap.get(input.bcGroupId);
    const mem = memberMap.get(input.memberId);

    const { receipt, nextReceipts } = issueReceipt(db, {
      receiptNumber,
      title: 'BC Collection Receipt',
      date: input.collectionDate,
      timestamp: now,
      partyName: mem?.name ?? input.memberId,
      partyId: input.memberId,
      groupName: grp?.name ?? input.bcGroupId,
      paymentType: 'BC Collection',
      installmentOrDraw: `Installment #${input.installmentNumber}`,
      breakdown: [
        { label: 'Installment Amount', value: input.installmentAmount },
        ...(input.dividendDeduction > 0
          ? [{ label: 'Dividend Deduction (-)', value: input.dividendDeduction, isDeduction: true }]
          : []),
        ...(input.lateFee > 0 ? [{ label: 'Late Fee (+)', value: input.lateFee }] : []),
      ],
      totalAmount: input.totalReceived,
      paymentMode: input.paymentMode,
      status: 'Paid & Credited',
      remarks: input.remarks,
    });

    setDb((prev) => ({
      ...prev,
      bcCollections: [...prev.bcCollections, record],
      receipts: nextReceipts,
      auditLogs: appendAudit(prev, 'CREATE', 'BC', id, `Collected ${receiptNumber} for ${input.bcGroupId}`),
    }));
    setActiveReceipt(receipt);
    return { ok: true, id, receipt };
  };

  const addBCAuction: FinanceContextValue['addBCAuction'] = (input) => {
    const duplicate = db.bcAuctions.some(
      (a) => a.bcGroupId === input.bcGroupId && a.installmentNumber === input.installmentNumber
    );
    if (duplicate) {
      return {
        ok: false,
        error: `Duplicate blocked: Auction for Installment #${input.installmentNumber} already recorded.`,
      };
    }
    const id = generateNextId('AUC', db.bcAuctions.map((a) => a.id), 4);
    const record: BCAuction = { ...input, id, createdAt: new Date().toISOString() };
    setDb((prev) => ({
      ...prev,
      bcAuctions: [...prev.bcAuctions, record],
      auditLogs: appendAudit(prev, 'CREATE', 'BC', id, `Recorded Auction #${input.installmentNumber}`),
    }));
    return { ok: true, id };
  };

  const addBCPayout: FinanceContextValue['addBCPayout'] = (input) => {
    if (input.transactionId.trim()) {
      const dupTxn = db.bcPayouts.some(
        (p) => p.transactionId.trim().toLowerCase() === input.transactionId.trim().toLowerCase()
      );
      if (dupTxn) return { ok: false, error: `Duplicate Transaction ID (${input.transactionId}) detected.` };
    }
    const now = new Date().toISOString();
    const id = generateNextId('PAY', db.bcPayouts.map((p) => p.id), 4);
    const voucherNumber = generateNextId('VCH', getAllVoucherNumbers(db), 4);
    const record: BCPayout = { ...input, id, voucherNumber, createdAt: now };

    const grp = bcMap.get(input.bcGroupId);
    const mem = memberMap.get(input.winnerMemberId);

    const { receipt, nextReceipts } = issueReceipt(db, {
      receiptNumber: voucherNumber,
      title: 'BC Winner Payout Voucher',
      date: input.payoutDate,
      timestamp: now,
      partyName: mem?.name ?? input.winnerMemberId,
      partyId: input.winnerMemberId,
      groupName: grp?.name ?? input.bcGroupId,
      paymentType: 'BC Payout',
      installmentOrDraw: input.transactionId ? `Txn ID: ${input.transactionId}` : 'BC Winner Payout',
      breakdown: [
        { label: 'Total Payable Amount', value: input.totalAmount },
        ...(input.deduction > 0 ? [{ label: 'Deduction (-)', value: input.deduction, isDeduction: true }] : []),
      ],
      totalAmount: input.netPaidAmount,
      paymentMode: input.paymentMode,
      status: input.paymentStatus,
      remarks: input.remarks,
    });

    setDb((prev) => ({
      ...prev,
      bcPayouts: [...prev.bcPayouts, record],
      receipts: nextReceipts,
      auditLogs: appendAudit(prev, 'CREATE', 'BC', id, `Issued BC Payout ${voucherNumber}`),
    }));
    setActiveReceipt(receipt);
    return { ok: true, id, receipt };
  };

  // --- LOAN & EMI ACTIONS ---
  const addLoanAccount: FinanceContextValue['addLoanAccount'] = (input) => {
    if (!input.customerName.trim() || !input.mobile.trim() || input.loanAmount <= 0) {
      return { ok: false, error: 'Customer Name, Mobile, and valid Loan Amount are required.' };
    }

    const calc = calculateLoanSchedule({
      principal: input.loanAmount,
      annualRatePercent: input.interestRate,
      interestType: input.interestType,
      totalInstallments: input.totalInstallments,
      frequency: input.emiFrequency,
      emiStartDate: input.emiStartDate,
    });

    const id = generateNextId('LON', db.loans.map((l) => l.id), 4);
    const now = new Date().toISOString();

    const newLoan: LoanAccount = {
      id,
      memberId: input.memberId || undefined,
      customerName: input.customerName.trim(),
      mobile: input.mobile.trim(),
      address: input.address.trim(),
      loanType: input.loanType,
      loanAmount: input.loanAmount,
      interestRate: input.interestRate,
      interestType: input.interestType,
      loanDate: input.loanDate,
      emiStartDate: input.emiStartDate,
      emiFrequency: input.emiFrequency,
      totalInstallments: input.totalInstallments,
      emiAmount: calc.emiAmount,
      processingFee: input.processingFee,
      disbursementMode: input.disbursementMode,
      loanStatus: input.loanStatus,
      totalInterest: calc.totalInterest,
      totalPayable: calc.totalPayable,
      principalOutstanding: input.loanAmount,
      interestOutstanding: calc.totalInterest,
      remarks: input.remarks,
      createdAt: now,
    };

    const newSchedules: EMIScheduleItem[] = calc.schedule.map((row) => ({
      ...row,
      id: `SCH-${id}-${row.installmentNumber}`,
      loanId: id,
    }));

    setDb((prev) => ({
      ...prev,
      loans: [...prev.loans, newLoan],
      emiSchedules: [...prev.emiSchedules, ...newSchedules],
      auditLogs: appendAudit(
        prev,
        'CREATE',
        'Loan',
        id,
        `Registered ${input.interestType} loan of ₹${input.loanAmount} for ${input.customerName}`
      ),
    }));

    return { ok: true, id };
  };

  // Modify Loan without altering historical EMIPayment records!
  const updateLoanAccount: FinanceContextValue['updateLoanAccount'] = (loanId, updates) => {
    const target = db.loans.find((l) => l.id === loanId);
    if (!target) return { ok: false, error: 'Loan not found.' };

    const now = new Date().toISOString();
    let nextSchedules = db.emiSchedules;
    let updatedLoan: LoanAccount = { ...target, ...updates, updatedAt: now };

    // If interestRate or totalInstallments changed, recalculate ONLY unpaid future schedule rows
    if (
      (updates.interestRate !== undefined && updates.interestRate !== target.interestRate) ||
      (updates.totalInstallments !== undefined && updates.totalInstallments !== target.totalInstallments)
    ) {
      const paidRows = db.emiSchedules.filter((s) => s.loanId === loanId && s.status === 'Paid');
      const remainingCount = Math.max(
        1,
        (updates.totalInstallments ?? target.totalInstallments) - paidRows.length
      );
      const nextStartIdx = paidRows.length;
      const baseStart = db.emiSchedules.find(
        (s) => s.loanId === loanId && s.installmentNumber === nextStartIdx + 1
      )?.dueDate ?? target.emiStartDate;

      const recalc = calculateLoanSchedule({
        principal: target.principalOutstanding,
        annualRatePercent: updates.interestRate ?? target.interestRate,
        interestType: target.interestType,
        totalInstallments: remainingCount,
        frequency: target.emiFrequency,
        emiStartDate: baseStart,
      });

      const regeneratedFuture: EMIScheduleItem[] = recalc.schedule.map((row, idx) => ({
        ...row,
        installmentNumber: nextStartIdx + idx + 1,
        id: `SCH-${loanId}-${nextStartIdx + idx + 1}`,
        loanId,
      }));

      nextSchedules = [
        ...db.emiSchedules.filter((s) => !(s.loanId === loanId && s.status !== 'Paid')),
        ...regeneratedFuture,
      ];

      updatedLoan = {
        ...updatedLoan,
        emiAmount: recalc.emiAmount,
        interestOutstanding: recalc.totalInterest,
        totalPayable:
          Math.round((target.totalPayable - target.interestOutstanding + recalc.totalInterest) * 100) / 100,
      };
    }

    setDb((prev) => ({
      ...prev,
      loans: prev.loans.map((l) => (l.id === loanId ? updatedLoan : l)),
      emiSchedules: nextSchedules,
      auditLogs: appendAudit(
        prev,
        'UPDATE',
        'Loan',
        loanId,
        `Updated loan ${loanId} (Status: ${updatedLoan.loanStatus}). Historical payments preserved.`
      ),
    }));

    return { ok: true, id: loanId };
  };

  const collectEMIPayment: FinanceContextValue['collectEMIPayment'] = (input) => {
    const loan = db.loans.find((l) => l.id === input.loanId);
    if (!loan) return { ok: false, error: 'Loan account not found.' };
    if (loan.loanStatus === 'Closed') return { ok: false, error: 'This loan is already Closed.' };
    if (input.amountPaid <= 0) return { ok: false, error: 'Payment amount must be greater than zero.' };

    const schedules = db.emiSchedules
      .filter((s) => s.loanId === input.loanId)
      .sort((a, b) => a.installmentNumber - b.installmentNumber);

    const unpaidSchedules = schedules.filter((s) => s.status !== 'Paid');
    if (unpaidSchedules.length === 0) {
      return { ok: false, error: 'All EMI installments for this loan are already Paid.' };
    }

    let remainingToApply = input.amountPaid;
    let principalReduced = 0;
    let interestReduced = 0;
    let coveredInstallments = 0;
    const firstInstNum = unpaidSchedules[0].installmentNumber;

    const updatedScheduleMap = new Map<string, EMIScheduleItem>();
    for (const item of unpaidSchedules) {
      if (remainingToApply <= 0) break;
      const dueForRow = Math.max(0, Math.round((item.emiAmount - item.paidAmount) * 100) / 100);
      const applyAmt = Math.min(remainingToApply, dueForRow);
      const newPaid = Math.round((item.paidAmount + applyAmt) * 100) / 100;
      const ratio = item.emiAmount > 0 ? applyAmt / item.emiAmount : 1;

      principalReduced += item.principalComponent * ratio;
      interestReduced += item.interestComponent * ratio;

      const isRowPaid = newPaid >= item.emiAmount - 0.01;
      if (isRowPaid) coveredInstallments += 1;

      updatedScheduleMap.set(item.id, {
        ...item,
        paidAmount: newPaid,
        lateFeePaid: item.installmentNumber === firstInstNum ? item.lateFeePaid + input.lateFee : item.lateFeePaid,
        status: isRowPaid ? 'Paid' : 'Partial',
        paidDate: input.paymentDate,
      });

      remainingToApply = Math.round((remainingToApply - applyAmt) * 100) / 100;
    }

    const nextPrincipalOut = Math.max(
      0,
      Math.round((loan.principalOutstanding - principalReduced) * 100) / 100
    );
    const nextInterestOut = Math.max(
      0,
      Math.round((loan.interestOutstanding - interestReduced) * 100) / 100
    );

    const nextSchedulesAll = db.emiSchedules.map((s) => updatedScheduleMap.get(s.id) ?? s);
    const allPaidNow = nextSchedulesAll
      .filter((s) => s.loanId === input.loanId)
      .every((s) => s.status === 'Paid');

    const now = new Date().toISOString();
    const payId = generateNextId('EMI', db.emiPayments.map((p) => p.id), 4);
    const receiptNumber = generateNextId('RCP', getAllReceiptNumbers(db), 4);
    const isAdvance = coveredInstallments > 1 || input.amountPaid > unpaidSchedules[0].emiAmount + 1;

    const emiPayment: EMIPayment = {
      id: payId,
      receiptNumber,
      loanId: loan.id,
      customerName: loan.customerName,
      installmentNumber: firstInstNum,
      paymentDate: input.paymentDate,
      amountPaid: input.amountPaid,
      lateFee: input.lateFee,
      totalReceived: Math.round((input.amountPaid + input.lateFee) * 100) / 100,
      paymentMode: input.paymentMode,
      transactionRef: input.transactionRef,
      isAdvance,
      remarks: input.remarks,
      createdAt: now,
    };

    const remainingBalanceAfter = Math.round((nextPrincipalOut + nextInterestOut) * 100) / 100;
    const { receipt, nextReceipts } = issueReceipt(db, {
      receiptNumber,
      title: 'Loan EMI Payment Receipt',
      date: input.paymentDate,
      timestamp: now,
      partyName: loan.customerName,
      partyId: loan.memberId ?? loan.id,
      groupName: `${loan.loanType} (${loan.id})`,
      paymentType: isAdvance ? 'Loan EMI (Advance/Multi)' : 'Loan EMI',
      installmentOrDraw: `EMI #${firstInstNum}`,
      remainingBalance: remainingBalanceAfter,
      breakdown: [
        { label: 'EMI Amount Paid', value: input.amountPaid },
        ...(input.lateFee > 0 ? [{ label: 'Late Fee (+)', value: input.lateFee }] : []),
      ],
      totalAmount: emiPayment.totalReceived,
      paymentMode: input.paymentMode,
      status: allPaidNow ? 'Loan Closed (Paid in Full)' : 'Paid & Credited',
      remarks: input.remarks,
    });

    setDb((prev) => ({
      ...prev,
      loans: prev.loans.map((l) =>
        l.id === loan.id
          ? {
              ...l,
              principalOutstanding: nextPrincipalOut,
              interestOutstanding: nextInterestOut,
              loanStatus: allPaidNow ? 'Closed' : l.loanStatus,
              updatedAt: now,
            }
          : l
      ),
      emiSchedules: nextSchedulesAll,
      emiPayments: [...prev.emiPayments, emiPayment],
      receipts: nextReceipts,
      auditLogs: appendAudit(
        prev,
        'CREATE',
        'Loan',
        payId,
        `Collected EMI ${receiptNumber} (₹${emiPayment.totalReceived}) for ${loan.id}`
      ),
    }));

    setActiveReceipt(receipt);
    return { ok: true, id: payId, receipt };
  };

  // --- EXPENSE & OTHER INCOME ---
  const addExpense: FinanceContextValue['addExpense'] = (input) => {
    if (!input.description.trim() || input.amount <= 0) {
      return { ok: false, error: 'Expense description and valid amount are required.' };
    }
    const id = generateNextId('EXP', db.expenses.map((e) => e.id), 4);
    const record: ExpenseRecord = { ...input, id, createdAt: new Date().toISOString() };
    setDb((prev) => ({
      ...prev,
      expenses: [...prev.expenses, record],
      auditLogs: appendAudit(prev, 'CREATE', 'Expense', id, `Recorded expense ₹${input.amount}`),
    }));
    return { ok: true, id };
  };

  const addOtherIncome: FinanceContextValue['addOtherIncome'] = (input) => {
    if (!input.title.trim() || input.amount <= 0) {
      return { ok: false, error: 'Income title and valid amount are required.' };
    }
    const now = new Date().toISOString();
    const id = generateNextId('INC', db.otherIncomes.map((i) => i.id), 4);
    const receiptNumber = generateNextId('RCP', getAllReceiptNumbers(db), 4);
    const record: OtherIncomeRecord = { ...input, id, receiptNumber, createdAt: now };

    const { receipt, nextReceipts } = issueReceipt(db, {
      receiptNumber,
      title: 'Deposit / Income Receipt',
      date: input.date,
      timestamp: now,
      partyName: input.title,
      groupName: 'General Account',
      paymentType: 'Other Income / Deposit',
      breakdown: [{ label: 'Deposit / Income Amount', value: input.amount }],
      totalAmount: input.amount,
      paymentMode: input.paymentMode,
      status: 'Credited',
      remarks: input.remarks,
    });

    setDb((prev) => ({
      ...prev,
      otherIncomes: [...prev.otherIncomes, record],
      receipts: nextReceipts,
      auditLogs: appendAudit(prev, 'CREATE', 'System', id, `Recorded income ${receiptNumber}`),
    }));
    setActiveReceipt(receipt);
    return { ok: true, id, receipt };
  };

  // --- SETTINGS, BACKUP & RESTORE ---
  const updateSettings = (updates: Partial<AppSettings>) => {
    setDb((prev) => ({
      ...prev,
      settings: { ...prev.settings, ...updates },
    }));
  };

  const exportBackupJSON = () => {
    const payload = JSON.stringify(db, null, 2);
    const blob = new Blob([payload], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `koshpay_backup_${todayISO()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const restoreBackupJSON = (rawJson: string): ActionResult => {
    try {
      const parsed = JSON.parse(rawJson) as FinanceDatabase;
      if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.members)) {
        return { ok: false, error: 'Invalid backup file format.' };
      }
      const next: FinanceDatabase = {
        ...EMPTY_DATABASE,
        ...parsed,
        settings: { ...EMPTY_DATABASE.settings, ...(parsed.settings ?? {}) },
      };
      next.auditLogs = appendAudit(next, 'RESTORE', 'System', 'BACKUP', 'Database restored from JSON backup');
      setDb(next);
      return { ok: true };
    } catch {
      return { ok: false, error: 'Could not parse JSON backup file.' };
    }
  };

  const resetDatabase = (withSeedData: boolean) => {
    setDb(withSeedData ? INITIAL_SEED_DATABASE : EMPTY_DATABASE);
  };

  return (
    <FinanceContext.Provider
      value={{
        db,
        lang,
        setLang,
        isLocked,
        unlockApp,
        lockApp,
        activeReceipt,
        setActiveReceipt,
        ledgerEntries,
        summary,
        getNextReceiptNumber,
        getNextVoucherNumber,
        getBCLedger,
        getLuckyDrawLedger,
        getMemberLedger,
        getLoanLedger,
        addBCGroup,
        updateBCGroup,
        softDeleteBCGroup,
        addLuckyDrawGroup,
        addLuckyDrawCollection,
        addLuckyDrawEntry,
        addMember,
        enrollExistingMember,
        updateMember,
        deleteMember,
        transferMember,
        addBCCollection,
        addBCAuction,
        addBCPayout,
        addLoanAccount,
        updateLoanAccount,
        collectEMIPayment,
        addExpense,
        addOtherIncome,
        updateSettings,
        exportBackupJSON,
        restoreBackupJSON,
        resetDatabase,
      }}
    >
      {children}
    </FinanceContext.Provider>
  );
};

export function useFinance(): FinanceContextValue {
  const ctx = useContext(FinanceContext);
  if (!ctx) throw new Error('useFinance must be used inside FinanceProvider');
  return ctx;
}
