export type Language = 'en' | 'mr';

export type PaymentMode = 'Cash' | 'UPI' | 'Bank';
export type RecordStatus = 'Active' | 'Inactive';
export type BCStatus = 'Active' | 'Completed';
export type PaymentStatus = 'Paid' | 'Pending';

export type BCType = '15 Members BC' | '20 Members BC' | '50 Members BC' | 'Custom';
export type DrawType = '150 Members' | 'Custom';
export type MemberCategory = 'BC Member' | 'Lucky Draw' | 'Loan Customer' | 'General';

export type InterestType = 'Flat' | 'Reducing Balance';
export type EMIFrequency = 'Monthly' | 'Weekly';
export type LoanApprovalStatus = 'Pending' | 'Approved' | 'Active' | 'Closed';

export interface BCGroup {
  id: string;
  name: string;
  bcType: BCType;
  totalMembers: number;
  monthlyInstallment: number;
  totalAmount: number;
  startDate: string;
  monthlyDueDate: number; // 1-28
  auctionDate: number; // 1-28
  dividendRules: string;
  description: string;
  status: BCStatus;
  isDeleted?: boolean;
  deletedAt?: string;
  deleteReason?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface LuckyDrawGroup {
  id: string;
  name: string;
  drawType: DrawType;
  totalMembers: number;
  monthlyInstallment: number;
  totalMonths: number;
  totalDrawAmount: number;
  prizeAmount: number;
  startDate: string;
  monthlyDrawDate: number; // 1-28
  rulesAndConditions: string;
  status: BCStatus;
  isDeleted?: boolean;
  createdAt: string;
}

export interface Member {
  id: string; // e.g., MEM-1001
  name: string;
  mobile: string;
  address: string;
  joiningDate: string;
  category: MemberCategory;
  aadhaar?: string;
  nomineeName?: string;
  loanCustomerRef?: string;
  initialBalance: number;
  status: RecordStatus;
  isDeleted?: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface GroupEnrollment {
  id: string;
  groupKind: 'bc' | 'luckydraw';
  groupId: string;
  memberId: string;
  memberNumber?: number;
  joiningDate: string;
  monthlyInstallment: number;
  totalInstallments: number;
  status: RecordStatus;
  remarks?: string;
  createdAt: string;
}

export interface BCCollection {
  id: string;
  receiptNumber: string;
  bcGroupId: string;
  memberId: string;
  installmentNumber: number;
  collectionDate: string;
  installmentAmount: number;
  dividendDeduction: number;
  lateFee: number;
  totalReceived: number;
  paymentMode: PaymentMode;
  transactionRef?: string;
  remarks: string;
  createdAt: string;
}

export interface BCAuction {
  id: string;
  bcGroupId: string;
  auctionDate: string;
  installmentNumber: number;
  totalBCAmount: number;
  winnerMemberId: string;
  auctionBidAmount: number;
  dividendAmount: number;
  winnerPayableAmount: number;
  otherDeduction: number;
  finalPayout: number;
  remarks: string;
  createdAt: string;
}

export interface BCPayout {
  id: string;
  voucherNumber: string;
  bcGroupId: string;
  auctionId?: string;
  winnerMemberId: string;
  payoutDate: string;
  totalAmount: number;
  deduction: number;
  netPaidAmount: number;
  paymentMode: PaymentMode;
  transactionId: string;
  paymentStatus: PaymentStatus;
  remarks?: string;
  createdAt: string;
}

export interface LuckyDrawCollection {
  id: string;
  receiptNumber: string;
  luckyDrawId: string;
  memberId: string;
  installmentNumber: number;
  collectionDate: string;
  installmentAmount: number;
  lateFee: number;
  totalReceived: number;
  paymentMode: PaymentMode;
  transactionRef?: string;
  remarks: string;
  createdAt: string;
}

export interface LuckyDrawEntry {
  id: string;
  voucherNumber: string;
  drawNumber: number;
  drawDate: string;
  luckyDrawId: string;
  totalMembers: number;
  winnerMemberId: string;
  prizeAmount: number;
  deduction: number;
  netPrizeAmount: number;
  paymentStatus: PaymentStatus;
  paymentDate: string;
  paymentMode: PaymentMode;
  authorizedBy: string;
  remarks?: string;
  createdAt: string;
}

export type LoanType = 'Personal Loan' | 'Business Loan' | 'Gold / Collateral' | 'Emergency Loan';

export interface LoanAccount {
  id: string; // LON-0001
  memberId?: string;
  customerName: string;
  mobile: string;
  address: string;
  loanType: LoanType;
  loanAmount: number;
  interestRate: number; // % per annum
  interestType: InterestType;
  loanDate: string;
  emiStartDate: string;
  emiFrequency: EMIFrequency;
  totalInstallments: number;
  emiAmount: number;
  processingFee: number;
  disbursementMode: PaymentMode;
  loanStatus: LoanApprovalStatus;
  totalInterest: number;
  totalPayable: number;
  principalOutstanding: number;
  interestOutstanding: number;
  remarks?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface EMIScheduleItem {
  id: string;
  loanId: string;
  installmentNumber: number;
  dueDate: string;
  openingBalance: number;
  principalComponent: number;
  interestComponent: number;
  emiAmount: number;
  paidAmount: number;
  lateFeePaid: number;
  status: 'Pending' | 'Partial' | 'Paid';
  paidDate?: string;
}

export interface EMIPayment {
  id: string;
  receiptNumber: string;
  loanId: string;
  customerName: string;
  installmentNumber: number;
  paymentDate: string;
  amountPaid: number;
  lateFee: number;
  totalReceived: number;
  paymentMode: PaymentMode;
  transactionRef?: string;
  isAdvance: boolean;
  remarks?: string;
  createdAt: string;
}

export type ExpenseCategory =
  | 'Office Rent'
  | 'Printing & Stationery'
  | 'Meeting & Refreshments'
  | 'Staff Salary'
  | 'Draw Event'
  | 'Travel'
  | 'Bank Charges'
  | 'Other';

export interface ExpenseRecord {
  id: string; // EXP-0001
  category: ExpenseCategory;
  linkedKind: 'general' | 'bc' | 'luckydraw' | 'loan';
  linkedGroupId?: string;
  expenseDate: string;
  description: string;
  amount: number;
  paymentMode: PaymentMode;
  referenceNumber: string;
  remarks: string;
  createdAt: string;
}

export interface OtherIncomeRecord {
  id: string;
  receiptNumber: string;
  title: string;
  date: string;
  amount: number;
  paymentMode: PaymentMode;
  remarks: string;
  createdAt: string;
}

export interface TransferLog {
  id: string;
  memberId: string;
  fromGroupKind: 'bc' | 'luckydraw';
  fromGroupId: string;
  toGroupKind: 'bc' | 'luckydraw';
  toGroupId: string;
  transferDate: string;
  reason: string;
  createdAt: string;
}

export interface DeletedMemberLog {
  id: string;
  memberId: string;
  memberName: string;
  mobile: string;
  reason: string;
  deletedAt: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: 'CREATE' | 'UPDATE' | 'SOFT_DELETE' | 'TRANSFER' | 'DRAW_AUTHORIZED' | 'RESTORE';
  module: 'BC' | 'LuckyDraw' | 'Member' | 'Loan' | 'Expense' | 'System';
  entityId: string;
  summary: string;
}

export type UniversalTxnType =
  | 'bc_collection'
  | 'bc_payout'
  | 'luckydraw_collection'
  | 'luckydraw_payout'
  | 'loan_disbursement'
  | 'loan_emi'
  | 'expense'
  | 'other_income';

export interface LedgerEntry {
  id: string;
  referenceNumber: string;
  date: string;
  timestamp: string;
  txnType: UniversalTxnType;
  direction: 'credit' | 'debit';
  amount: number;
  paymentMode: PaymentMode;
  book: 'Cash Book' | 'Bank Book';
  groupKind?: 'bc' | 'luckydraw' | 'loan' | 'general';
  groupId?: string;
  groupName?: string;
  memberId?: string;
  memberName?: string;
  description: string;
  status: 'Completed' | 'Pending';
}

export interface ReceiptData {
  receiptNumber: string;
  title: string;
  businessName?: string;
  authorizedSignature?: string;
  date: string;
  timestamp: string;
  partyName: string;
  partyId?: string;
  groupName?: string;
  paymentType?: string;
  installmentOrDraw?: string;
  remainingBalance?: number;
  breakdown: { label: string; value: number; isDeduction?: boolean }[];
  totalAmount: number;
  paymentMode: PaymentMode;
  status: string;
  remarks?: string;
}

export interface AppSettings {
  businessName: string;
  authorizedSignatory: string;
  pinEnabled: boolean;
  appPin: string;
  biometricEnabled: boolean;
  lastAutoBackupAt: string;
}

export interface FinanceDatabase {
  version: number;
  settings: AppSettings;
  bcGroups: BCGroup[];
  luckyDrawGroups: LuckyDrawGroup[];
  members: Member[];
  enrollments: GroupEnrollment[];
  bcCollections: BCCollection[];
  bcAuctions: BCAuction[];
  bcPayouts: BCPayout[];
  luckyDrawCollections: LuckyDrawCollection[];
  luckyDrawEntries: LuckyDrawEntry[];
  loans: LoanAccount[];
  emiSchedules: EMIScheduleItem[];
  emiPayments: EMIPayment[];
  expenses: ExpenseRecord[];
  otherIncomes: OtherIncomeRecord[];
  receipts: ReceiptData[];
  transferLogs: TransferLog[];
  deletedMemberLogs: DeletedMemberLog[];
  auditLogs: AuditLogEntry[];
}
