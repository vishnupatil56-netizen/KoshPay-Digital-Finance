import { EMIFrequency, EMIScheduleItem, InterestType } from '../types/finance';

export interface EMICalculationSummary {
  emiAmount: number;
  totalInterest: number;
  totalPayable: number;
  schedule: Omit<EMIScheduleItem, 'id' | 'loanId'>[];
}

function addPeriod(dateStr: string, periodIndex: number, frequency: EMIFrequency): string {
  const base = new Date(dateStr + 'T00:00:00');
  if (Number.isNaN(base.getTime())) return dateStr;
  const d = new Date(base);
  if (frequency === 'Weekly') {
    d.setDate(d.getDate() + periodIndex * 7);
  } else {
    d.setMonth(d.getMonth() + periodIndex);
  }
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function calculateLoanSchedule(params: {
  principal: number;
  annualRatePercent: number;
  interestType: InterestType;
  totalInstallments: number;
  frequency: EMIFrequency;
  emiStartDate: string;
}): EMICalculationSummary {
  const P = Math.max(0, params.principal);
  const n = Math.max(1, Math.round(params.totalInstallments));
  const periodsPerYear = params.frequency === 'Weekly' ? 52 : 12;
  const periodRate = params.annualRatePercent / 100 / periodsPerYear;

  const schedule: Omit<EMIScheduleItem, 'id' | 'loanId'>[] = [];

  if (params.interestType === 'Flat') {
    const years = n / periodsPerYear;
    const totalInterest = Math.round(P * (params.annualRatePercent / 100) * years * 100) / 100;
    const totalPayable = Math.round((P + totalInterest) * 100) / 100;
    const emiAmount = Math.round((totalPayable / n) * 100) / 100;

    let remainingPrincipal = P;
    const principalPerInst = Math.round((P / n) * 100) / 100;
    const interestPerInst = Math.round((totalInterest / n) * 100) / 100;

    for (let i = 1; i <= n; i++) {
      const isLast = i === n;
      const prin = isLast ? Math.round(remainingPrincipal * 100) / 100 : principalPerInst;
      const intr = isLast
        ? Math.round((totalInterest - interestPerInst * (n - 1)) * 100) / 100
        : interestPerInst;
      const emi = Math.round((prin + intr) * 100) / 100;

      schedule.push({
        installmentNumber: i,
        dueDate: addPeriod(params.emiStartDate, i - 1, params.frequency),
        openingBalance: Math.round(remainingPrincipal * 100) / 100,
        principalComponent: prin,
        interestComponent: intr,
        emiAmount: emi,
        paidAmount: 0,
        lateFeePaid: 0,
        status: 'Pending',
      });

      remainingPrincipal = Math.max(0, remainingPrincipal - prin);
    }

    return {
      emiAmount,
      totalInterest,
      totalPayable,
      schedule,
    };
  }

  // Reducing Balance
  let emiAmount = 0;
  if (periodRate === 0) {
    emiAmount = Math.round((P / n) * 100) / 100;
  } else {
    const factor = Math.pow(1 + periodRate, n);
    emiAmount = Math.round(((P * periodRate * factor) / (factor - 1)) * 100) / 100;
  }

  let balance = P;
  let totalInterest = 0;
  let totalPayable = 0;

  for (let i = 1; i <= n; i++) {
    const isLast = i === n;
    const interestComp = Math.round(balance * periodRate * 100) / 100;
    const principalComp = isLast
      ? Math.round(balance * 100) / 100
      : Math.round(Math.min(balance, emiAmount - interestComp) * 100) / 100;
    const thisEmi = Math.round((principalComp + interestComp) * 100) / 100;

    schedule.push({
      installmentNumber: i,
      dueDate: addPeriod(params.emiStartDate, i - 1, params.frequency),
      openingBalance: Math.round(balance * 100) / 100,
      principalComponent: principalComp,
      interestComponent: interestComp,
      emiAmount: thisEmi,
      paidAmount: 0,
      lateFeePaid: 0,
      status: 'Pending',
    });

    totalInterest += interestComp;
    totalPayable += thisEmi;
    balance = Math.max(0, balance - principalComp);
  }

  return {
    emiAmount,
    totalInterest: Math.round(totalInterest * 100) / 100,
    totalPayable: Math.round(totalPayable * 100) / 100,
    schedule,
  };
}
