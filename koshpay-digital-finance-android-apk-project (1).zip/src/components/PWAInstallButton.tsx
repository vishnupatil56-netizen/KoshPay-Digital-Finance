import React, { useState } from 'react';
import { Download, Smartphone, WifiOff } from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ variant?: 'compact' | 'card' }> = ({
  variant = 'compact',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className={
          variant === 'card'
            ? 'inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl transition-colors min-h-[44px]'
            : 'inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#002E6E] bg-blue-50 hover:bg-blue-100 rounded-xl transition-colors whitespace-nowrap min-h-[36px]'
        }
      >
        <Download className="w-3.5 h-3.5" />
        <span>Install Android / PWA</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className={
            variant === 'card'
              ? 'inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#002E6E] bg-blue-50 hover:bg-blue-100 rounded-xl transition-colors min-h-[44px]'
              : 'inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#002E6E] bg-blue-50 hover:bg-blue-100 rounded-xl transition-colors whitespace-nowrap min-h-[36px]'
          }
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Install App</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
            <div className="w-full max-w-sm rounded-2xl bg-white p-6 border border-slate-200 space-y-4">
              <h3 className="text-base font-bold text-[#002E6E] font-display">
                Install on iPhone / iPad
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                1. Tap the <strong>Share</strong> icon in the Safari toolbar.
                <br />
                2. Scroll down and tap <strong>Add to Home Screen</strong>.
              </p>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="w-full rounded-xl bg-[#002E6E] py-2.5 text-xs font-semibold text-white hover:bg-[#001F4D]"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div className="fixed bottom-16 lg:bottom-4 left-4 z-40 inline-flex items-center gap-2 rounded-xl bg-[#002E6E] px-3.5 py-2 text-xs font-medium text-white border border-blue-800">
      <WifiOff className="w-3.5 h-3.5 text-amber-300" />
      <span>Offline Mode — Local ledger data active</span>
    </div>
  );
};
