import React, { useEffect, useMemo, useState } from 'react';
import { ReceiptText, Search } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { ExpenseCategory, PaymentMode, PaymentStatus, UniversalTxnType } from '../types/finance';
import { formatDateOnly, formatINR, todayISO } from '../utils/formatters';
import { FieldLabel, FormAlert, SectionHeader, inputBaseClass, monoInputClass } from './FormControls';

const EXPENSE_CATEGORIES: ExpenseCategory[] = [
  'Office Rent',
  'Printing & Stationery',
  'Meeting & Refreshments',
  'Staff Salary',
  'Draw Event',
  'Travel',
  'Bank Charges',
  'Other',
];

export const UniversalTransactionView: React.FC = () => {
  const {
    db,
    lang,
    getNextReceiptNumber,
    getNextVoucherNumber,
    addBCCollection,
    addBCPayout,
    addLuckyDrawCollection,
    addLuckyDrawEntry,
    collectEMIPayment,
    addExpense,
    addOtherIncome,
    setActiveReceipt,
  } = useFinance();

  const [viewMode, setViewMode] = useState<'entry' | 'receipts'>('entry');
  const [receiptSearch, setReceiptSearch] = useState('');

  const [txnType, setTxnType] = useState<UniversalTxnType>('bc_collection');
  const [date, setDate] = useState(todayISO());
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('Cash');
  const [txnRef, setTxnRef] = useState('');
  const [remarks, setRemarks] = useState('');
  const [feedback, setFeedback] = useState<{ type: 'error' | 'success'; message: string } | null>(null);

  const activeBCs = useMemo(() => db.bcGroups.filter((g) => !g.isDeleted), [db.bcGroups]);
  const activeMembers = useMemo(() => db.members.filter((m) => !m.isDeleted), [db.members]);

  // BC & LD selectors
  const [bcGroupId, setBcGroupId] = useState(activeBCs[0]?.id ?? '');
  const [ldGroupId, setLdGroupId] = useState(db.luckyDrawGroups[0]?.id ?? '');
  const [memberId, setMemberId] = useState(activeMembers[0]?.id ?? '');
  const [installmentNumber, setInstallmentNumber] = useState(1);

  // Loan EMI selector
  const [loanId, setLoanId] = useState(db.loans[0]?.id ?? '');
  const [emiAmount, setEmiAmount] = useState(db.loans[0]?.emiAmount ?? 0);

  // Collection fields
  const [installmentAmount, setInstallmentAmount] = useState(0);
  const [dividendDeduction, setDividendDeduction] = useState(0);
  const [lateFee, setLateFee] = useState(0);

  // Payout / Prize fields
  const [totalPayable, setTotalPayable] = useState(0);
  const [deduction, setDeduction] = useState(0);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('Paid');
  const [drawNumber, setDrawNumber] = useState(1);

  // Expense / Income fields
  const [expenseCategory, setExpenseCategory] = useState<ExpenseCategory>('Office Rent');
  const [expenseLinkKind, setExpenseLinkKind] = useState<'general' | 'bc' | 'luckydraw'>('general');
  const [expenseLinkGroupId, setExpenseLinkGroupId] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState(0);

  const selectedBC = activeBCs.find((g) => g.id === bcGroupId);
  const selectedLD = db.luckyDrawGroups.find((g) => g.id === ldGroupId);
  const selectedLoan = db.loans.find((l) => l.id === loanId);

  const bcMembers = useMemo(() => {
    const enrolledIds = new Set(
      db.enrollments
        .filter((e) => e.groupKind === 'bc' && e.groupId === bcGroupId && e.status === 'Active')
        .map((e) => e.memberId)
    );
    const list = activeMembers.filter((m) => enrolledIds.has(m.id));
    return list.length > 0 ? list : activeMembers;
  }, [db.enrollments, activeMembers, bcGroupId]);

  const ldMembers = useMemo(() => {
    const enrolledIds = new Set(
      db.enrollments
        .filter((e) => e.groupKind === 'luckydraw' && e.groupId === ldGroupId && e.status === 'Active')
        .map((e) => e.memberId)
    );
    const list = activeMembers.filter((m) => enrolledIds.has(m.id));
    return list.length > 0 ? list : activeMembers;
  }, [db.enrollments, activeMembers, ldGroupId]);

  useEffect(() => {
    if (txnType === 'bc_collection' && selectedBC) {
      setInstallmentAmount(selectedBC.monthlyInstallment);
      if (bcMembers.length > 0 && !bcMembers.some((m) => m.id === memberId)) {
        setMemberId(bcMembers[0].id);
      }
    } else if (txnType === 'bc_payout' && selectedBC) {
      setTotalPayable(selectedBC.totalAmount);
      if (bcMembers.length > 0 && !bcMembers.some((m) => m.id === memberId)) {
        setMemberId(bcMembers[0].id);
      }
    } else if (txnType === 'luckydraw_collection' && selectedLD) {
      setInstallmentAmount(selectedLD.monthlyInstallment);
      if (ldMembers.length > 0 && !ldMembers.some((m) => m.id === memberId)) {
        setMemberId(ldMembers[0].id);
      }
    } else if (txnType === 'luckydraw_payout' && selectedLD) {
      const existingDraws = db.luckyDrawEntries.filter((e) => e.luckyDrawId === ldGroupId);
      setDrawNumber(existingDraws.length + 1);
      setTotalPayable(selectedLD.prizeAmount);
      if (ldMembers.length > 0 && !ldMembers.some((m) => m.id === memberId)) {
        setMemberId(ldMembers[0].id);
      }
    } else if (txnType === 'loan_emi' && selectedLoan) {
      setEmiAmount(selectedLoan.emiAmount);
    }
  }, [
    txnType,
    bcGroupId,
    ldGroupId,
    loanId,
    selectedBC,
    selectedLD,
    selectedLoan,
    bcMembers,
    ldMembers,
    db.luckyDrawEntries,
    memberId,
  ]);

  const calculatedNetCollection = Math.max(0, installmentAmount - dividendDeduction + lateFee);
  const calculatedNetLDCollection = Math.max(0, installmentAmount + lateFee);
  const calculatedNetPayout = Math.max(0, totalPayable - deduction);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    if (txnType === 'bc_collection') {
      const res = addBCCollection({
        bcGroupId,
        memberId,
        installmentNumber,
        collectionDate: date,
        installmentAmount,
        dividendDeduction,
        lateFee,
        totalReceived: calculatedNetCollection,
        paymentMode,
        transactionRef: txnRef,
        remarks,
      });
      setFeedback(
        res.ok
          ? { type: 'success', message: `BC Collection saved (${res.receipt?.receiptNumber}).` }
          : { type: 'error', message: res.error ?? 'Failed to save.' }
      );
      if (res.ok) {
        setTxnRef('');
        setRemarks('');
      }
      return;
    }

    if (txnType === 'bc_payout') {
      const res = addBCPayout({
        bcGroupId,
        winnerMemberId: memberId,
        payoutDate: date,
        totalAmount: totalPayable,
        deduction,
        netPaidAmount: calculatedNetPayout,
        paymentMode,
        transactionId: txnRef,
        paymentStatus,
        remarks,
      });
      setFeedback(
        res.ok
          ? { type: 'success', message: `BC Payout recorded (${res.receipt?.receiptNumber}).` }
          : { type: 'error', message: res.error ?? 'Failed to save.' }
      );
      if (res.ok) {
        setTxnRef('');
        setRemarks('');
      }
      return;
    }

    if (txnType === 'luckydraw_collection') {
      const res = addLuckyDrawCollection({
        luckyDrawId: ldGroupId,
        memberId,
        installmentNumber,
        collectionDate: date,
        installmentAmount,
        lateFee,
        totalReceived: calculatedNetLDCollection,
        paymentMode,
        transactionRef: txnRef,
        remarks,
      });
      setFeedback(
        res.ok
          ? { type: 'success', message: `Lucky Draw Collection saved (${res.receipt?.receiptNumber}).` }
          : { type: 'error', message: res.error ?? 'Failed to save.' }
      );
      if (res.ok) {
        setTxnRef('');
        setRemarks('');
      }
      return;
    }

    if (txnType === 'luckydraw_payout') {
      const res = addLuckyDrawEntry({
        drawNumber,
        drawDate: date,
        luckyDrawId: ldGroupId,
        totalMembers: selectedLD?.totalMembers ?? 150,
        winnerMemberId: memberId,
        prizeAmount: totalPayable,
        deduction,
        netPrizeAmount: calculatedNetPayout,
        paymentStatus,
        paymentDate: date,
        paymentMode,
        authorizedBy: db.settings.authorizedSignatory,
        remarks,
      });
      setFeedback(
        res.ok
          ? { type: 'success', message: `Lucky Draw Winner Entry saved (${res.receipt?.receiptNumber}).` }
          : { type: 'error', message: res.error ?? 'Failed to save.' }
      );
      if (res.ok) setRemarks('');
      return;
    }

    if (txnType === 'loan_emi') {
      const res = collectEMIPayment({
        loanId,
        paymentDate: date,
        amountPaid: emiAmount,
        lateFee,
        paymentMode,
        transactionRef: txnRef,
        remarks,
      });
      setFeedback(
        res.ok
          ? { type: 'success', message: `Loan EMI saved (${res.receipt?.receiptNumber}).` }
          : { type: 'error', message: res.error ?? 'Failed to collect EMI.' }
      );
      if (res.ok) {
        setTxnRef('');
        setRemarks('');
      }
      return;
    }

    if (txnType === 'expense') {
      const res = addExpense({
        category: expenseCategory,
        linkedKind: expenseLinkKind,
        linkedGroupId: expenseLinkKind === 'general' ? undefined : expenseLinkGroupId,
        expenseDate: date,
        description,
        amount,
        paymentMode,
        referenceNumber: txnRef,
        remarks,
      });
      setFeedback(
        res.ok
          ? { type: 'success', message: `Expense ${res.id} recorded.` }
          : { type: 'error', message: res.error ?? 'Failed to save.' }
      );
      if (res.ok) {
        setDescription('');
        setAmount(0);
        setTxnRef('');
        setRemarks('');
      }
      return;
    }

    if (txnType === 'other_income') {
      const res = addOtherIncome({
        title: description,
        date,
        amount,
        paymentMode,
        remarks,
      });
      setFeedback(
        res.ok
          ? { type: 'success', message: `Deposit recorded (${res.receipt?.receiptNumber}).` }
          : { type: 'error', message: res.error ?? 'Failed to save.' }
      );
      if (res.ok) {
        setDescription('');
        setAmount(0);
        setRemarks('');
      }
    }
  };

  const txnTypes: { value: UniversalTxnType; label: string }[] = [
    { value: 'bc_collection', label: 'BC Collection' },
    { value: 'loan_emi', label: 'Loan EMI Payment' },
    { value: 'luckydraw_collection', label: 'Lucky Draw Collection' },
    { value: 'bc_payout', label: 'BC Winner Payout' },
    { value: 'luckydraw_payout', label: 'Lucky Draw Prize' },
    { value: 'expense', label: 'Expense Entry' },
    { value: 'other_income', label: 'Other Income / Deposit' },
  ];

  const isCollection = txnType === 'bc_collection' || txnType === 'luckydraw_collection';
  const isPayout = txnType === 'bc_payout' || txnType === 'luckydraw_payout';

  const filteredReceipts = useMemo(() => {
    const q = receiptSearch.trim().toLowerCase();
    return db.receipts.filter(
      (r) =>
        !q ||
        r.receiptNumber.toLowerCase().includes(q) ||
        r.partyName.toLowerCase().includes(q) ||
        (r.groupName ?? '').toLowerCase().includes(q)
    );
  }, [db.receipts, receiptSearch]);

  return (
    <div className="space-y-6 max-w-4xl">
      <SectionHeader
        title={lang === 'mr' ? 'पेमेंट्स व पावत्या (Payments & Receipts)' : 'Payments & Receipt Center'}
        subtitle={
          lang === 'mr'
            ? 'BC, लकी ड्रॉ, कर्ज EMI, खर्च आणि पावती इतिहास एकाच ठिकाणाहून हाताळा'
            : 'Receive BC, Lucky Draw & Loan EMI payments, issue vouchers, and reprint past receipts'
        }
        actions={
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => setViewMode('entry')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg ${
                viewMode === 'entry' ? 'bg-white text-[#002E6E] shadow-xs' : 'text-slate-600'
              }`}
            >
              Receive / Pay
            </button>
            <button
              type="button"
              onClick={() => setViewMode('receipts')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg ${
                viewMode === 'receipts' ? 'bg-white text-[#002E6E] shadow-xs' : 'text-slate-600'
              }`}
            >
              Receipt History ({db.receipts.length})
            </button>
          </div>
        }
      />

      {viewMode === 'entry' ? (
        <>
          {feedback && (
            <FormAlert
              type={feedback.type}
              message={feedback.message}
              onDismiss={() => setFeedback(null)}
            />
          )}

          <form
            onSubmit={handleSubmit}
            className="bg-white border border-slate-200 rounded-2xl p-6 space-y-6"
          >
            <div>
              <FieldLabel label="Transaction Type" required />
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {txnTypes.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => {
                      setTxnType(opt.value);
                      setFeedback(null);
                    }}
                    className={`px-3 py-2.5 text-xs font-semibold rounded-xl border text-left transition-colors ${
                      txnType === opt.value
                        ? 'bg-[#002E6E] text-white border-[#002E6E]'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
              <div>
                <FieldLabel
                  label={isPayout ? 'Auto Voucher #' : txnType === 'expense' ? 'Expense ID' : 'Auto Receipt #'}
                />
                <input
                  type="text"
                  readOnly
                  value={
                    isPayout
                      ? getNextVoucherNumber()
                      : txnType === 'expense'
                        ? 'Auto (EXP-XXXX)'
                        : getNextReceiptNumber()
                  }
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Payment Date" required />
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>

              {(txnType === 'bc_collection' || txnType === 'bc_payout') && (
                <div>
                  <FieldLabel label="BC Group" required />
                  <select
                    value={bcGroupId}
                    onChange={(e) => setBcGroupId(e.target.value)}
                    className={inputBaseClass}
                  >
                    {activeBCs.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.name} ({formatINR(g.monthlyInstallment)}/mo)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {(txnType === 'luckydraw_collection' || txnType === 'luckydraw_payout') && (
                <div>
                  <FieldLabel label="Lucky Draw Group" required />
                  <select
                    value={ldGroupId}
                    onChange={(e) => setLdGroupId(e.target.value)}
                    className={inputBaseClass}
                  >
                    {db.luckyDrawGroups.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.name} ({formatINR(g.monthlyInstallment)}/mo)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {(isCollection || isPayout) && (
                <div>
                  <FieldLabel label={isPayout ? 'Winner Member' : 'Member Name'} required />
                  <select
                    value={memberId}
                    onChange={(e) => setMemberId(e.target.value)}
                    className={inputBaseClass}
                  >
                    {(txnType.startsWith('bc_') ? bcMembers : ldMembers).map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.id})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {txnType === 'loan_emi' && (
                <>
                  <div>
                    <FieldLabel label="Select Loan Account" required />
                    <select
                      value={loanId}
                      onChange={(e) => setLoanId(e.target.value)}
                      className={inputBaseClass}
                    >
                      {db.loans.map((l) => (
                        <option key={l.id} value={l.id}>
                          {l.id} — {l.customerName} (Bal: {formatINR(l.principalOutstanding)})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <FieldLabel label="EMI Amount Paid (₹)" required />
                    <input
                      type="number"
                      min={1}
                      step="0.01"
                      required
                      value={emiAmount}
                      onChange={(e) => setEmiAmount(Number(e.target.value))}
                      className={monoInputClass}
                    />
                  </div>
                  <div>
                    <FieldLabel label="Late Fee (₹)" />
                    <input
                      type="number"
                      min={0}
                      value={lateFee}
                      onChange={(e) => setLateFee(Number(e.target.value))}
                      className={monoInputClass}
                    />
                  </div>
                </>
              )}

              {isCollection && (
                <>
                  <div>
                    <FieldLabel label="Installment Number" required />
                    <input
                      type="number"
                      min={1}
                      required
                      value={installmentNumber}
                      onChange={(e) => setInstallmentNumber(Math.max(1, Number(e.target.value)))}
                      className={monoInputClass}
                    />
                  </div>
                  <div>
                    <FieldLabel label="Installment Amount (₹)" required />
                    <input
                      type="number"
                      min={0}
                      required
                      value={installmentAmount}
                      onChange={(e) => setInstallmentAmount(Number(e.target.value))}
                      className={monoInputClass}
                    />
                  </div>
                  {txnType === 'bc_collection' && (
                    <div>
                      <FieldLabel label="Dividend Deduction (₹)" />
                      <input
                        type="number"
                        min={0}
                        value={dividendDeduction}
                        onChange={(e) => setDividendDeduction(Number(e.target.value))}
                        className={monoInputClass}
                      />
                    </div>
                  )}
                  <div>
                    <FieldLabel label="Late Fee (₹)" />
                    <input
                      type="number"
                      min={0}
                      value={lateFee}
                      onChange={(e) => setLateFee(Number(e.target.value))}
                      className={monoInputClass}
                    />
                  </div>
                </>
              )}

              {isPayout && (
                <>
                  {txnType === 'luckydraw_payout' && (
                    <div>
                      <FieldLabel label="Draw Number" required />
                      <input
                        type="number"
                        min={1}
                        required
                        value={drawNumber}
                        onChange={(e) => setDrawNumber(Math.max(1, Number(e.target.value)))}
                        className={monoInputClass}
                      />
                    </div>
                  )}
                  <div>
                    <FieldLabel label="Total / Prize Amount (₹)" required />
                    <input
                      type="number"
                      min={0}
                      required
                      value={totalPayable}
                      onChange={(e) => setTotalPayable(Number(e.target.value))}
                      className={monoInputClass}
                    />
                  </div>
                  <div>
                    <FieldLabel label="Deduction (₹)" />
                    <input
                      type="number"
                      min={0}
                      value={deduction}
                      onChange={(e) => setDeduction(Number(e.target.value))}
                      className={monoInputClass}
                    />
                  </div>
                  <div>
                    <FieldLabel label="Payment Status" required />
                    <select
                      value={paymentStatus}
                      onChange={(e) => setPaymentStatus(e.target.value as PaymentStatus)}
                      className={inputBaseClass}
                    >
                      <option value="Paid">Paid</option>
                      <option value="Pending">Pending</option>
                    </select>
                  </div>
                </>
              )}

              {txnType === 'expense' && (
                <>
                  <div>
                    <FieldLabel label="Category" required />
                    <select
                      value={expenseCategory}
                      onChange={(e) => setExpenseCategory(e.target.value as ExpenseCategory)}
                      className={inputBaseClass}
                    >
                      {EXPENSE_CATEGORIES.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <FieldLabel label="Linked Account" />
                    <select
                      value={expenseLinkKind}
                      onChange={(e) => {
                        const next = e.target.value as 'general' | 'bc' | 'luckydraw';
                        setExpenseLinkKind(next);
                        setExpenseLinkGroupId(
                          next === 'bc'
                            ? activeBCs[0]?.id ?? ''
                            : next === 'luckydraw'
                              ? db.luckyDrawGroups[0]?.id ?? ''
                              : ''
                        );
                      }}
                      className={inputBaseClass}
                    >
                      <option value="general">General Office</option>
                      <option value="bc">BC Group</option>
                      <option value="luckydraw">Lucky Draw</option>
                    </select>
                  </div>
                  {expenseLinkKind !== 'general' && (
                    <div>
                      <FieldLabel label="Select Group" />
                      <select
                        value={expenseLinkGroupId}
                        onChange={(e) => setExpenseLinkGroupId(e.target.value)}
                        className={inputBaseClass}
                      >
                        {(expenseLinkKind === 'bc' ? activeBCs : db.luckyDrawGroups).map((g) => (
                          <option key={g.id} value={g.id}>
                            {g.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                  <div>
                    <FieldLabel label="Description" required />
                    <input
                      type="text"
                      required
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className={inputBaseClass}
                    />
                  </div>
                  <div>
                    <FieldLabel label="Amount (₹)" required />
                    <input
                      type="number"
                      min={1}
                      required
                      value={amount}
                      onChange={(e) => setAmount(Number(e.target.value))}
                      className={monoInputClass}
                    />
                  </div>
                </>
              )}

              {txnType === 'other_income' && (
                <>
                  <div>
                    <FieldLabel label="Income Title" required />
                    <input
                      type="text"
                      required
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className={inputBaseClass}
                    />
                  </div>
                  <div>
                    <FieldLabel label="Amount (₹)" required />
                    <input
                      type="number"
                      min={1}
                      required
                      value={amount}
                      onChange={(e) => setAmount(Number(e.target.value))}
                      className={monoInputClass}
                    />
                  </div>
                </>
              )}

              <div>
                <FieldLabel label="Payment Mode" required />
                <div className="grid grid-cols-3 gap-2">
                  {(['Cash', 'UPI', 'Bank'] as PaymentMode[]).map((mode) => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => setPaymentMode(mode)}
                      className={`min-h-[44px] text-xs font-semibold rounded-xl border transition-colors ${
                        paymentMode === mode
                          ? 'bg-[#002E6E] text-white border-[#002E6E]'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <FieldLabel label="Transaction Reference" />
                <input
                  type="text"
                  value={txnRef}
                  onChange={(e) => setTxnRef(e.target.value)}
                  placeholder="UPI / UTR / Bill #"
                  className={monoInputClass}
                />
              </div>

              <div className="md:col-span-2">
                <FieldLabel label="Remarks" />
                <input
                  type="text"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="Optional payment note"
                  className={inputBaseClass}
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pt-4 border-t border-slate-200">
              <div>
                <span className="text-xs text-slate-500">Auto-Calculated Net Amount</span>
                <p className="text-xl font-bold text-[#002E6E] font-mono-num">
                  {formatINR(
                    txnType === 'bc_collection'
                      ? calculatedNetCollection
                      : txnType === 'luckydraw_collection'
                        ? calculatedNetLDCollection
                        : txnType === 'loan_emi'
                          ? emiAmount + lateFee
                          : isPayout
                            ? calculatedNetPayout
                            : amount
                  )}
                </p>
              </div>
              <button
                type="submit"
                className="px-6 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl transition-colors"
              >
                Save &amp; Generate Receipt
              </button>
            </div>
          </form>
        </>
      ) : (
        /* RECEIPT HISTORY & REPRINT */
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 border-b border-slate-200">
            <h3 className="text-sm font-bold text-[#002E6E]">
              Receipt &amp; Voucher History ({filteredReceipts.length})
            </h3>
            <div className="relative min-w-[220px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={receiptSearch}
                onChange={(e) => setReceiptSearch(e.target.value)}
                placeholder="Search receipt # or name..."
                className={`${inputBaseClass} pl-9 min-h-[38px] text-xs`}
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                  <th className="py-2.5 px-4">Receipt #</th>
                  <th className="py-2.5 px-4">Date</th>
                  <th className="py-2.5 px-4">Member / Party</th>
                  <th className="py-2.5 px-4">Type</th>
                  <th className="py-2.5 px-4">Mode</th>
                  <th className="py-2.5 px-4 text-right">Amount</th>
                  <th className="py-2.5 px-4 text-right">Reprint</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredReceipts.map((r) => (
                  <tr key={r.receiptNumber} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono-num font-semibold">{r.receiptNumber}</td>
                    <td className="py-3 px-4 font-mono-num">{formatDateOnly(r.date)}</td>
                    <td className="py-3 px-4 font-medium">{r.partyName}</td>
                    <td className="py-3 px-4 text-slate-600">{r.paymentType ?? r.title}</td>
                    <td className="py-3 px-4">{r.paymentMode}</td>
                    <td className="py-3 px-4 text-right font-mono-num font-semibold text-[#002E6E]">
                      {formatINR(r.totalAmount)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => setActiveReceipt(r)}
                        className="inline-flex items-center gap-1 text-[#0070E0] font-semibold hover:underline"
                      >
                        <ReceiptText className="w-3.5 h-3.5" />
                        <span>Reprint / Share</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
