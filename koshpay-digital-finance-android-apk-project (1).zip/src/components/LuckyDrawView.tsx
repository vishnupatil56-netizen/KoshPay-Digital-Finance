import React, { useEffect, useMemo, useState } from 'react';
import { Dices, Download, ReceiptText, ShieldCheck } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { BCStatus, DrawType, PaymentMode, PaymentStatus, RecordStatus } from '../types/finance';
import { exportToCSV, formatDateOnly, formatDateTime, formatINR, generateNextId, todayISO } from '../utils/formatters';
import { FieldLabel, FormAlert, SectionHeader, inputBaseClass, monoInputClass } from './FormControls';

type LDTab = 'draw_entry' | 'collection' | 'member' | 'create' | 'ledger';

export const LuckyDrawView: React.FC = () => {
  const {
    db,
    lang,
    getNextReceiptNumber,
    getNextVoucherNumber,
    getLuckyDrawLedger,
    addLuckyDrawGroup,
    addMember,
    enrollExistingMember,
    addLuckyDrawCollection,
    addLuckyDrawEntry,
    setActiveReceipt,
  } = useFinance();

  const [activeTab, setActiveTab] = useState<LDTab>('draw_entry');
  const [feedback, setFeedback] = useState<{ type: 'error' | 'success'; message: string } | null>(null);

  // --- Form 2A: Create Lucky Draw ---
  const [ldName, setLdName] = useState('');
  const [drawType, setDrawType] = useState<DrawType>('150 Members');
  const [ldTotalMembers, setLdTotalMembers] = useState(150);
  const [ldMonthlyInst, setLdMonthlyInst] = useState(1000);
  const [ldTotalMonths, setLdTotalMonths] = useState(15);
  const [ldTotalDrawAmount, setLdTotalDrawAmount] = useState(150000);
  const [ldPrizeAmount, setLdPrizeAmount] = useState(25000);
  const [ldStartDate, setLdStartDate] = useState(todayISO());
  const [ldMonthlyDate, setLdMonthlyDate] = useState(15);
  const [ldRules, setLdRules] = useState('Monthly transparent draw. Past winners remain tracked.');
  const [ldStatus, setLdStatus] = useState<BCStatus>('Active');

  const nextDrawGroupId = useMemo(
    () => generateNextId('LD', db.luckyDrawGroups.map((g) => g.id), 3),
    [db.luckyDrawGroups]
  );

  const handleCreateLD = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const res = addLuckyDrawGroup({
      name: ldName,
      drawType,
      totalMembers: ldTotalMembers,
      monthlyInstallment: ldMonthlyInst,
      totalMonths: ldTotalMonths,
      totalDrawAmount: ldTotalDrawAmount,
      prizeAmount: ldPrizeAmount,
      startDate: ldStartDate,
      monthlyDrawDate: ldMonthlyDate,
      rulesAndConditions: ldRules,
      status: ldStatus,
    });
    if (res.ok) {
      setFeedback({ type: 'success', message: `Lucky Draw "${ldName}" (${res.id}) created.` });
      setLdName('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Failed to create Lucky Draw.' });
    }
  };

  // --- Form 2B: Lucky Draw Member Form ---
  const [ldRegMode, setLdRegMode] = useState<'new' | 'existing'>('new');
  const [existingMemId, setExistingMemId] = useState(db.members[0]?.id ?? '');
  const [memName, setMemName] = useState('');
  const [memMobile, setMemMobile] = useState('');
  const [memAddress, setMemAddress] = useState('');
  const [memJoinDate, setMemJoinDate] = useState(todayISO());
  const [memLdId, setMemLdId] = useState(db.luckyDrawGroups[0]?.id ?? '');
  const [memNumber, setMemNumber] = useState(103);
  const [memMonthlyInst, setMemMonthlyInst] = useState(1000);
  const [memTotalInst, setMemTotalInst] = useState(15);
  const [memStatus, setMemStatus] = useState<RecordStatus>('Active');
  const [memRemarks, setMemRemarks] = useState('');

  useEffect(() => {
    const grp = db.luckyDrawGroups.find((g) => g.id === memLdId);
    if (grp) {
      setMemMonthlyInst(grp.monthlyInstallment);
      setMemTotalInst(grp.totalMonths);
      const taken = db.enrollments
        .filter((e) => e.groupKind === 'luckydraw' && e.groupId === memLdId)
        .map((e) => e.memberNumber ?? 0);
      const nextSlot = taken.length > 0 ? Math.max(...taken) + 1 : 1;
      setMemNumber(nextSlot);
    }
  }, [memLdId, db.luckyDrawGroups, db.enrollments]);

  const nextAutoMemberId = useMemo(
    () => generateNextId('MEM', db.members.map((m) => m.id), 4),
    [db.members]
  );

  const handleSaveLDMember = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!memLdId) {
      setFeedback({ type: 'error', message: 'Please select a Lucky Draw Group.' });
      return;
    }

    if (ldRegMode === 'existing') {
      const res = enrollExistingMember({
        groupKind: 'luckydraw',
        groupId: memLdId,
        memberId: existingMemId,
        memberNumber: memNumber,
        joiningDate: memJoinDate,
        monthlyInstallment: memMonthlyInst,
        totalInstallments: memTotalInst,
        status: memStatus,
        remarks: memRemarks,
      });
      setFeedback(
        res.ok
          ? { type: 'success', message: `Member enrolled with Token #${memNumber}.` }
          : { type: 'error', message: res.error ?? 'Failed to enroll.' }
      );
      return;
    }

    const res = addMember(
      {
        name: memName,
        mobile: memMobile,
        address: memAddress,
        joiningDate: memJoinDate,
        category: 'Lucky Draw',
        initialBalance: 0,
        status: memStatus,
      },
      {
        groupKind: 'luckydraw',
        groupId: memLdId,
        memberNumber: memNumber,
        joiningDate: memJoinDate,
        monthlyInstallment: memMonthlyInst,
        totalInstallments: memTotalInst,
        remarks: memRemarks,
      }
    );
    if (res.ok) {
      setFeedback({
        type: 'success',
        message: `Lucky Draw Member ${memName} (${res.id}) added with Token #${memNumber}.`,
      });
      setMemName('');
      setMemMobile('');
      setMemAddress('');
      setMemRemarks('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Could not save member.' });
    }
  };

  // --- Lucky Draw Collection + Pending Tracker ---
  const [colLdId, setColLdId] = useState(db.luckyDrawGroups[0]?.id ?? '');
  const [colMemId, setColMemId] = useState('');
  const [colInstNo, setColInstNo] = useState(1);
  const [colDate, setColDate] = useState(todayISO());
  const [colAmt, setColAmt] = useState(1000);
  const [colLateFee, setColLateFee] = useState(0);
  const [colMode, setColMode] = useState<PaymentMode>('Cash');
  const [colTxnRef, setColTxnRef] = useState('');
  const [colRemarks, setColRemarks] = useState('');

  const colEnrolled = useMemo(() => {
    const ids = new Set(
      db.enrollments
        .filter((e) => e.groupKind === 'luckydraw' && e.groupId === colLdId)
        .map((e) => e.memberId)
    );
    return db.members.filter((m) => !m.isDeleted && ids.has(m.id));
  }, [db.enrollments, db.members, colLdId]);

  const pendingForInst = useMemo(() => {
    const paid = new Set(
      db.luckyDrawCollections
        .filter((c) => c.luckyDrawId === colLdId && c.installmentNumber === colInstNo)
        .map((c) => c.memberId)
    );
    return colEnrolled.filter((m) => !paid.has(m.id));
  }, [db.luckyDrawCollections, colLdId, colInstNo, colEnrolled]);

  useEffect(() => {
    const grp = db.luckyDrawGroups.find((g) => g.id === colLdId);
    if (grp) setColAmt(grp.monthlyInstallment);
    if (colEnrolled.length > 0 && !colEnrolled.some((m) => m.id === colMemId)) {
      setColMemId(colEnrolled[0].id);
    }
  }, [colLdId, db.luckyDrawGroups, colEnrolled, colMemId]);

  const handleSaveLDCollection = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!colLdId || !colMemId) {
      setFeedback({ type: 'error', message: 'Select Lucky Draw Group and Member.' });
      return;
    }
    const res = addLuckyDrawCollection({
      luckyDrawId: colLdId,
      memberId: colMemId,
      installmentNumber: colInstNo,
      collectionDate: colDate,
      installmentAmount: colAmt,
      lateFee: colLateFee,
      totalReceived: Math.max(0, colAmt + colLateFee),
      paymentMode: colMode,
      transactionRef: colTxnRef,
      remarks: colRemarks,
    });
    if (res.ok) {
      setFeedback({
        type: 'success',
        message: `Lucky Draw Receipt ${res.receipt?.receiptNumber} created.`,
      });
      setColTxnRef('');
      setColRemarks('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Failed to record collection.' });
    }
  };

  // --- Form 2C: Authorized Winner Draw Entry ---
  const [drawLdId, setDrawLdId] = useState(db.luckyDrawGroups[0]?.id ?? '');
  const [drawNumber, setDrawNumber] = useState(2);
  const [drawDate, setDrawDate] = useState(todayISO());
  const [drawTotalMembers, setDrawTotalMembers] = useState(150);
  const [winnerMemberId, setWinnerMemberId] = useState('');
  const [prizeAmount, setPrizeAmount] = useState(25000);
  const [deduction, setDeduction] = useState(0);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('Paid');
  const [paymentDate, setPaymentDate] = useState(todayISO());
  const [drawPayMode, setDrawPayMode] = useState<PaymentMode>('UPI');
  const [authorizedBy, setAuthorizedBy] = useState(db.settings.authorizedSignatory);
  const [authorizeConfirmed, setAuthorizeConfirmed] = useState(false);
  const [drawRemarks, setDrawRemarks] = useState('');

  const drawMembers = useMemo(() => {
    const ids = new Set(
      db.enrollments
        .filter((e) => e.groupKind === 'luckydraw' && e.groupId === drawLdId)
        .map((e) => e.memberId)
    );
    const list = db.members.filter((m) => !m.isDeleted && ids.has(m.id));
    return list.length > 0 ? list : db.members.filter((m) => !m.isDeleted);
  }, [db.enrollments, db.members, drawLdId]);

  useEffect(() => {
    const grp = db.luckyDrawGroups.find((g) => g.id === drawLdId);
    if (grp) {
      setDrawTotalMembers(grp.totalMembers);
      setPrizeAmount(grp.prizeAmount);
      const count = db.luckyDrawEntries.filter((e) => e.luckyDrawId === drawLdId).length;
      setDrawNumber(count + 1);
    }
    if (drawMembers.length > 0 && !drawMembers.some((m) => m.id === winnerMemberId)) {
      setWinnerMemberId(drawMembers[0].id);
    }
  }, [drawLdId, db.luckyDrawGroups, db.luckyDrawEntries, drawMembers, winnerMemberId]);

  const netPrizeAmount = Math.max(0, prizeAmount - deduction);
  const selectedWinner = db.members.find((m) => m.id === winnerMemberId);

  const handleRandomCandidatePreview = () => {
    if (drawMembers.length === 0) return;
    const pastWinners = new Set(
      db.luckyDrawEntries.filter((e) => e.luckyDrawId === drawLdId).map((e) => e.winnerMemberId)
    );
    const eligible = drawMembers.filter((m) => !pastWinners.has(m.id));
    const pool = eligible.length > 0 ? eligible : drawMembers;
    const picked = pool[Math.floor(Math.random() * pool.length)];
    setWinnerMemberId(picked.id);
    // Notice: Never auto-declares winner; user must authorize and submit explicitly!
    setAuthorizeConfirmed(false);
  };

  const handleSaveDrawEntry = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!authorizeConfirmed) {
      setFeedback({
        type: 'error',
        message: 'Transparent Draw Rule: Check the Authorization confirmation box before declaring a winner.',
      });
      return;
    }
    if (!drawLdId || !winnerMemberId) {
      setFeedback({ type: 'error', message: 'Please select Lucky Draw Group and Winner.' });
      return;
    }
    const res = addLuckyDrawEntry({
      drawNumber,
      drawDate,
      luckyDrawId: drawLdId,
      totalMembers: drawTotalMembers,
      winnerMemberId,
      prizeAmount,
      deduction,
      netPrizeAmount,
      paymentStatus,
      paymentDate,
      paymentMode: drawPayMode,
      authorizedBy,
      remarks: drawRemarks,
    });
    if (res.ok) {
      setFeedback({
        type: 'success',
        message: `Draw #${drawNumber} authorized & saved (${res.receipt?.receiptNumber}).`,
      });
      setAuthorizeConfirmed(false);
      setDrawRemarks('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Failed to save draw entry.' });
    }
  };

  const [ledgerLdId, setLedgerLdId] = useState(db.luckyDrawGroups[0]?.id ?? '');
  const ldLedgerData = getLuckyDrawLedger(ledgerLdId);

  const tabs: { id: LDTab; label: string }[] = [
    { id: 'draw_entry', label: lang === 'mr' ? 'अधिकृत विजेता नोंद' : 'Authorized Draw & Winner' },
    { id: 'collection', label: lang === 'mr' ? 'हप्ता वसुली व बाकी' : 'Collection & Pending' },
    { id: 'member', label: lang === 'mr' ? 'लकी ड्रॉ सभासद' : 'LD Members' },
    { id: 'create', label: lang === 'mr' ? 'नवीन लकी ड्रॉ' : 'Create Lucky Draw' },
    { id: 'ledger', label: lang === 'mr' ? 'स्वतंत्र ड्रॉ खातेवही' : 'Lucky Draw Ledger' },
  ];

  return (
    <div className="space-y-6">
      <SectionHeader
        title={lang === 'mr' ? 'लकी ड्रॉ व्यवस्थापन (Lucky Draw)' : 'Lucky Draw Management'}
        subtitle={
          lang === 'mr'
            ? 'पारदर्शक व अधिकृत विजेता निवड, टोकन नोंदणी, हप्ता वसुली, बक्षीस वाटप आणि स्वतंत्र खातेवही'
            : 'Transparent authorized winner selection, token enrollment, pending tracking, prize distribution & per-draw ledger'
        }
      />

      <div className="flex flex-wrap gap-1.5 p-1.5 bg-slate-100 rounded-xl no-print">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => {
              setActiveTab(tab.id);
              setFeedback(null);
            }}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-white text-[#002E6E] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {feedback && (
        <FormAlert
          type={feedback.type}
          message={feedback.message}
          onDismiss={() => setFeedback(null)}
        />
      )}

      {/* CREATE LUCKY DRAW */}
      {activeTab === 'create' && (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <form
            onSubmit={handleCreateLD}
            className="lg:col-span-3 bg-white border border-slate-200 rounded-2xl p-6 space-y-4"
          >
            <h3 className="text-base font-bold text-[#002E6E] font-display">
              Lucky Draw Creation Form
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <FieldLabel label="Draw ID (Auto Generated)" />
                <input type="text" readOnly value={nextDrawGroupId} className={monoInputClass} />
              </div>

              <div>
                <FieldLabel label="Status" required />
                <select
                  value={ldStatus}
                  onChange={(e) => setLdStatus(e.target.value as BCStatus)}
                  className={inputBaseClass}
                >
                  <option value="Active">Active</option>
                  <option value="Completed">Completed</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <FieldLabel label="Lucky Draw Name" required />
                <input
                  type="text"
                  required
                  value={ldName}
                  onChange={(e) => setLdName(e.target.value)}
                  placeholder="e.g. Suvarna 150-Member Draw"
                  className={inputBaseClass}
                />
              </div>

              <div>
                <FieldLabel label="Draw Type" required />
                <select
                  value={drawType}
                  onChange={(e) => {
                    const next = e.target.value as DrawType;
                    setDrawType(next);
                    if (next === '150 Members') setLdTotalMembers(150);
                  }}
                  className={inputBaseClass}
                >
                  <option value="150 Members">150 Members</option>
                  <option value="Custom">Custom</option>
                </select>
              </div>

              <div>
                <FieldLabel label="Total Members" required />
                <input
                  type="number"
                  min={2}
                  required
                  value={ldTotalMembers}
                  onChange={(e) => {
                    const m = Math.max(2, Number(e.target.value));
                    setLdTotalMembers(m);
                    setLdTotalDrawAmount(m * ldMonthlyInst);
                  }}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Monthly Installment (₹)" required />
                <input
                  type="number"
                  min={50}
                  required
                  value={ldMonthlyInst}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setLdMonthlyInst(val);
                    setLdTotalDrawAmount(ldTotalMembers * val);
                  }}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Total Months" required />
                <input
                  type="number"
                  min={1}
                  required
                  value={ldTotalMonths}
                  onChange={(e) => setLdTotalMonths(Math.max(1, Number(e.target.value)))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Total Draw Amount (₹)" required />
                <input
                  type="number"
                  required
                  value={ldTotalDrawAmount}
                  onChange={(e) => setLdTotalDrawAmount(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Monthly Prize Amount (₹)" required />
                <input
                  type="number"
                  required
                  value={ldPrizeAmount}
                  onChange={(e) => setLdPrizeAmount(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Start Date" required />
                <input
                  type="date"
                  required
                  value={ldStartDate}
                  onChange={(e) => setLdStartDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Monthly Draw Day (1–28)" required />
                <input
                  type="number"
                  min={1}
                  max={28}
                  required
                  value={ldMonthlyDate}
                  onChange={(e) =>
                    setLdMonthlyDate(Math.min(28, Math.max(1, Number(e.target.value))))
                  }
                  className={monoInputClass}
                />
              </div>

              <div className="sm:col-span-2">
                <FieldLabel label="Rules and Conditions" />
                <textarea
                  rows={2}
                  value={ldRules}
                  onChange={(e) => setLdRules(e.target.value)}
                  className={`${inputBaseClass} min-h-[68px]`}
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
              >
                Save Lucky Draw
              </button>
            </div>
          </form>

          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 space-y-3 self-start">
            <h3 className="text-sm font-bold text-[#002E6E] font-display">
              Lucky Draw Groups ({db.luckyDrawGroups.length})
            </h3>
            <div className="divide-y divide-slate-100">
              {db.luckyDrawGroups.map((g) => (
                <div key={g.id} className="py-3 first:pt-0 last:pb-0">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-900">{g.name}</span>
                    <span className="text-xs font-mono-num text-slate-500">{g.id}</span>
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    {g.totalMembers} Members · {formatINR(g.monthlyInstallment)}/mo · Prize{' '}
                    {formatINR(g.prizeAmount)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* LUCKY DRAW MEMBER FORM */}
      {activeTab === 'member' && (
        <form
          onSubmit={handleSaveLDMember}
          className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5 max-w-3xl"
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <h3 className="text-base font-bold text-[#002E6E] font-display">
              Lucky Draw Member Registration
            </h3>
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl self-start">
              <button
                type="button"
                onClick={() => setLdRegMode('new')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg ${
                  ldRegMode === 'new' ? 'bg-white text-[#002E6E] shadow-xs' : 'text-slate-600'
                }`}
              >
                New Member
              </button>
              <button
                type="button"
                onClick={() => setLdRegMode('existing')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg ${
                  ldRegMode === 'existing' ? 'bg-white text-[#002E6E] shadow-xs' : 'text-slate-600'
                }`}
              >
                Enroll Existing
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {ldRegMode === 'new' ? (
              <>
                <div>
                  <FieldLabel label="Member ID (Auto)" />
                  <input type="text" readOnly value={nextAutoMemberId} className={monoInputClass} />
                </div>
                <div>
                  <FieldLabel label="Member Name" required />
                  <input
                    type="text"
                    required
                    value={memName}
                    onChange={(e) => setMemName(e.target.value)}
                    className={inputBaseClass}
                  />
                </div>
                <div>
                  <FieldLabel label="Mobile Number" required />
                  <input
                    type="tel"
                    required
                    value={memMobile}
                    onChange={(e) => setMemMobile(e.target.value)}
                    className={monoInputClass}
                  />
                </div>
                <div>
                  <FieldLabel label="Address" required />
                  <input
                    type="text"
                    required
                    value={memAddress}
                    onChange={(e) => setMemAddress(e.target.value)}
                    className={inputBaseClass}
                  />
                </div>
              </>
            ) : (
              <div className="sm:col-span-2">
                <FieldLabel label="Select Existing Member" required />
                <select
                  value={existingMemId}
                  onChange={(e) => setExistingMemId(e.target.value)}
                  className={inputBaseClass}
                >
                  {db.members
                    .filter((m) => !m.isDeleted)
                    .map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.id} · {m.mobile})
                      </option>
                    ))}
                </select>
              </div>
            )}

            <div>
              <FieldLabel label="Lucky Draw Group" required />
              <select
                value={memLdId}
                onChange={(e) => setMemLdId(e.target.value)}
                className={inputBaseClass}
              >
                {db.luckyDrawGroups.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <FieldLabel label="Member Token #" required />
              <input
                type="number"
                min={1}
                required
                value={memNumber}
                onChange={(e) => setMemNumber(Math.max(1, Number(e.target.value)))}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Joining Date" required />
              <input
                type="date"
                required
                value={memJoinDate}
                onChange={(e) => setMemJoinDate(e.target.value)}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Monthly Installment (₹)" required />
              <input
                type="number"
                required
                value={memMonthlyInst}
                onChange={(e) => setMemMonthlyInst(Number(e.target.value))}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Total Installments" required />
              <input
                type="number"
                required
                value={memTotalInst}
                onChange={(e) => setMemTotalInst(Number(e.target.value))}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Status" required />
              <select
                value={memStatus}
                onChange={(e) => setMemStatus(e.target.value as RecordStatus)}
                className={inputBaseClass}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
            <div className="sm:col-span-2">
              <FieldLabel label="Remarks" />
              <input
                type="text"
                value={memRemarks}
                onChange={(e) => setMemRemarks(e.target.value)}
                className={inputBaseClass}
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
            >
              Save Lucky Draw Member
            </button>
          </div>
        </form>
      )}

      {/* LUCKY DRAW COLLECTION & PENDING */}
      {activeTab === 'collection' && (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <form
            onSubmit={handleSaveLDCollection}
            className="lg:col-span-3 bg-white border border-slate-200 rounded-2xl p-6 space-y-5"
          >
            <h3 className="text-base font-bold text-[#002E6E] font-display">
              Lucky Draw Monthly Collection
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <FieldLabel label="Receipt Number (Auto)" />
                <input type="text" readOnly value={getNextReceiptNumber()} className={monoInputClass} />
              </div>
              <div>
                <FieldLabel label="Collection Date" required />
                <input
                  type="date"
                  required
                  value={colDate}
                  onChange={(e) => setColDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Lucky Draw Group" required />
                <select
                  value={colLdId}
                  onChange={(e) => setColLdId(e.target.value)}
                  className={inputBaseClass}
                >
                  {db.luckyDrawGroups.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <FieldLabel label="Member Name" required />
                <select
                  value={colMemId}
                  onChange={(e) => setColMemId(e.target.value)}
                  className={inputBaseClass}
                >
                  {colEnrolled.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.id})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <FieldLabel label="Installment Number" required />
                <input
                  type="number"
                  min={1}
                  required
                  value={colInstNo}
                  onChange={(e) => setColInstNo(Math.max(1, Number(e.target.value)))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Installment Amount (₹)" required />
                <input
                  type="number"
                  min={0}
                  required
                  value={colAmt}
                  onChange={(e) => setColAmt(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Late Fee (₹)" />
                <input
                  type="number"
                  min={0}
                  value={colLateFee}
                  onChange={(e) => setColLateFee(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Payment Mode" required />
                <select
                  value={colMode}
                  onChange={(e) => setColMode(e.target.value as PaymentMode)}
                  className={inputBaseClass}
                >
                  <option value="Cash">Cash</option>
                  <option value="UPI">UPI</option>
                  <option value="Bank">Bank</option>
                </select>
              </div>
              <div>
                <FieldLabel label="Transaction Ref" />
                <input
                  type="text"
                  value={colTxnRef}
                  onChange={(e) => setColTxnRef(e.target.value)}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Remarks" />
                <input
                  type="text"
                  value={colRemarks}
                  onChange={(e) => setColRemarks(e.target.value)}
                  className={inputBaseClass}
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pt-4 border-t border-slate-200">
              <div>
                <span className="text-xs text-slate-500">Total Received</span>
                <p className="text-xl font-bold text-emerald-700 font-mono-num">
                  {formatINR(colAmt + colLateFee)}
                </p>
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
              >
                Save &amp; Issue Receipt
              </button>
            </div>
          </form>

          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 space-y-3 self-start">
            <h3 className="text-sm font-bold text-[#002E6E] font-display">
              Pending Payments — Month #{colInstNo}
            </h3>
            <p className="text-xs text-slate-500">
              {pendingForInst.length} of {colEnrolled.length} enrolled members pending
            </p>
            <div className="divide-y divide-slate-100">
              {pendingForInst.length === 0 ? (
                <p className="py-4 text-xs text-emerald-700 font-medium">
                  All enrolled members have paid Month #{colInstNo}.
                </p>
              ) : (
                pendingForInst.map((m) => (
                  <div key={m.id} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                    <div>
                      <div className="font-semibold text-slate-900">{m.name}</div>
                      <div className="text-slate-500 font-mono-num">{m.id}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setColMemId(m.id)}
                      className="px-3 py-1.5 text-xs font-semibold text-[#0070E0] bg-blue-50 hover:bg-blue-100 rounded-lg"
                    >
                      Collect
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* AUTHORIZED WINNER DRAW ENTRY */}
      {activeTab === 'draw_entry' && (
        <div className="space-y-6">
          <form
            onSubmit={handleSaveDrawEntry}
            className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5 max-w-3xl"
          >
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-[#002E6E] font-display">
                  Authorized Draw &amp; Winner Selection
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Winners are never auto-declared; an explicit Authorized Draw Officer sign-off is required.
                </p>
              </div>
              <button
                type="button"
                onClick={handleRandomCandidatePreview}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#0070E0] bg-blue-50 hover:bg-blue-100 rounded-xl self-start"
              >
                <Dices className="w-3.5 h-3.5" />
                <span>Spin Eligible Candidate</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <FieldLabel label="Voucher Number (Auto)" />
                <input type="text" readOnly value={getNextVoucherNumber()} className={monoInputClass} />
              </div>
              <div>
                <FieldLabel label="Lucky Draw Group" required />
                <select
                  value={drawLdId}
                  onChange={(e) => setDrawLdId(e.target.value)}
                  className={inputBaseClass}
                >
                  {db.luckyDrawGroups.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <FieldLabel label="Draw Number" required />
                <input
                  type="number"
                  min={1}
                  required
                  value={drawNumber}
                  onChange={(e) => setDrawNumber(Math.max(1, Number(e.target.value)))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Draw Date" required />
                <input
                  type="date"
                  required
                  value={drawDate}
                  onChange={(e) => setDrawDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Winner Member" required />
                <select
                  value={winnerMemberId}
                  onChange={(e) => setWinnerMemberId(e.target.value)}
                  className={inputBaseClass}
                >
                  {drawMembers.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.id})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <FieldLabel label="Prize Amount (₹)" required />
                <input
                  type="number"
                  min={0}
                  required
                  value={prizeAmount}
                  onChange={(e) => setPrizeAmount(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Deduction (₹)" />
                <input
                  type="number"
                  min={0}
                  value={deduction}
                  onChange={(e) => setDeduction(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Payment Status" required />
                <select
                  value={paymentStatus}
                  onChange={(e) => setPaymentStatus(e.target.value as PaymentStatus)}
                  className={inputBaseClass}
                >
                  <option value="Paid">Paid</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>
              <div>
                <FieldLabel label="Payment Date" required />
                <input
                  type="date"
                  required
                  value={paymentDate}
                  onChange={(e) => setPaymentDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Payment Mode" required />
                <select
                  value={drawPayMode}
                  onChange={(e) => setDrawPayMode(e.target.value as PaymentMode)}
                  className={inputBaseClass}
                >
                  <option value="UPI">UPI</option>
                  <option value="Cash">Cash</option>
                  <option value="Bank">Bank</option>
                </select>
              </div>
              <div>
                <FieldLabel label="Authorized Draw Officer" required />
                <input
                  type="text"
                  required
                  value={authorizedBy}
                  onChange={(e) => setAuthorizedBy(e.target.value)}
                  className={inputBaseClass}
                />
              </div>
              <div>
                <FieldLabel label="Remarks" />
                <input
                  type="text"
                  value={drawRemarks}
                  onChange={(e) => setDrawRemarks(e.target.value)}
                  className={inputBaseClass}
                />
              </div>
            </div>

            {/* Explicit Draw Authorization Gate */}
            <label className="flex items-start gap-3 p-3.5 bg-blue-50 border border-blue-200 rounded-xl cursor-pointer">
              <input
                type="checkbox"
                checked={authorizeConfirmed}
                onChange={(e) => setAuthorizeConfirmed(e.target.checked)}
                className="mt-1 w-4 h-4 accent-[#0070E0]"
              />
              <span className="text-xs text-[#002E6E] font-medium">
                I authorize Draw #{drawNumber} for <strong>{selectedWinner?.name ?? winnerMemberId}</strong> and confirm this result will be permanently logged in the audit trail.
              </span>
            </label>

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pt-4 border-t border-slate-200">
              <div>
                <span className="text-xs text-slate-500">Net Prize Distribution</span>
                <p className="text-xl font-bold text-[#002E6E] font-mono-num">
                  {formatINR(netPrizeAmount)}
                </p>
              </div>
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Authorize &amp; Declare Winner</span>
              </button>
            </div>
          </form>

          {/* Winner History */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200">
              <h4 className="text-sm font-bold text-[#002E6E]">Lucky Draw Winner History</h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                    <th className="py-2.5 px-4">Voucher #</th>
                    <th className="py-2.5 px-4">Draw #</th>
                    <th className="py-2.5 px-4">Date</th>
                    <th className="py-2.5 px-4">Winner</th>
                    <th className="py-2.5 px-4">Authorized By</th>
                    <th className="py-2.5 px-4">Status</th>
                    <th className="py-2.5 px-4 text-right">Net Prize</th>
                    <th className="py-2.5 px-4 text-right">Voucher</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {db.luckyDrawEntries.map((entry) => {
                    const win = db.members.find((m) => m.id === entry.winnerMemberId);
                    return (
                      <tr key={entry.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono-num font-medium">{entry.voucherNumber}</td>
                        <td className="py-3 px-4 font-mono-num">Draw #{entry.drawNumber}</td>
                        <td className="py-3 px-4 font-mono-num">{formatDateOnly(entry.drawDate)}</td>
                        <td className="py-3 px-4 font-medium">{win?.name ?? entry.winnerMemberId}</td>
                        <td className="py-3 px-4 text-slate-600">{entry.authorizedBy}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`font-semibold ${
                              entry.paymentStatus === 'Paid' ? 'text-emerald-700' : 'text-amber-700'
                            }`}
                          >
                            {entry.paymentStatus}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right font-mono-num font-semibold">
                          {formatINR(entry.netPrizeAmount)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => {
                              const found = db.receipts.find(
                                (r) => r.receiptNumber === entry.voucherNumber
                              );
                              if (found) setActiveReceipt(found);
                            }}
                            className="inline-flex items-center gap-1 text-[#0070E0] font-semibold hover:underline"
                          >
                            <ReceiptText className="w-3.5 h-3.5" />
                            <span>View</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* INDEPENDENT LUCKY DRAW LEDGER */}
      {activeTab === 'ledger' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 bg-white border border-slate-200 rounded-2xl p-5">
            <div className="min-w-[260px]">
              <FieldLabel label="Select Lucky Draw for Independent Ledger" />
              <select
                value={ledgerLdId}
                onChange={(e) => setLedgerLdId(e.target.value)}
                className={inputBaseClass}
              >
                {db.luckyDrawGroups.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name} ({g.id})
                  </option>
                ))}
              </select>
            </div>
            <button
              type="button"
              onClick={() =>
                exportToCSV(
                  `luckydraw_ledger_${ledgerLdId}`,
                  ['Ref #', 'Date', 'Timestamp', 'Member', 'Description', 'Mode', 'Direction', 'Amount'],
                  ldLedgerData.entries.map((e) => [
                    e.referenceNumber,
                    e.date,
                    formatDateTime(e.timestamp),
                    e.memberName ?? '',
                    e.description,
                    e.paymentMode,
                    e.direction,
                    e.amount,
                  ])
                )
              }
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Draw Ledger CSV</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-4">
              <p className="text-xs text-slate-500">Draw Collection</p>
              <p className="text-lg font-bold text-emerald-700 font-mono-num mt-1">
                {formatINR(ldLedgerData.totalCollection)}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-4">
              <p className="text-xs text-slate-500">Prizes Paid</p>
              <p className="text-lg font-bold text-slate-900 font-mono-num mt-1">
                {formatINR(ldLedgerData.totalPayout)}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-4">
              <p className="text-xs text-slate-500">Draw Expenses</p>
              <p className="text-lg font-bold text-red-600 font-mono-num mt-1">
                {formatINR(ldLedgerData.totalExpenses)}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-4">
              <p className="text-xs text-slate-500">Net Draw Balance</p>
              <p className="text-lg font-bold text-[#002E6E] font-mono-num mt-1">
                {formatINR(ldLedgerData.balance)}
              </p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                    <th className="py-2.5 px-4">Ref #</th>
                    <th className="py-2.5 px-4">Date &amp; Time</th>
                    <th className="py-2.5 px-4">Member / Item</th>
                    <th className="py-2.5 px-4">Description</th>
                    <th className="py-2.5 px-4">Mode</th>
                    <th className="py-2.5 px-4 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {ldLedgerData.entries.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        No transactions recorded for this Lucky Draw yet.
                      </td>
                    </tr>
                  ) : (
                    ldLedgerData.entries.map((e) => (
                      <tr key={e.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono-num font-medium">{e.referenceNumber}</td>
                        <td className="py-3 px-4 font-mono-num">{formatDateTime(e.timestamp)}</td>
                        <td className="py-3 px-4 font-medium">{e.memberName ?? 'Lucky Draw'}</td>
                        <td className="py-3 px-4 text-slate-600">{e.description}</td>
                        <td className="py-3 px-4">{e.paymentMode}</td>
                        <td
                          className={`py-3 px-4 text-right font-mono-num font-semibold ${
                            e.direction === 'credit' ? 'text-emerald-700' : 'text-red-600'
                          }`}
                        >
                          {e.direction === 'credit' ? '+' : '-'} {formatINR(e.amount)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
