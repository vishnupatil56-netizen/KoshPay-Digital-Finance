import React, { useMemo, useState } from 'react';
import { Download, Printer } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { exportToCSV, formatDateOnly, formatDateTime, formatINR, todayISO } from '../utils/formatters';
import { FieldLabel, FormAlert, SectionHeader, monoInputClass } from './FormControls';

type ReportCategory =
  | 'summary'
  | 'profit_loss'
  | 'pending'
  | 'bc'
  | 'luckydraw'
  | 'loans'
  | 'emi'
  | 'expenses';

type PeriodPreset = 'all' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom';

export const ReportsBackupView: React.FC = () => {
  const {
    db,
    lang,
    summary,
    ledgerEntries,
    getBCLedger,
    getLuckyDrawLedger,
    getLoanLedger,
  } = useFinance();

  const [reportCat, setReportCat] = useState<ReportCategory>('summary');
  const [selectedAccountId, setSelectedAccountId] = useState<string>('all');
  const [period, setPeriod] = useState<PeriodPreset>('all');
  const [fromDate, setFromDate] = useState(todayISO().slice(0, 8) + '01');
  const [toDate, setToDate] = useState(todayISO());
  const [exportMessage, setExportMessage] = useState<string | null>(null);

  const dateRange = useMemo(() => {
    const today = todayISO();
    if (period === 'daily') return { start: today, end: today };
    if (period === 'weekly') {
      const d = new Date(today + 'T00:00:00');
      d.setDate(d.getDate() - 6);
      return { start: d.toISOString().split('T')[0], end: today };
    }
    if (period === 'monthly') return { start: today.slice(0, 7) + '-01', end: today };
    if (period === 'yearly') return { start: today.slice(0, 4) + '-01-01', end: today };
    if (period === 'custom') return { start: fromDate, end: toDate };
    return { start: '1900-01-01', end: '2999-12-31' };
  }, [period, fromDate, toDate]);

  const filteredLedger = useMemo(
    () =>
      ledgerEntries.filter(
        (e) => e.date >= dateRange.start && e.date <= dateRange.end && e.status === 'Completed'
      ),
    [ledgerEntries, dateRange]
  );

  const periodTotals = useMemo(() => {
    let collection = 0;
    let payout = 0;
    let expense = 0;
    for (const e of filteredLedger) {
      if (e.direction === 'credit') collection += e.amount;
      else if (e.txnType === 'expense') expense += e.amount;
      else payout += e.amount;
    }
    return { collection, payout, expense, net: collection - payout - expense };
  }, [filteredLedger]);

  // Profit & Loss breakdown within period
  const pnlStats = useMemo(() => {
    const procFees = db.loans
      .filter((l) => l.loanDate >= dateRange.start && l.loanDate <= dateRange.end)
      .reduce((s, l) => s + l.processingFee, 0);
    const bcLateFees = db.bcCollections
      .filter((c) => c.collectionDate >= dateRange.start && c.collectionDate <= dateRange.end)
      .reduce((s, c) => s + c.lateFee, 0);
    const ldLateFees = db.luckyDrawCollections
      .filter((c) => c.collectionDate >= dateRange.start && c.collectionDate <= dateRange.end)
      .reduce((s, c) => s + c.lateFee, 0);
    const emiLateFees = db.emiPayments
      .filter((p) => p.paymentDate >= dateRange.start && p.paymentDate <= dateRange.end)
      .reduce((s, p) => s + p.lateFee, 0);
    const interestEarned = db.emiSchedules
      .filter((s) => s.status === 'Paid' && s.paidDate && s.paidDate >= dateRange.start && s.paidDate <= dateRange.end)
      .reduce((s, r) => s + r.interestComponent, 0);
    const expenses = db.expenses
      .filter((e) => e.expenseDate >= dateRange.start && e.expenseDate <= dateRange.end)
      .reduce((s, e) => s + e.amount, 0);

    const totalRevenue = procFees + bcLateFees + ldLateFees + emiLateFees + interestEarned;
    return {
      procFees,
      lateFees: bcLateFees + ldLateFees + emiLateFees,
      interestEarned,
      totalRevenue,
      expenses,
      netProfit: totalRevenue - expenses,
    };
  }, [db, dateRange]);

  const overdueSchedules = useMemo(() => {
    const today = todayISO();
    return db.emiSchedules.filter((s) => s.status !== 'Paid' && s.dueDate <= today);
  }, [db.emiSchedules]);

  const activeBCs = useMemo(() => db.bcGroups.filter((g) => !g.isDeleted), [db.bcGroups]);

  const categories: { id: ReportCategory; label: string }[] = [
    { id: 'summary', label: 'Collection & Cashflow' },
    { id: 'profit_loss', label: 'Profit & Loss' },
    { id: 'pending', label: 'Pending & Overdue' },
    { id: 'bc', label: lang === 'mr' ? 'BC स्वतंत्र हिशोब' : 'BC Independent Ledgers' },
    { id: 'luckydraw', label: lang === 'mr' ? 'Lucky Draw स्वतंत्र हिशोब' : 'Lucky Draw Independent Ledgers' },
    { id: 'loans', label: lang === 'mr' ? 'Loan स्वतंत्र हिशोब' : 'Loan Independent Ledgers' },
    { id: 'emi', label: 'EMI Collection' },
    { id: 'expenses', label: 'Expense Reports' },
  ];

  const handleCategoryChange = (cat: ReportCategory) => {
    setReportCat(cat);
    setSelectedAccountId('all');
  };

  const displayedLedgerEntries = useMemo(
    () =>
      filteredLedger.filter((e) => {
        if (reportCat === 'bc') {
          if (e.groupKind !== 'bc') return false;
          return selectedAccountId === 'all' || e.groupId === selectedAccountId;
        }
        if (reportCat === 'luckydraw') {
          if (e.groupKind !== 'luckydraw') return false;
          return selectedAccountId === 'all' || e.groupId === selectedAccountId;
        }
        if (reportCat === 'loans') {
          if (e.groupKind !== 'loan') return false;
          return selectedAccountId === 'all' || e.groupId === selectedAccountId;
        }
        if (reportCat === 'emi') return e.txnType === 'loan_emi';
        if (reportCat === 'expenses') return e.txnType === 'expense';
        return true;
      }),
    [filteredLedger, reportCat, selectedAccountId]
  );

  const handleExportCurrentReport = () => {
    const periodLabel = period === 'all' ? 'All Time' : `${dateRange.start} to ${dateRange.end}`;

    if (reportCat === 'profit_loss') {
      exportToCSV(
        `profit_loss_${period}`,
        ['Line Item', 'Period', 'Amount'],
        [
          ['Loan Interest Earned', periodLabel, pnlStats.interestEarned],
          ['Loan Processing Fees', periodLabel, pnlStats.procFees],
          ['Late Fees (BC + Lucky Draw + EMI)', periodLabel, pnlStats.lateFees],
          ['Total Revenue', periodLabel, pnlStats.totalRevenue],
          ['Operating Expenses', periodLabel, -pnlStats.expenses],
          ['Net Operating Profit / (Loss)', periodLabel, pnlStats.netProfit],
        ]
      );
      setExportMessage('Profit & Loss statement exported to CSV.');
      return;
    }

    if (reportCat === 'pending') {
      exportToCSV(
        'pending_overdue_emis',
        ['Loan ID', 'Customer', 'Mobile', 'EMI #', 'Due Date', 'Due Amount'],
        overdueSchedules.map((s) => {
          const loan = db.loans.find((l) => l.id === s.loanId);
          return [
            s.loanId,
            loan?.customerName ?? s.loanId,
            loan?.mobile ?? '',
            s.installmentNumber,
            s.dueDate,
            Math.max(0, s.emiAmount - s.paidAmount),
          ];
        })
      );
      setExportMessage(`Exported ${overdueSchedules.length} overdue EMI records to CSV.`);
      return;
    }

    if (reportCat === 'loans' && selectedAccountId === 'all') {
      exportToCSV(
        'loan_report',
        [
          'Loan ID',
          'Customer',
          'Mobile',
          'Type',
          'Principal',
          'Rate %',
          'EMI',
          'Disbursed',
          'EMI Collected',
          'Principal Out',
          'Net Cashflow',
          'Status',
        ],
        db.loans.map((l) => {
          const ledger = getLoanLedger(l.id);
          return [
            l.id,
            l.customerName,
            l.mobile,
            l.loanType,
            l.loanAmount,
            l.interestRate,
            l.emiAmount,
            ledger.totalDisbursed,
            ledger.totalCollection,
            l.principalOutstanding,
            ledger.netAccountBalance,
            l.loanStatus,
          ];
        })
      );
      setExportMessage(`Exported ${db.loans.length} loan account records to CSV.`);
      return;
    }

    if (reportCat === 'emi') {
      const emiRows = db.emiPayments.filter(
        (p) => p.paymentDate >= dateRange.start && p.paymentDate <= dateRange.end
      );
      exportToCSV(
        'emi_collection_report',
        ['Receipt #', 'Loan ID', 'Customer', 'EMI #', 'Date', 'Amount Paid', 'Late Fee', 'Total Received', 'Mode'],
        emiRows.map((p) => [
          p.receiptNumber,
          p.loanId,
          p.customerName,
          p.installmentNumber,
          p.paymentDate,
          p.amountPaid,
          p.lateFee,
          p.totalReceived,
          p.paymentMode,
        ])
      );
      setExportMessage(`Exported ${emiRows.length} EMI collection records to CSV.`);
      return;
    }

    if (reportCat === 'expenses') {
      const expRows = db.expenses.filter(
        (e) => e.expenseDate >= dateRange.start && e.expenseDate <= dateRange.end
      );
      exportToCSV(
        'expense_report',
        ['ID', 'Date', 'Category', 'Linked Account', 'Description', 'Mode', 'Ref #', 'Amount'],
        expRows.map((e) => [
          e.id,
          e.expenseDate,
          e.category,
          e.linkedGroupId ?? 'General Office',
          e.description,
          e.paymentMode,
          e.referenceNumber,
          e.amount,
        ])
      );
      setExportMessage(`Exported ${expRows.length} expense records to CSV.`);
      return;
    }

    exportToCSV(
      `report_${reportCat}_${selectedAccountId}`,
      ['Ref #', 'Date', 'Timestamp', 'Party / Group', 'Description', 'Mode', 'Book', 'Direction', 'Amount'],
      displayedLedgerEntries.map((e) => [
        e.referenceNumber,
        e.date,
        formatDateTime(e.timestamp),
        e.memberName || e.groupName || '',
        e.description,
        e.paymentMode,
        e.book,
        e.direction,
        e.amount,
      ])
    );
    setExportMessage(`Exported ${displayedLedgerEntries.length} financial ledger records to CSV.`);
  };

  return (
    <div className="space-y-6">
      <SectionHeader
        title={lang === 'mr' ? 'रिपोर्ट्स व नफा-तोटा विश्लेषण' : 'Reports & Financial Analytics'}
        subtitle={
          lang === 'mr'
            ? 'दैनिक, साप्ताहिक, मासिक, वार्षिक रिपोर्ट्स, नफा-तोटा, प्रलंबित हप्ते आणि CSV / PDF एक्सपोर्ट'
            : 'Daily, Weekly, Monthly & Yearly reports, Profit & Loss, Pending EMIs, and CSV / PDF export'
        }
        actions={
          <div className="flex items-center gap-2 no-print">
            <button
              type="button"
              onClick={handleExportCurrentReport}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#002E6E] bg-white border border-slate-200 rounded-xl hover:bg-blue-50 transition-colors min-h-[40px]"
            >
              <Download className="w-3.5 h-3.5 text-[#0070E0]" />
              <span>Export to CSV</span>
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl transition-colors min-h-[40px]"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
          </div>
        }
      />

      {exportMessage && (
        <FormAlert
          type="success"
          message={exportMessage}
          onDismiss={() => setExportMessage(null)}
        />
      )}

      {/* Period & Date Filter Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 no-print">
        <div className="flex flex-wrap items-center gap-1.5">
          {(
            [
              { id: 'all', label: 'All Time' },
              { id: 'daily', label: 'Daily (Today)' },
              { id: 'weekly', label: 'Weekly (7 Days)' },
              { id: 'monthly', label: 'Monthly' },
              { id: 'yearly', label: 'Yearly' },
              { id: 'custom', label: 'Custom Dates' },
            ] as const
          ).map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPeriod(p.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                period === p.id
                  ? 'bg-[#002E6E] text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {period === 'custom' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 max-w-md">
            <div>
              <FieldLabel label="From Date" />
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="To Date" />
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className={monoInputClass}
              />
            </div>
          </div>
        )}

        <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-100">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => handleCategoryChange(cat.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                reportCat === cat.id
                  ? 'border-[#0070E0] bg-blue-50 text-[#002E6E]'
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {(reportCat === 'bc' || reportCat === 'luckydraw' || reportCat === 'loans') && (
          <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs font-semibold text-[#002E6E]">
              {lang === 'mr'
                ? 'स्वतंत्र खाते निवडा (Independent Ledger Filter):'
                : 'Filter Specific Account Ledger:'}
            </span>
            <select
              value={selectedAccountId}
              onChange={(e) => setSelectedAccountId(e.target.value)}
              className="px-3 py-2 text-xs font-medium bg-[#F4F7FB] border border-slate-200 rounded-xl text-slate-900 min-w-[240px]"
            >
              <option value="all">
                {reportCat === 'bc'
                  ? 'All BC Groups (Combined Entries)'
                  : reportCat === 'luckydraw'
                    ? 'All Lucky Draws (Combined Entries)'
                    : 'All Loan Accounts (Combined Entries)'}
              </option>
              {reportCat === 'bc' &&
                activeBCs.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name} ({g.id})
                  </option>
                ))}
              {reportCat === 'luckydraw' &&
                db.luckyDrawGroups.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name} ({g.id})
                  </option>
                ))}
              {reportCat === 'loans' &&
                db.loans.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.id} — {l.customerName}
                  </option>
                ))}
            </select>
          </div>
        )}
      </div>

      {/* Period Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs text-slate-500">Period Collection</p>
          <p className="text-lg font-bold text-emerald-700 font-mono-num mt-1">
            {formatINR(periodTotals.collection)}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs text-slate-500">Period Payout / Loans</p>
          <p className="text-lg font-bold text-slate-900 font-mono-num mt-1">
            {formatINR(periodTotals.payout)}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs text-slate-500">Period Expenses</p>
          <p className="text-lg font-bold text-red-600 font-mono-num mt-1">
            {formatINR(periodTotals.expense)}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs text-slate-500">Net Period Cashflow</p>
          <p className="text-lg font-bold text-[#002E6E] font-mono-num mt-1">
            {formatINR(periodTotals.net)}
          </p>
        </div>
      </div>

      {/* PROFIT & LOSS VIEW */}
      {reportCat === 'profit_loss' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 print-container max-w-2xl">
          <h3 className="text-base font-bold text-[#002E6E] font-display">
            Profit &amp; Loss Statement ({period === 'all' ? 'All Time' : `${dateRange.start} to ${dateRange.end}`})
          </h3>
          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-600">Loan Interest Earned</span>
              <span className="font-mono-num font-semibold text-emerald-700">
                + {formatINR(pnlStats.interestEarned)}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-600">Loan Processing Fees</span>
              <span className="font-mono-num font-semibold text-emerald-700">
                + {formatINR(pnlStats.procFees)}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-600">Late Fees (BC + Lucky Draw + EMI)</span>
              <span className="font-mono-num font-semibold text-emerald-700">
                + {formatINR(pnlStats.lateFees)}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-600">Operating Expenses</span>
              <span className="font-mono-num font-semibold text-red-600">
                - {formatINR(pnlStats.expenses)}
              </span>
            </div>
            <div className="flex justify-between pt-3 border-t border-slate-900 text-sm font-bold">
              <span className="text-[#002E6E]">Net Operating Profit / (Loss)</span>
              <span
                className={`font-mono-num ${
                  pnlStats.netProfit >= 0 ? 'text-emerald-700' : 'text-red-600'
                }`}
              >
                {formatINR(pnlStats.netProfit)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* PENDING & OVERDUE VIEW */}
      {reportCat === 'pending' && (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#002E6E]">
              Due &amp; Overdue Loan EMIs ({overdueSchedules.length})
            </h3>
            <span className="text-xs font-mono-num font-semibold text-amber-700">
              Total Due: {formatINR(summary.pendingEMI)}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                  <th className="py-2.5 px-4">Loan ID</th>
                  <th className="py-2.5 px-4">Customer</th>
                  <th className="py-2.5 px-4">EMI #</th>
                  <th className="py-2.5 px-4">Due Date</th>
                  <th className="py-2.5 px-4 text-right">Due Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {overdueSchedules.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-emerald-700 font-medium">
                      No overdue EMIs as of today.
                    </td>
                  </tr>
                ) : (
                  overdueSchedules.map((s) => {
                    const loan = db.loans.find((l) => l.id === s.loanId);
                    return (
                      <tr key={s.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono-num font-medium">{s.loanId}</td>
                        <td className="py-3 px-4 font-medium">{loan?.customerName ?? s.loanId}</td>
                        <td className="py-3 px-4 font-mono-num">EMI #{s.installmentNumber}</td>
                        <td className="py-3 px-4 font-mono-num text-red-600">
                          {formatDateOnly(s.dueDate)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono-num font-semibold">
                          {formatINR(Math.max(0, s.emiAmount - s.paidAmount))}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* PER-ACCOUNT INDEPENDENT LEDGER SUMMARY (BC / LUCKY DRAW / LOANS) */}
      {reportCat === 'bc' && (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden print-container">
          <div className="px-5 py-3.5 border-b border-slate-200">
            <h3 className="text-sm font-bold text-[#002E6E]">
              {lang === 'mr'
                ? `प्रत्येक BC चा स्वतंत्र हिशोब (${activeBCs.length})`
                : `Independent Accounting by BC Group (${activeBCs.length})`}
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                  <th className="py-2.5 px-4">BC Group</th>
                  <th className="py-2.5 px-4 text-right">Members</th>
                  <th className="py-2.5 px-4 text-right">Collection</th>
                  <th className="py-2.5 px-4 text-right">Winner Payouts</th>
                  <th className="py-2.5 px-4 text-right">BC Expenses</th>
                  <th className="py-2.5 px-4 text-right">Independent Balance</th>
                  <th className="py-2.5 px-4 text-right no-print">Ledger</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {activeBCs.map((g) => {
                  const ledger = getBCLedger(g.id);
                  const memberCount = db.enrollments.filter(
                    (e) => e.groupKind === 'bc' && e.groupId === g.id && e.status === 'Active'
                  ).length;
                  const isSelected = selectedAccountId === g.id;
                  return (
                    <tr
                      key={g.id}
                      className={isSelected ? 'bg-blue-50/70' : 'hover:bg-slate-50/70'}
                    >
                      <td className="py-2.5 px-4">
                        <div className="font-semibold text-slate-900">{g.name}</div>
                        <div className="font-mono-num text-[11px] text-slate-500">
                          {g.id} · {g.status}
                        </div>
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num">
                        {memberCount}/{g.totalMembers}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num text-emerald-700 font-semibold">
                        {formatINR(ledger.totalCollection)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num text-slate-800">
                        {formatINR(ledger.totalPayout)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num text-red-600">
                        {formatINR(ledger.totalExpenses)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num font-bold text-[#002E6E]">
                        {formatINR(ledger.balance)}
                      </td>
                      <td className="py-2.5 px-4 text-right no-print">
                        <button
                          type="button"
                          onClick={() => setSelectedAccountId(isSelected ? 'all' : g.id)}
                          className="text-[#0070E0] font-semibold hover:underline"
                        >
                          {isSelected ? 'Show All' : 'View Ledger'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {reportCat === 'luckydraw' && (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden print-container">
          <div className="px-5 py-3.5 border-b border-slate-200">
            <h3 className="text-sm font-bold text-[#002E6E]">
              {lang === 'mr'
                ? `प्रत्येक Lucky Draw चा स्वतंत्र हिशोब (${db.luckyDrawGroups.length})`
                : `Independent Accounting by Lucky Draw (${db.luckyDrawGroups.length})`}
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                  <th className="py-2.5 px-4">Lucky Draw</th>
                  <th className="py-2.5 px-4 text-right">Members</th>
                  <th className="py-2.5 px-4 text-right">Collection</th>
                  <th className="py-2.5 px-4 text-right">Prize Payouts</th>
                  <th className="py-2.5 px-4 text-right">Draw Expenses</th>
                  <th className="py-2.5 px-4 text-right">Independent Balance</th>
                  <th className="py-2.5 px-4 text-right no-print">Ledger</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {db.luckyDrawGroups.map((g) => {
                  const ledger = getLuckyDrawLedger(g.id);
                  const memberCount = db.enrollments.filter(
                    (e) => e.groupKind === 'luckydraw' && e.groupId === g.id && e.status === 'Active'
                  ).length;
                  const isSelected = selectedAccountId === g.id;
                  return (
                    <tr
                      key={g.id}
                      className={isSelected ? 'bg-blue-50/70' : 'hover:bg-slate-50/70'}
                    >
                      <td className="py-2.5 px-4">
                        <div className="font-semibold text-slate-900">{g.name}</div>
                        <div className="font-mono-num text-[11px] text-slate-500">
                          {g.id} · {g.status}
                        </div>
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num">
                        {memberCount}/{g.totalMembers}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num text-emerald-700 font-semibold">
                        {formatINR(ledger.totalCollection)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num text-slate-800">
                        {formatINR(ledger.totalPayout)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num text-red-600">
                        {formatINR(ledger.totalExpenses)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num font-bold text-[#002E6E]">
                        {formatINR(ledger.balance)}
                      </td>
                      <td className="py-2.5 px-4 text-right no-print">
                        <button
                          type="button"
                          onClick={() => setSelectedAccountId(isSelected ? 'all' : g.id)}
                          className="text-[#0070E0] font-semibold hover:underline"
                        >
                          {isSelected ? 'Show All' : 'View Ledger'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {reportCat === 'loans' && (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden print-container">
          <div className="px-5 py-3.5 border-b border-slate-200">
            <h3 className="text-sm font-bold text-[#002E6E]">
              {lang === 'mr'
                ? `प्रत्येक Loan चा स्वतंत्र हिशोब (${db.loans.length})`
                : `Independent Accounting by Loan Account (${db.loans.length})`}
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                  <th className="py-2.5 px-4">Loan &amp; Customer</th>
                  <th className="py-2.5 px-4 text-right">Principal</th>
                  <th className="py-2.5 px-4 text-right">Disbursed</th>
                  <th className="py-2.5 px-4 text-right">EMI Collected</th>
                  <th className="py-2.5 px-4 text-right">Principal Out</th>
                  <th className="py-2.5 px-4 text-right">Net Cashflow</th>
                  <th className="py-2.5 px-4 text-right no-print">Ledger</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {db.loans.map((l) => {
                  const ledger = getLoanLedger(l.id);
                  const isSelected = selectedAccountId === l.id;
                  return (
                    <tr
                      key={l.id}
                      className={isSelected ? 'bg-blue-50/70' : 'hover:bg-slate-50/70'}
                    >
                      <td className="py-2.5 px-4">
                        <div className="font-semibold text-slate-900">{l.customerName}</div>
                        <div className="font-mono-num text-[11px] text-slate-500">
                          {l.id} · {l.loanType} · {l.loanStatus}
                        </div>
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num">
                        {formatINR(l.loanAmount)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num text-slate-700">
                        {formatINR(ledger.totalDisbursed)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num text-emerald-700 font-semibold">
                        {formatINR(ledger.totalCollection)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num font-semibold text-[#0070E0]">
                        {formatINR(l.principalOutstanding)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-num font-bold text-[#002E6E]">
                        {formatINR(ledger.netAccountBalance)}
                      </td>
                      <td className="py-2.5 px-4 text-right no-print">
                        <button
                          type="button"
                          onClick={() => setSelectedAccountId(isSelected ? 'all' : l.id)}
                          className="text-[#0070E0] font-semibold hover:underline"
                        >
                          {isSelected ? 'Show All' : 'View Ledger'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* FILTERED TRANSACTIONS TABLE FOR SUMMARY / BC / LD / LOANS / EMI / EXPENSES */}
      {reportCat !== 'profit_loss' && reportCat !== 'pending' && (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden print-container">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#002E6E]">
              {categories.find((c) => c.id === reportCat)?.label}
              {selectedAccountId !== 'all' ? ` · ${selectedAccountId}` : ''}
            </h3>
            <span className="text-xs font-mono-num text-slate-500">
              {dateRange.start === '1900-01-01' ? 'All Dates' : `${dateRange.start} → ${dateRange.end}`}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                  <th className="py-2.5 px-4">Ref #</th>
                  <th className="py-2.5 px-4">Date</th>
                  <th className="py-2.5 px-4">Party / Group</th>
                  <th className="py-2.5 px-4">Description</th>
                  <th className="py-2.5 px-4">Mode</th>
                  <th className="py-2.5 px-4 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {displayedLedgerEntries.map((e) => (
                    <tr key={`${e.id}-${e.referenceNumber}`} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-mono-num font-medium">{e.referenceNumber}</td>
                      <td className="py-3 px-4 font-mono-num">{formatDateOnly(e.date)}</td>
                      <td className="py-3 px-4 font-medium">{e.memberName || e.groupName}</td>
                      <td className="py-3 px-4 text-slate-600">{e.description}</td>
                      <td className="py-3 px-4">{e.paymentMode}</td>
                      <td
                        className={`py-3 px-4 text-right font-mono-num font-semibold ${
                          e.direction === 'credit' ? 'text-emerald-700' : 'text-red-600'
                        }`}
                      >
                        {e.direction === 'credit' ? '+' : '-'} {formatINR(e.amount)}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
