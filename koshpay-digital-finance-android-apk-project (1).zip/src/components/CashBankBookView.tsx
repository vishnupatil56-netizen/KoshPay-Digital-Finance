import React, { useMemo, useState } from 'react';
import { Download, Printer } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { exportToCSV, formatDateOnly, formatDateTime, formatINR } from '../utils/formatters';
import { SectionHeader } from './FormControls';

export const CashBankBookView: React.FC = () => {
  const { lang, ledgerEntries, summary } = useFinance();
  const [bookTab, setBookTab] = useState<'Cash Book' | 'Bank Book'>('Cash Book');

  // Compute chronological running balance for selected book
  const rowsWithBalance = useMemo(() => {
    const filtered = ledgerEntries
      .filter((e) => e.book === bookTab && e.status === 'Completed')
      .slice()
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

    let running = 0;
    return filtered
      .map((entry) => {
        running += entry.direction === 'credit' ? entry.amount : -entry.amount;
        return { ...entry, runningBalance: running };
      })
      .reverse();
  }, [ledgerEntries, bookTab]);

  const totalInflow = useMemo(
    () => rowsWithBalance.filter((r) => r.direction === 'credit').reduce((s, r) => s + r.amount, 0),
    [rowsWithBalance]
  );

  const totalOutflow = useMemo(
    () => rowsWithBalance.filter((r) => r.direction === 'debit').reduce((s, r) => s + r.amount, 0),
    [rowsWithBalance]
  );

  return (
    <div className="space-y-6">
      <SectionHeader
        title={lang === 'mr' ? 'कॅश बुक आणि बँक बुक' : 'Cash Book & Bank Book'}
        subtitle={
          lang === 'mr'
            ? 'नियम ८: रोख (Cash) आणि बँक / UPI व्यवहारांची स्वतंत्र व स्वयंचलित नोंद'
            : 'Rule 8: Automatic separation of Cash Book and Bank/UPI Book with running balances'
        }
        actions={
          <div className="flex items-center gap-2 no-print">
            <button
              type="button"
              onClick={() =>
                exportToCSV(
                  bookTab.toLowerCase().replace(' ', '_'),
                  ['Ref #', 'Date', 'Timestamp', 'Party / Group', 'Description', 'Mode', 'Credit', 'Debit', 'Running Balance'],
                  rowsWithBalance.map((r) => [
                    r.referenceNumber,
                    r.date,
                    formatDateTime(r.timestamp),
                    r.memberName || r.groupName || '',
                    r.description,
                    r.paymentMode,
                    r.direction === 'credit' ? r.amount : 0,
                    r.direction === 'debit' ? r.amount : 0,
                    r.runningBalance,
                  ])
                )
              }
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export {bookTab} CSV</span>
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print PDF</span>
            </button>
          </div>
        }
      />

      {/* Book Switcher */}
      <div className="flex items-center gap-1.5 p-1.5 bg-slate-100 rounded-xl w-fit no-print">
        {(['Cash Book', 'Bank Book'] as const).map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setBookTab(tab)}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              bookTab === tab ? 'bg-white text-[#002E6E] shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab === 'Cash Book'
              ? `Cash Book (${formatINR(summary.cashBalance)})`
              : `Bank / UPI Book (${formatINR(summary.bankBalance)})`}
          </button>
        ))}
      </div>

      {/* Book Summary Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs text-slate-500">Total Credit (+ Inflow)</p>
          <p className="text-lg font-bold text-emerald-700 font-mono-num mt-1">
            {formatINR(totalInflow)}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs text-slate-500">Total Debit (- Outflow)</p>
          <p className="text-lg font-bold text-red-600 font-mono-num mt-1">
            {formatINR(totalOutflow)}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs text-slate-500">Closing {bookTab} Balance</p>
          <p className="text-lg font-bold text-[#002E6E] font-mono-num mt-1">
            {formatINR(bookTab === 'Cash Book' ? summary.cashBalance : summary.bankBalance)}
          </p>
        </div>
      </div>

      {/* Book Ledger Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                <th className="py-2.5 px-4">Ref #</th>
                <th className="py-2.5 px-4">Date &amp; Time</th>
                <th className="py-2.5 px-4">Party / Group</th>
                <th className="py-2.5 px-4">Particulars</th>
                <th className="py-2.5 px-4">Mode</th>
                <th className="py-2.5 px-4 text-right">Credit (+)</th>
                <th className="py-2.5 px-4 text-right">Debit (-)</th>
                <th className="py-2.5 px-4 text-right">Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rowsWithBalance.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No entries in {bookTab} yet.
                  </td>
                </tr>
              ) : (
                rowsWithBalance.map((r) => (
                  <tr key={`${r.id}-${r.referenceNumber}`} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono-num font-medium">{r.referenceNumber}</td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="font-mono-num">{formatDateOnly(r.date)}</div>
                      <div className="text-[11px] text-slate-400 font-mono-num">
                        {formatDateTime(r.timestamp)}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-900">
                      {r.memberName || r.groupName || '-'}
                    </td>
                    <td className="py-3 px-4 text-slate-600">{r.description}</td>
                    <td className="py-3 px-4">{r.paymentMode}</td>
                    <td className="py-3 px-4 text-right font-mono-num text-emerald-700 font-medium">
                      {r.direction === 'credit' ? formatINR(r.amount) : '-'}
                    </td>
                    <td className="py-3 px-4 text-right font-mono-num text-red-600 font-medium">
                      {r.direction === 'debit' ? formatINR(r.amount) : '-'}
                    </td>
                    <td className="py-3 px-4 text-right font-mono-num font-semibold text-slate-900">
                      {formatINR(r.runningBalance)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
