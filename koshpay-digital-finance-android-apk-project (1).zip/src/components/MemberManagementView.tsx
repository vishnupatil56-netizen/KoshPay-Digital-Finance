import React, { useEffect, useMemo, useState } from 'react';
import { Download, ReceiptText, Search } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { MemberCategory, RecordStatus } from '../types/finance';
import { exportToCSV, formatDateOnly, formatDateTime, formatINR, generateNextId, todayISO } from '../utils/formatters';
import { FieldLabel, FormAlert, SectionHeader, inputBaseClass, monoInputClass } from './FormControls';

type MemberTab = 'directory' | 'ledger' | 'add' | 'modify' | 'transfer' | 'delete';

export const MemberManagementView: React.FC = () => {
  const {
    db,
    lang,
    getMemberLedger,
    addMember,
    updateMember,
    deleteMember,
    transferMember,
    setActiveReceipt,
  } = useFinance();

  const [activeTab, setActiveTab] = useState<MemberTab>('directory');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Inactive'>('All');
  const [feedback, setFeedback] = useState<{ type: 'error' | 'success'; message: string } | null>(null);
  const [search, setSearch] = useState('');

  const activeMembersList = useMemo(() => db.members.filter((m) => !m.isDeleted), [db.members]);

  // --- Add Member ---
  const [addName, setAddName] = useState('');
  const [addMobile, setAddMobile] = useState('');
  const [addAddress, setAddAddress] = useState('');
  const [addJoinDate, setAddJoinDate] = useState(todayISO());
  const [addCategory, setAddCategory] = useState<MemberCategory>('BC Member');
  const [addAadhaar, setAddAadhaar] = useState('');
  const [addNominee, setAddNominee] = useState('');
  const [addLoanRef, setAddLoanRef] = useState('');
  const [addInitialBal, setAddInitialBal] = useState(0);
  const [addStatus, setAddStatus] = useState<RecordStatus>('Active');

  const nextMemId = useMemo(
    () => generateNextId('MEM', db.members.map((m) => m.id), 4),
    [db.members]
  );

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const res = addMember({
      name: addName,
      mobile: addMobile,
      address: addAddress,
      joiningDate: addJoinDate,
      category: addCategory,
      aadhaar: addAadhaar || undefined,
      nomineeName: addNominee || undefined,
      loanCustomerRef: addLoanRef || undefined,
      initialBalance: addInitialBal,
      status: addStatus,
    });
    if (res.ok) {
      setFeedback({ type: 'success', message: `Member ${addName} (${res.id}) added.` });
      setAddName('');
      setAddMobile('');
      setAddAddress('');
      setAddAadhaar('');
      setAddNominee('');
      setAddLoanRef('');
      setAddInitialBal(0);
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Failed to add member.' });
    }
  };

  // --- Modify Member ---
  const [modMemberId, setModMemberId] = useState(activeMembersList[0]?.id ?? '');
  const selectedModMember = activeMembersList.find((m) => m.id === modMemberId);
  const [modName, setModName] = useState('');
  const [modMobile, setModMobile] = useState('');
  const [modAddress, setModAddress] = useState('');
  const [modCategory, setModCategory] = useState<MemberCategory>('BC Member');
  const [modNominee, setModNominee] = useState('');
  const [modStatus, setModStatus] = useState<RecordStatus>('Active');

  useEffect(() => {
    if (selectedModMember) {
      setModName(selectedModMember.name);
      setModMobile(selectedModMember.mobile);
      setModAddress(selectedModMember.address);
      setModCategory(selectedModMember.category);
      setModNominee(selectedModMember.nomineeName ?? '');
      setModStatus(selectedModMember.status);
    }
  }, [selectedModMember]);

  const handleModifyMember = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!modMemberId) return;
    const res = updateMember(modMemberId, {
      name: modName,
      mobile: modMobile,
      address: modAddress,
      category: modCategory,
      nomineeName: modNominee || undefined,
      status: modStatus,
    });
    setFeedback(
      res.ok
        ? { type: 'success', message: `Member ${modMemberId} updated.` }
        : { type: 'error', message: res.error ?? 'Update failed.' }
    );
  };

  // --- Transfer Member ---
  const [trfMemberId, setTrfMemberId] = useState(activeMembersList[0]?.id ?? '');
  const memberEnrollments = useMemo(
    () => db.enrollments.filter((e) => e.memberId === trfMemberId),
    [db.enrollments, trfMemberId]
  );
  const [fromEnrollmentId, setFromEnrollmentId] = useState('');
  const [toGroupKind, setToGroupKind] = useState<'bc' | 'luckydraw'>('bc');
  const [toGroupId, setToGroupId] = useState(db.bcGroups[0]?.id ?? '');
  const [trfDate, setTrfDate] = useState(todayISO());
  const [trfReason, setTrfReason] = useState('');

  useEffect(() => {
    if (memberEnrollments.length > 0 && !memberEnrollments.some((e) => e.id === fromEnrollmentId)) {
      setFromEnrollmentId(memberEnrollments[0].id);
    } else if (memberEnrollments.length === 0) {
      setFromEnrollmentId('');
    }
  }, [memberEnrollments, fromEnrollmentId]);

  useEffect(() => {
    if (toGroupKind === 'bc') {
      setToGroupId(db.bcGroups.find((g) => !g.isDeleted)?.id ?? '');
    } else {
      setToGroupId(db.luckyDrawGroups[0]?.id ?? '');
    }
  }, [toGroupKind, db.bcGroups, db.luckyDrawGroups]);

  const handleTransferMember = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const res = transferMember({
      memberId: trfMemberId,
      fromEnrollmentId,
      toGroupKind,
      toGroupId,
      transferDate: trfDate,
      reason: trfReason,
    });
    if (res.ok) {
      setFeedback({ type: 'success', message: `Member transferred (${res.id}).` });
      setTrfReason('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Transfer failed.' });
    }
  };

  // --- Soft Delete Member ---
  const [delMemberId, setDelMemberId] = useState(activeMembersList[0]?.id ?? '');
  const [delReason, setDelReason] = useState('');

  const handleDeleteMember = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const res = deleteMember(delMemberId, delReason);
    if (res.ok) {
      setFeedback({ type: 'success', message: `Member ${delMemberId} soft-deleted & logged.` });
      setDelReason('');
      setDelMemberId(activeMembersList.find((m) => m.id !== delMemberId)?.id ?? '');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Could not delete member.' });
    }
  };

  // --- Member Ledger & Payment History ---
  const [ledgerMemberId, setLedgerMemberId] = useState(activeMembersList[0]?.id ?? '');
  const ledgerData = getMemberLedger(ledgerMemberId);
  const ledgerMember = db.members.find((m) => m.id === ledgerMemberId);

  const filteredDirectory = useMemo(() => {
    const q = search.trim().toLowerCase();
    return activeMembersList.filter((m) => {
      if (statusFilter !== 'All' && m.status !== statusFilter) return false;
      if (!q) return true;
      return (
        m.name.toLowerCase().includes(q) ||
        m.id.toLowerCase().includes(q) ||
        m.mobile.toLowerCase().includes(q) ||
        m.category.toLowerCase().includes(q)
      );
    });
  }, [activeMembersList, search, statusFilter]);

  const getGroupName = (kind: 'bc' | 'luckydraw', id: string) =>
    kind === 'bc'
      ? db.bcGroups.find((g) => g.id === id)?.name ?? id
      : db.luckyDrawGroups.find((g) => g.id === id)?.name ?? id;

  const tabs: { id: MemberTab; label: string }[] = [
    { id: 'directory', label: lang === 'mr' ? 'सभासद यादी' : 'Member Directory' },
    { id: 'ledger', label: lang === 'mr' ? 'सभासद खातेवही' : 'Member Ledger & History' },
    { id: 'add', label: lang === 'mr' ? 'नवीन सभासद' : 'Add Member' },
    { id: 'modify', label: lang === 'mr' ? 'माहिती बदला' : 'Modify Member' },
    { id: 'transfer', label: lang === 'mr' ? 'ग्रुप बदला' : 'Member Transfer' },
    { id: 'delete', label: lang === 'mr' ? 'सभासद काढणे' : 'Soft Delete' },
  ];

  return (
    <div className="space-y-6">
      <SectionHeader
        title={lang === 'mr' ? 'सभासद व पेमेंट व्यवस्थापन' : 'Member Management System'}
        subtitle={
          lang === 'mr'
            ? 'सक्रिय/निष्क्रिय सभासद, शोध, माहिती बदल, ग्रुप ट्रान्सफर, वैयक्तिक खातेवही आणि पावती इतिहास'
            : 'Centralized member registry with Active/Inactive filter, category, transfers, ledgers & payment history'
        }
      />

      <div className="flex flex-wrap gap-1.5 p-1.5 bg-slate-100 rounded-xl no-print">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => {
              setActiveTab(tab.id);
              setFeedback(null);
            }}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-white text-[#002E6E] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {feedback && (
        <FormAlert
          type={feedback.type}
          message={feedback.message}
          onDismiss={() => setFeedback(null)}
        />
      )}

      {/* DIRECTORY */}
      {activeTab === 'directory' && (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 px-5 py-4 border-b border-slate-200">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl w-fit">
              {(['All', 'Active', 'Inactive'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg ${
                    statusFilter === st ? 'bg-white text-[#002E6E] shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="relative min-w-[220px]">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search name, ID, mobile..."
                  className={`${inputBaseClass} pl-9 min-h-[38px] text-xs`}
                />
              </div>
              <button
                type="button"
                onClick={() =>
                  exportToCSV(
                    'members_report',
                    ['Member ID', 'Name', 'Mobile', 'Category', 'Address', 'Joined', 'Status'],
                    filteredDirectory.map((m) => [
                      m.id,
                      m.name,
                      m.mobile,
                      m.category,
                      m.address,
                      m.joiningDate,
                      m.status,
                    ])
                  )
                }
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Excel CSV</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                  <th className="py-2.5 px-4">Member ID</th>
                  <th className="py-2.5 px-4">Full Name</th>
                  <th className="py-2.5 px-4">Mobile</th>
                  <th className="py-2.5 px-4">Category</th>
                  <th className="py-2.5 px-4">Enrolled Groups</th>
                  <th className="py-2.5 px-4">Status</th>
                  <th className="py-2.5 px-4 text-right">Ledger</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredDirectory.map((m) => {
                  const enrs = db.enrollments.filter((e) => e.memberId === m.id);
                  return (
                    <tr key={m.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-mono-num font-medium">{m.id}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{m.name}</div>
                        <div className="text-[11px] text-slate-500">{m.address}</div>
                      </td>
                      <td className="py-3 px-4 font-mono-num">{m.mobile}</td>
                      <td className="py-3 px-4 text-slate-700">{m.category}</td>
                      <td className="py-3 px-4 text-slate-600">
                        {enrs.length === 0
                          ? m.loanCustomerRef || 'General'
                          : enrs.map((e) => getGroupName(e.groupKind, e.groupId)).join(' · ')}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`font-semibold ${
                            m.status === 'Active' ? 'text-emerald-700' : 'text-slate-500'
                          }`}
                        >
                          {m.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => {
                            setLedgerMemberId(m.id);
                            setActiveTab('ledger');
                          }}
                          className="text-[#0070E0] font-semibold hover:underline"
                        >
                          Open Ledger
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MEMBER LEDGER & PAYMENT HISTORY */}
      {activeTab === 'ledger' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 bg-white border border-slate-200 rounded-2xl p-5">
            <div className="min-w-[260px]">
              <FieldLabel label="Select Member" />
              <select
                value={ledgerMemberId}
                onChange={(e) => setLedgerMemberId(e.target.value)}
                className={inputBaseClass}
              >
                {db.members.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} ({m.id} · {m.mobile})
                  </option>
                ))}
              </select>
            </div>
            <button
              type="button"
              onClick={() =>
                exportToCSV(
                  `member_ledger_${ledgerMemberId}`,
                  ['Ref #', 'Date', 'Timestamp', 'Group', 'Description', 'Mode', 'Direction', 'Amount'],
                  ledgerData.entries.map((e) => [
                    e.referenceNumber,
                    e.date,
                    formatDateTime(e.timestamp),
                    e.groupName ?? '',
                    e.description,
                    e.paymentMode,
                    e.direction,
                    e.amount,
                  ])
                )
              }
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Ledger CSV</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-4">
              <p className="text-xs text-slate-500">Total Paid (Credit)</p>
              <p className="text-xl font-bold text-emerald-700 font-mono-num mt-1">
                {formatINR(ledgerData.totalCredit)}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-4">
              <p className="text-xs text-slate-500">Total Received (Payout / Loan)</p>
              <p className="text-xl font-bold text-slate-900 font-mono-num mt-1">
                {formatINR(ledgerData.totalDebit)}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-4">
              <p className="text-xs text-slate-500">Net Member Balance ({ledgerMember?.id})</p>
              <p className="text-xl font-bold text-[#002E6E] font-mono-num mt-1">
                {formatINR(ledgerData.netBalance)}
              </p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200">
              <h4 className="text-sm font-bold text-[#002E6E]">
                Payment History — {ledgerMember?.name ?? ledgerMemberId}
              </h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                    <th className="py-2.5 px-4">Ref #</th>
                    <th className="py-2.5 px-4">Date &amp; Time</th>
                    <th className="py-2.5 px-4">Account / Group</th>
                    <th className="py-2.5 px-4">Details</th>
                    <th className="py-2.5 px-4">Mode</th>
                    <th className="py-2.5 px-4 text-right">Amount</th>
                    <th className="py-2.5 px-4 text-right">Receipt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {ledgerData.entries.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-500">
                        No payment history for this member yet.
                      </td>
                    </tr>
                  ) : (
                    ledgerData.entries.map((e) => (
                      <tr key={e.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono-num font-medium">{e.referenceNumber}</td>
                        <td className="py-3 px-4 font-mono-num">{formatDateTime(e.timestamp)}</td>
                        <td className="py-3 px-4">{e.groupName}</td>
                        <td className="py-3 px-4">{e.description}</td>
                        <td className="py-3 px-4">{e.paymentMode}</td>
                        <td
                          className={`py-3 px-4 text-right font-mono-num font-semibold ${
                            e.direction === 'credit' ? 'text-emerald-700' : 'text-red-600'
                          }`}
                        >
                          {e.direction === 'credit' ? '+' : '-'} {formatINR(e.amount)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => {
                              const saved = db.receipts.find(
                                (r) => r.receiptNumber === e.referenceNumber
                              );
                              if (saved) setActiveReceipt(saved);
                            }}
                            className="inline-flex items-center gap-1 text-[#0070E0] font-semibold hover:underline"
                          >
                            <ReceiptText className="w-3.5 h-3.5" />
                            <span>View</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ADD MEMBER */}
      {activeTab === 'add' && (
        <form
          onSubmit={handleAddMember}
          className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 max-w-2xl"
        >
          <h3 className="text-base font-bold text-[#002E6E] font-display">
            Member Registration Form
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <FieldLabel label="Member ID (Auto)" />
              <input type="text" readOnly value={nextMemId} className={monoInputClass} />
            </div>
            <div>
              <FieldLabel label="Full Name" required />
              <input
                type="text"
                required
                value={addName}
                onChange={(e) => setAddName(e.target.value)}
                className={inputBaseClass}
              />
            </div>
            <div>
              <FieldLabel label="Mobile Number" required />
              <input
                type="tel"
                required
                value={addMobile}
                onChange={(e) => setAddMobile(e.target.value)}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Joining Date" required />
              <input
                type="date"
                required
                value={addJoinDate}
                onChange={(e) => setAddJoinDate(e.target.value)}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Member Category" required />
              <select
                value={addCategory}
                onChange={(e) => setAddCategory(e.target.value as MemberCategory)}
                className={inputBaseClass}
              >
                <option value="BC Member">BC Member</option>
                <option value="Lucky Draw">Lucky Draw</option>
                <option value="Loan Customer">Loan Customer</option>
                <option value="General">General</option>
              </select>
            </div>
            <div>
              <FieldLabel label="Initial Balance (₹)" />
              <input
                type="number"
                value={addInitialBal}
                onChange={(e) => setAddInitialBal(Number(e.target.value))}
                className={monoInputClass}
              />
            </div>
            <div className="sm:col-span-2">
              <FieldLabel label="Address" required />
              <input
                type="text"
                required
                value={addAddress}
                onChange={(e) => setAddAddress(e.target.value)}
                className={inputBaseClass}
              />
            </div>
            <div>
              <FieldLabel label="Nominee Name" />
              <input
                type="text"
                value={addNominee}
                onChange={(e) => setAddNominee(e.target.value)}
                className={inputBaseClass}
              />
            </div>
            <div>
              <FieldLabel label="Loan Customer Reference" />
              <input
                type="text"
                value={addLoanRef}
                onChange={(e) => setAddLoanRef(e.target.value)}
                placeholder="Optional LON-XXXX"
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Aadhaar (Optional)" />
              <input
                type="text"
                value={addAadhaar}
                onChange={(e) => setAddAadhaar(e.target.value)}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Member Status" required />
              <select
                value={addStatus}
                onChange={(e) => setAddStatus(e.target.value as RecordStatus)}
                className={inputBaseClass}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>
          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
            >
              Register Member
            </button>
          </div>
        </form>
      )}

      {/* MODIFY MEMBER */}
      {activeTab === 'modify' && (
        <form
          onSubmit={handleModifyMember}
          className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5 max-w-3xl"
        >
          <h3 className="text-base font-bold text-[#002E6E] font-display">Modify Member Details</h3>
          <div>
            <FieldLabel label="Select Member" required />
            <select
              value={modMemberId}
              onChange={(e) => setModMemberId(e.target.value)}
              className={inputBaseClass}
            >
              {activeMembersList.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.id} · {m.mobile})
                </option>
              ))}
            </select>
          </div>

          {selectedModMember && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2 border-t border-slate-100">
              <div className="p-4 bg-[#F4F7FB] border border-slate-200 rounded-xl space-y-2 text-xs">
                <p className="font-semibold text-slate-700">Previous Info</p>
                <p>Name: {selectedModMember.name}</p>
                <p>Mobile: {selectedModMember.mobile}</p>
                <p>Category: {selectedModMember.category}</p>
                <p>Address: {selectedModMember.address}</p>
                <p>Status: {selectedModMember.status}</p>
              </div>
              <div className="space-y-3">
                <div>
                  <FieldLabel label="New Name" required />
                  <input
                    type="text"
                    required
                    value={modName}
                    onChange={(e) => setModName(e.target.value)}
                    className={inputBaseClass}
                  />
                </div>
                <div>
                  <FieldLabel label="New Mobile" required />
                  <input
                    type="tel"
                    required
                    value={modMobile}
                    onChange={(e) => setModMobile(e.target.value)}
                    className={monoInputClass}
                  />
                </div>
                <div>
                  <FieldLabel label="Category" required />
                  <select
                    value={modCategory}
                    onChange={(e) => setModCategory(e.target.value as MemberCategory)}
                    className={inputBaseClass}
                  >
                    <option value="BC Member">BC Member</option>
                    <option value="Lucky Draw">Lucky Draw</option>
                    <option value="Loan Customer">Loan Customer</option>
                    <option value="General">General</option>
                  </select>
                </div>
                <div>
                  <FieldLabel label="New Address" required />
                  <input
                    type="text"
                    required
                    value={modAddress}
                    onChange={(e) => setModAddress(e.target.value)}
                    className={inputBaseClass}
                  />
                </div>
                <div>
                  <FieldLabel label="Status" />
                  <select
                    value={modStatus}
                    onChange={(e) => setModStatus(e.target.value as RecordStatus)}
                    className={inputBaseClass}
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
            >
              Update Member
            </button>
          </div>
        </form>
      )}

      {/* TRANSFER MEMBER */}
      {activeTab === 'transfer' && (
        <form
          onSubmit={handleTransferMember}
          className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 max-w-2xl"
        >
          <h3 className="text-base font-bold text-[#002E6E] font-display">Member Group Transfer</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <FieldLabel label="Select Member" required />
              <select
                value={trfMemberId}
                onChange={(e) => setTrfMemberId(e.target.value)}
                className={inputBaseClass}
              >
                {activeMembersList.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} ({m.id})
                  </option>
                ))}
              </select>
            </div>
            <div className="sm:col-span-2">
              <FieldLabel label="Current Enrollment" required />
              <select
                value={fromEnrollmentId}
                onChange={(e) => setFromEnrollmentId(e.target.value)}
                className={inputBaseClass}
              >
                {memberEnrollments.length === 0 && <option value="">No group enrollments</option>}
                {memberEnrollments.map((enr) => (
                  <option key={enr.id} value={enr.id}>
                    {enr.groupKind.toUpperCase()} — {getGroupName(enr.groupKind, enr.groupId)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <FieldLabel label="Destination Kind" required />
              <select
                value={toGroupKind}
                onChange={(e) => setToGroupKind(e.target.value as 'bc' | 'luckydraw')}
                className={inputBaseClass}
              >
                <option value="bc">BC Group</option>
                <option value="luckydraw">Lucky Draw Group</option>
              </select>
            </div>
            <div>
              <FieldLabel label="Destination Group" required />
              <select
                value={toGroupId}
                onChange={(e) => setToGroupId(e.target.value)}
                className={inputBaseClass}
              >
                {(toGroupKind === 'bc'
                  ? db.bcGroups.filter((g) => !g.isDeleted)
                  : db.luckyDrawGroups
                ).map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <FieldLabel label="Transfer Date" required />
              <input
                type="date"
                required
                value={trfDate}
                onChange={(e) => setTrfDate(e.target.value)}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Reason" required />
              <input
                type="text"
                required
                value={trfReason}
                onChange={(e) => setTrfReason(e.target.value)}
                className={inputBaseClass}
              />
            </div>
          </div>
          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={!fromEnrollmentId}
              className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl disabled:opacity-50"
            >
              Transfer Member
            </button>
          </div>
        </form>
      )}

      {/* SOFT DELETE MEMBER */}
      {activeTab === 'delete' && (
        <form
          onSubmit={handleDeleteMember}
          className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 max-w-2xl"
        >
          <h3 className="text-base font-bold text-[#002E6E] font-display">
            Soft Delete Member (Audit Preserved)
          </h3>
          <p className="text-xs text-slate-500">
            Marks member Inactive and archives them with reason while preserving financial ledgers.
          </p>
          <div>
            <FieldLabel label="Select Member" required />
            <select
              value={delMemberId}
              onChange={(e) => setDelMemberId(e.target.value)}
              className={inputBaseClass}
            >
              {activeMembersList.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.id} — {m.name} ({m.mobile})
                </option>
              ))}
            </select>
          </div>
          <div>
            <FieldLabel label="Reason" required />
            <textarea
              rows={2}
              required
              value={delReason}
              onChange={(e) => setDelReason(e.target.value)}
              className={`${inputBaseClass} min-h-[72px]`}
            />
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={!delMemberId}
              className="px-5 py-2.5 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-xl disabled:opacity-50"
            >
              Confirm Soft Delete
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
