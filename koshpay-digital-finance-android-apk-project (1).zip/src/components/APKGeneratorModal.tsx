import React, { useEffect, useState } from 'react';
import {
  Check,
  CheckCircle2,
  Cloud,
  Copy,
  Download,
  ExternalLink,
  Globe,
  Smartphone,
  Terminal,
  X,
} from 'lucide-react';
import { Language } from '../types/finance';

type GeneratorMethod = 'pwa_to_apk' | 'capacitor' | 'cloud_actions';

export interface APKGeneratorModalProps {
  open: boolean;
  onClose: () => void;
  lang: Language;
  appName: string;
  packageId: string;
  version: string;
  isExportingApk: boolean;
  onDownloadZip: () => Promise<void>;
}

export const APKGeneratorModal: React.FC<APKGeneratorModalProps> = ({
  open,
  onClose,
  lang,
  appName,
  packageId,
  version,
  isExportingApk,
  onDownloadZip,
}) => {
  const [method, setMethod] = useState<GeneratorMethod>('pwa_to_apk');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const sanitizedPkg = packageId.trim() || 'com.koshpay.finance';
  const safeAppName = appName.trim() || 'KoshPay Finance';
  const safeVersion = version.trim() || '1.0.0';

  const copyText = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey((prev) => (prev === key ? null : prev)), 2000);
    } catch {
      // Clipboard write may be blocked in restricted contexts
    }
  };

  const bubblewrapCommands = `npm install -g @bubblewrap/cli\nbubblewrap init --manifest=${appUrl}/manifest.webmanifest\nbubblewrap build`;
  const capacitorCommands = `npm install\nnpm run build\nrm -rf android\nnpx cap add android\nnpx cap sync android\nnpx cap open android`;
  const gradleCommand = `cd android && ./gradlew assembleDebug`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/55 p-3 sm:p-5"
      role="dialog"
      aria-modal="true"
      aria-label={lang === 'mr' ? 'Android APK जनरेटर मार्गदर्शिका' : 'APK Generator Guide'}
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[90vh] flex flex-col bg-white rounded-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#002E6E] text-white px-5 py-4 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <Smartphone className="w-5 h-5 text-sky-300" />
            </div>
            <div className="min-w-0">
              <h2 className="text-base font-bold font-display truncate">
                {lang === 'mr'
                  ? 'Android APK तयार करण्याची मार्गदर्शिका'
                  : 'Convert PWA to Android APK — Guide'}
              </h2>
              <p className="text-[11px] text-blue-200 font-mono-num truncate">
                {safeAppName} · {sanitizedPkg} · v{safeVersion}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-2 rounded-xl text-blue-100 hover:bg-white/10 hover:text-white transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Method Tabs */}
        <div className="px-5 pt-3.5 pb-2.5 border-b border-slate-200 bg-[#F4F7FB] flex flex-wrap gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setMethod('pwa_to_apk')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl transition-colors min-h-[40px] ${
              method === 'pwa_to_apk'
                ? 'bg-[#0070E0] text-white'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{lang === 'mr' ? '1. PWA-to-APK सेवा' : '1. PWA-to-APK Services'}</span>
          </button>
          <button
            type="button"
            onClick={() => setMethod('capacitor')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl transition-colors min-h-[40px] ${
              method === 'capacitor'
                ? 'bg-[#0070E0] text-white'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>{lang === 'mr' ? '2. Capacitor + Android Studio' : '2. Capacitor + Android Studio'}</span>
          </button>
          <button
            type="button"
            onClick={() => setMethod('cloud_actions')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl transition-colors min-h-[40px] ${
              method === 'cloud_actions'
                ? 'bg-[#0070E0] text-white'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Cloud className="w-3.5 h-3.5" />
            <span>{lang === 'mr' ? '3. Cloud APK (GitHub)' : '3. Automatic Cloud Build'}</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-700 leading-relaxed">
          {/* PWA Readiness Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 text-[#002E6E]">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-medium">Web Manifest Ready</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-medium">Offline Service Worker</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-medium">192px &amp; 512px PNG Icons</span>
            </div>
          </div>

          {method === 'pwa_to_apk' && (
            <div className="space-y-3.5">
              {/* Step 1 */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                <p className="font-bold text-[#002E6E]">
                  Step 1 · {lang === 'mr' ? 'तुमची App URL कॉपी करा' : 'Copy Your Live PWA URL'}
                </p>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2.5 bg-[#F4F7FB] border border-slate-200 rounded-lg">
                  <span className="font-mono-num text-[11px] text-slate-800 break-all">
                    {appUrl}
                  </span>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => copyText('url', appUrl)}
                      className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-[11px] font-semibold text-[#002E6E] bg-white border border-slate-200 hover:bg-slate-50 rounded-lg min-h-[36px]"
                    >
                      {copiedKey === 'url' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedKey === 'url' ? 'Copied' : 'Copy URL'}</span>
                    </button>
                    <a
                      href="https://www.pwabuilder.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => copyText('url', appUrl)}
                      className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-[11px] font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-lg min-h-[36px]"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>{lang === 'mr' ? 'PWABuilder उघडा' : 'Copy & Open PWABuilder'}</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* Step 2: PWABuilder */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-1.5">
                <p className="font-bold text-[#002E6E]">
                  Step 2 ·{' '}
                  {lang === 'mr'
                    ? 'PWABuilder.com वरून .APK डाउनलोड करा (कोणत्याही कोडशिवाय)'
                    : 'Generate Signed APK via PWABuilder (No Coding Required)'}
                </p>
                <p>
                  {lang === 'mr'
                    ? '१. वरच्या बटनावर क्लिक करून PWABuilder उघडा आणि कॉपी केलेली URL पेस्ट करून Start दाबा.'
                    : '1. Paste your copied URL into pwabuilder.com and click Start.'}
                </p>
                <p>
                  {lang === 'mr' ? (
                    <>
                      २. <strong>Package for Stores → Android → Generate Package</strong> निवडा आणि Package ID{' '}
                      <span className="font-mono-num font-semibold">{sanitizedPkg}</span> भरा.
                    </>
                  ) : (
                    <>
                      2. Select <strong>Package for Stores → Android → Generate Package</strong> and enter Package ID{' '}
                      <span className="font-mono-num font-semibold">{sanitizedPkg}</span>.
                    </>
                  )}
                </p>
                <p>
                  {lang === 'mr'
                    ? '३. डाउनलोड झालेली ZIP फाईल उघडून त्यातील स्वाक्षरी केलेली .apk फाईल Android फोनवर इन्स्टॉल करा.'
                    : '3. Extract the downloaded package ZIP and install the generated .apk on your Android device.'}
                </p>
              </div>

              {/* Step 3: Bubblewrap TWA CLI */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-bold text-[#002E6E]">
                    Step 3 ·{' '}
                    {lang === 'mr'
                      ? 'पर्याय: Google Bubblewrap CLI द्वारे TWA APK'
                      : 'Optional CLI: Google Bubblewrap (PWA-to-APK)'}
                  </p>
                  <button
                    type="button"
                    onClick={() => copyText('bubblewrap', bubblewrapCommands)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-[#002E6E] bg-slate-100 hover:bg-blue-50 rounded-lg"
                  >
                    {copiedKey === 'bubblewrap' ? (
                      <Check className="w-3 h-3 text-emerald-600" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                    <span>{copiedKey === 'bubblewrap' ? 'Copied' : 'Copy CLI'}</span>
                  </button>
                </div>
                <pre className="p-3 rounded-xl bg-slate-900 text-slate-100 font-mono-num text-[11px] overflow-x-auto leading-relaxed">
{bubblewrapCommands}
                </pre>
              </div>
            </div>
          )}

          {method === 'capacitor' && (
            <div className="space-y-3.5">
              {/* Step 1 */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="font-bold text-[#002E6E]">
                    Step 1 ·{' '}
                    {lang === 'mr'
                      ? 'Capacitor Android प्रोजेक्ट (.zip) डाउनलोड करा'
                      : 'Download Pre-Configured Capacitor Project (.zip)'}
                  </p>
                  <button
                    type="button"
                    disabled={isExportingApk}
                    onClick={onDownloadZip}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] disabled:opacity-60 rounded-xl min-h-[38px]"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{isExportingApk ? 'Packaging...' : 'Download APK Project (.zip)'}</span>
                  </button>
                </div>
                <p className="text-slate-600">
                  {lang === 'mr' ? (
                    <>
                      ZIP एक्स्ट्रॅक्ट करा—यात <span className="font-mono-num">capacitor.config.json</span>, PNG आयकॉन्स, संपूर्ण React कोड आणि स्वयंचलित <span className="font-mono-num">build-apk.bat</span> / <span className="font-mono-num">build-apk.sh</span> स्क्रिप्ट्स आहेत.
                    </>
                  ) : (
                    <>
                      Extract the ZIP archive. It includes <span className="font-mono-num">capacitor.config.json</span>, PNG icons, your full React source code, and 1-click <span className="font-mono-num">build-apk.bat</span> (Windows) / <span className="font-mono-num">build-apk.sh</span> (Mac/Linux) scripts.
                    </>
                  )}
                </p>
              </div>

              {/* Step 2 */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-bold text-[#002E6E]">
                    Step 2 ·{' '}
                    {lang === 'mr'
                      ? 'वेब बंडल तयार करा व Capacitor Android सिंक करा'
                      : 'Build Offline Web Assets & Sync Capacitor Android'}
                  </p>
                  <button
                    type="button"
                    onClick={() => copyText('cap', capacitorCommands)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-[#002E6E] bg-slate-100 hover:bg-blue-50 rounded-lg"
                  >
                    {copiedKey === 'cap' ? (
                      <Check className="w-3 h-3 text-emerald-600" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                    <span>{copiedKey === 'cap' ? 'Copied' : 'Copy Commands'}</span>
                  </button>
                </div>
                <pre className="p-3 rounded-xl bg-slate-900 text-slate-100 font-mono-num text-[11px] overflow-x-auto leading-relaxed">
{capacitorCommands}
                </pre>
              </div>

              {/* Step 3 */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-bold text-[#002E6E]">
                    Step 3 ·{' '}
                    {lang === 'mr'
                      ? 'Android Studio किंवा Gradle मधून .APK बनवा'
                      : 'Compile Debug or Signed Release APK'}
                  </p>
                  <button
                    type="button"
                    onClick={() => copyText('gradle', gradleCommand)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-[#002E6E] bg-slate-100 hover:bg-blue-50 rounded-lg"
                  >
                    {copiedKey === 'gradle' ? (
                      <Check className="w-3 h-3 text-emerald-600" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                    <span>{copiedKey === 'gradle' ? 'Copied' : 'Copy Gradle Cmd'}</span>
                  </button>
                </div>
                <p>
                  <strong>Android Studio:</strong> Open <strong>Build → Build Bundle(s) / APK(s) → Build APK(s)</strong> (or <strong>Generate Signed Bundle / APK</strong> for release signing).
                </p>
                <p>
                  <strong>CLI:</strong> Run{' '}
                  <span className="font-mono-num bg-slate-100 px-1.5 py-0.5 rounded">
                    {gradleCommand}
                  </span>{' '}
                  — APK output is saved at{' '}
                  <span className="font-mono-num text-[#002E6E]">
                    android/app/build/outputs/apk/debug/app-debug.apk
                  </span>
                  .
                </p>
              </div>
            </div>
          )}

          {method === 'cloud_actions' && (
            <div className="space-y-3.5">
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2.5">
                <p className="font-bold text-[#002E6E]">
                  Step 1 ·{' '}
                  {lang === 'mr'
                    ? 'स्वयंचलित GitHub Workflow असलेली ZIP डाउनलोड करा'
                    : 'Download APK Project ZIP (Includes Cloud Workflow)'}
                </p>
                <p className="text-slate-600">
                  {lang === 'mr' ? (
                    <>
                      या ZIP मध्ये <span className="font-mono-num">.github/workflows/build-apk.yml</span> समाविष्ट आहे, त्यामुळे तुमच्या संगणकावर Android Studio इन्स्टॉल करण्याची गरज नाही.
                    </>
                  ) : (
                    <>
                      The archive includes <span className="font-mono-num">.github/workflows/build-apk.yml</span> pre-configured with Node 20, JDK 17, and Capacitor Android—no local Android Studio needed.
                    </>
                  )}
                </p>
                <button
                  type="button"
                  disabled={isExportingApk}
                  onClick={onDownloadZip}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] disabled:opacity-60 rounded-xl min-h-[38px]"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isExportingApk ? 'Packaging...' : 'Download APK Project (.zip)'}</span>
                </button>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-1.5">
                <p className="font-bold text-[#002E6E]">
                  Step 2 · {lang === 'mr' ? 'GitHub Repository मध्ये अपलोड करा' : 'Push Extracted Files to GitHub'}
                </p>
                <p>
                  {lang === 'mr'
                    ? 'कोणत्याही मोफत GitHub रेपोमध्ये फाईल्स पुश/अपलोड करा (.github फोल्डरसह).'
                    : 'Upload or push the extracted project folder (including the .github/ directory) to any GitHub repository.'}
                </p>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-1.5">
                <p className="font-bold text-[#002E6E]">
                  Step 3 ·{' '}
                  {lang === 'mr'
                    ? 'Actions मधून तयार झालेली .APK फाईल डाउनलोड करा'
                    : 'Download Compiled APK from Actions Artifacts'}
                </p>
                <p>
                  {lang === 'mr'
                    ? 'GitHub मधील Actions टॅब उघडून Build Android APK वर्कफ्लो चालवा आणि Artifacts मधून तयार .apk फाईल डाउनलोड करा.'
                    : 'Open the Actions tab in GitHub, run Build Android APK (auto-runs on push), wait ~2–3 minutes, and download the compiled .apk under Artifacts.'}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 border-t border-slate-200 bg-white flex items-center justify-between gap-3 shrink-0">
          <span className="text-[11px] text-slate-500">
            {lang === 'mr'
              ? 'सर्व डेटा फोनवर ऑफलाइन सुरक्षित राहतो.'
              : 'All ledger records stay offline on device.'}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#002E6E] hover:bg-[#001F4D] rounded-xl min-h-[40px]"
          >
            {lang === 'mr' ? 'बंद करा' : 'Close Guide'}
          </button>
        </div>
      </div>
    </div>
  );
};
