import React, { useState } from 'react';
import { Fingerprint, Lock } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';

export const PinLockScreen: React.FC = () => {
  const { db, unlockApp } = useFinance();
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleDigit = (d: string) => {
    if (pin.length >= 4) return;
    const next = pin + d;
    setPin(next);
    setError(false);
    if (next.length === 4) {
      const ok = unlockApp(next);
      if (!ok) {
        setError(true);
        setTimeout(() => setPin(''), 350);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#002E6E] flex items-center justify-center p-4">
      <div className="w-full max-w-xs bg-white rounded-3xl p-6 text-center space-y-6">
        <div className="w-12 h-12 rounded-2xl bg-blue-50 text-[#0070E0] flex items-center justify-center mx-auto">
          <Lock className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-base font-bold text-[#002E6E] font-display">
            {db.settings.businessName}
          </h1>
          <p className="text-xs text-slate-500 mt-1">Enter 4-digit App PIN to unlock</p>
        </div>

        <div className="flex items-center justify-center gap-3">
          {[0, 1, 2, 3].map((idx) => (
            <div
              key={idx}
              className={`w-3.5 h-3.5 rounded-full border-2 transition-colors ${
                pin.length > idx
                  ? error
                    ? 'bg-red-600 border-red-600'
                    : 'bg-[#0070E0] border-[#0070E0]'
                  : 'border-slate-300'
              }`}
            />
          ))}
        </div>

        {error && <p className="text-xs font-medium text-red-600">Incorrect PIN. Try again.</p>}

        <div className="grid grid-cols-3 gap-2.5">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleDigit(digit)}
              className="h-12 rounded-xl bg-slate-50 hover:bg-blue-50 text-base font-bold text-[#002E6E] font-mono-num transition-colors"
            >
              {digit}
            </button>
          ))}
          <button
            type="button"
            onClick={() => {
              if (db.settings.biometricEnabled) unlockApp(db.settings.appPin);
            }}
            disabled={!db.settings.biometricEnabled}
            className="h-12 rounded-xl bg-slate-50 hover:bg-blue-50 text-[#0070E0] flex items-center justify-center disabled:opacity-30"
            aria-label="Quick Biometric Unlock"
          >
            <Fingerprint className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={() => handleDigit('0')}
            className="h-12 rounded-xl bg-slate-50 hover:bg-blue-50 text-base font-bold text-[#002E6E] font-mono-num"
          >
            0
          </button>
          <button
            type="button"
            onClick={() => setPin((p) => p.slice(0, -1))}
            className="h-12 rounded-xl bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-600"
          >
            Clear
          </button>
        </div>
      </div>
    </div>
  );
};
