import React, { useEffect, useMemo, useState } from 'react';
import { Download, ReceiptText } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import {
  EMIFrequency,
  InterestType,
  LoanApprovalStatus,
  LoanType,
  PaymentMode,
} from '../types/finance';
import { exportToCSV, formatDateOnly, formatINR, generateNextId, todayISO } from '../utils/formatters';
import { calculateLoanSchedule } from '../utils/loanCalculator';
import { FieldLabel, FormAlert, SectionHeader, inputBaseClass, monoInputClass } from './FormControls';

type LoanTab = 'emi_collect' | 'new_loan' | 'schedule' | 'modify';

export const LoanManagementView: React.FC = () => {
  const {
    db,
    lang,
    getLoanLedger,
    addLoanAccount,
    updateLoanAccount,
    collectEMIPayment,
    setActiveReceipt,
  } = useFinance();

  const [activeTab, setActiveTab] = useState<LoanTab>('emi_collect');
  const [feedback, setFeedback] = useState<{ type: 'error' | 'success'; message: string } | null>(null);

  // --- New Loan Registration ---
  const [linkMemberId, setLinkMemberId] = useState<string>('');
  const [customerName, setCustomerName] = useState('');
  const [mobile, setMobile] = useState('');
  const [address, setAddress] = useState('');
  const [loanType, setLoanType] = useState<LoanType>('Personal Loan');
  const [loanAmount, setLoanAmount] = useState(50000);
  const [interestRate, setInterestRate] = useState(18);
  const [interestType, setInterestType] = useState<InterestType>('Reducing Balance');
  const [loanDate, setLoanDate] = useState(todayISO());
  const [emiStartDate, setEmiStartDate] = useState(todayISO());
  const [emiFrequency, setEmiFrequency] = useState<EMIFrequency>('Monthly');
  const [totalInstallments, setTotalInstallments] = useState(12);
  const [processingFee, setProcessingFee] = useState(500);
  const [disbursementMode, setDisbursementMode] = useState<PaymentMode>('Bank');
  const [loanStatus, setLoanStatus] = useState<LoanApprovalStatus>('Active');
  const [loanRemarks, setLoanRemarks] = useState('');

  const nextLoanId = useMemo(
    () => generateNextId('LON', db.loans.map((l) => l.id), 4),
    [db.loans]
  );

  useEffect(() => {
    if (!linkMemberId) return;
    const mem = db.members.find((m) => m.id === linkMemberId);
    if (mem) {
      setCustomerName(mem.name);
      setMobile(mem.mobile);
      setAddress(mem.address);
    }
  }, [linkMemberId, db.members]);

  const liveCalc = useMemo(
    () =>
      calculateLoanSchedule({
        principal: loanAmount,
        annualRatePercent: interestRate,
        interestType,
        totalInstallments,
        frequency: emiFrequency,
        emiStartDate,
      }),
    [loanAmount, interestRate, interestType, totalInstallments, emiFrequency, emiStartDate]
  );

  const handleCreateLoan = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const res = addLoanAccount({
      memberId: linkMemberId || undefined,
      customerName,
      mobile,
      address,
      loanType,
      loanAmount,
      interestRate,
      interestType,
      loanDate,
      emiStartDate,
      emiFrequency,
      totalInstallments,
      processingFee,
      disbursementMode,
      loanStatus,
      remarks: loanRemarks,
    });
    if (res.ok) {
      setFeedback({
        type: 'success',
        message: `Loan ${res.id} registered (${interestType}, EMI ${formatINR(liveCalc.emiAmount)}). Complete schedule generated.`,
      });
      setLinkMemberId('');
      setCustomerName('');
      setMobile('');
      setAddress('');
      setLoanRemarks('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Failed to register loan.' });
    }
  };

  // --- EMI Collection ---
  const activeLoans = useMemo(
    () => db.loans.filter((l) => l.loanStatus !== 'Closed' && l.loanStatus !== 'Pending'),
    [db.loans]
  );
  const [collectLoanId, setCollectLoanId] = useState(activeLoans[0]?.id ?? db.loans[0]?.id ?? '');
  const collectLoanData = getLoanLedger(collectLoanId);
  const [emiPayDate, setEmiPayDate] = useState(todayISO());
  const [emiPayAmount, setEmiPayAmount] = useState(0);
  const [emiLateFee, setEmiLateFee] = useState(0);
  const [emiPayMode, setEmiPayMode] = useState<PaymentMode>('UPI');
  const [emiTxnRef, setEmiTxnRef] = useState('');
  const [emiRemarks, setEmiRemarks] = useState('');

  useEffect(() => {
    if (collectLoanData.nextDueItem) {
      const rem = Math.max(
        0,
        Math.round(
          (collectLoanData.nextDueItem.emiAmount - collectLoanData.nextDueItem.paidAmount) * 100
        ) / 100
      );
      setEmiPayAmount(rem);
    } else {
      setEmiPayAmount(0);
    }
  }, [collectLoanId, collectLoanData.nextDueItem]);

  const handleCollectEMI = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!collectLoanId) {
      setFeedback({ type: 'error', message: 'Please select an active loan.' });
      return;
    }
    const res = collectEMIPayment({
      loanId: collectLoanId,
      paymentDate: emiPayDate,
      amountPaid: emiPayAmount,
      lateFee: emiLateFee,
      paymentMode: emiPayMode,
      transactionRef: emiTxnRef,
      remarks: emiRemarks,
    });
    if (res.ok) {
      setFeedback({
        type: 'success',
        message: `EMI Payment saved (${res.receipt?.receiptNumber}). Outstanding balance updated.`,
      });
      setEmiLateFee(0);
      setEmiTxnRef('');
      setEmiRemarks('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'EMI collection failed.' });
    }
  };

  // --- Schedule & Ledger Inspector ---
  const [inspectLoanId, setInspectLoanId] = useState(db.loans[0]?.id ?? '');
  const inspectData = getLoanLedger(inspectLoanId);
  const today = todayISO();

  // --- Modify Loan ---
  const [modLoanId, setModLoanId] = useState(db.loans[0]?.id ?? '');
  const modLoan = db.loans.find((l) => l.id === modLoanId);
  const [modStatus, setModStatus] = useState<LoanApprovalStatus>('Active');
  const [modRate, setModRate] = useState(18);
  const [modTenure, setModTenure] = useState(12);
  const [modRemarks, setModRemarks] = useState('');

  useEffect(() => {
    if (modLoan) {
      setModStatus(modLoan.loanStatus);
      setModRate(modLoan.interestRate);
      setModTenure(modLoan.totalInstallments);
      setModRemarks(modLoan.remarks ?? '');
    }
  }, [modLoan]);

  const handleModifyLoan = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!modLoanId) return;
    const res = updateLoanAccount(modLoanId, {
      loanStatus: modStatus,
      interestRate: modRate,
      totalInstallments: modTenure,
      remarks: modRemarks,
    });
    setFeedback(
      res.ok
        ? {
            type: 'success',
            message: `Loan ${modLoanId} updated. Historical payment records remain untouched.`,
          }
        : { type: 'error', message: res.error ?? 'Update failed.' }
    );
  };

  const tabs: { id: LoanTab; label: string }[] = [
    { id: 'emi_collect', label: lang === 'mr' ? 'EMI वसुली (Collect)' : 'EMI Collection' },
    { id: 'new_loan', label: lang === 'mr' ? 'नवीन कर्ज नोंदणी' : 'New Loan Registration' },
    { id: 'schedule', label: lang === 'mr' ? 'EMI वेळापत्रक व लेजर' : 'EMI Schedule & Ledger' },
    { id: 'modify', label: lang === 'mr' ? 'कर्ज बदल / बंद करा' : 'Modify / Close Loan' },
  ];

  return (
    <div className="space-y-6">
      <SectionHeader
        title={lang === 'mr' ? 'कर्ज आणि EMI व्यवस्थापन' : 'Loan & EMI Management'}
        subtitle={
          lang === 'mr'
            ? 'Flat व Reducing Balance व्याज, स्वयंचलित EMI वेळापत्रक, अर्धवट/आगाऊ हप्ता, Overdue अलर्ट व कर्ज खातेवही'
            : 'Flat & Reducing Balance EMI calculator, complete installment schedules, partial/advance payments & loan ledgers'
        }
        actions={
          <button
            type="button"
            onClick={() =>
              exportToCSV(
                'loans_portfolio_report',
                [
                  'Loan ID',
                  'Customer',
                  'Mobile',
                  'Type',
                  'Principal',
                  'Rate %',
                  'Interest Type',
                  'EMI',
                  'Principal Outstanding',
                  'Interest Outstanding',
                  'Status',
                ],
                db.loans.map((l) => [
                  l.id,
                  l.customerName,
                  l.mobile,
                  l.loanType,
                  l.loanAmount,
                  l.interestRate,
                  l.interestType,
                  l.emiAmount,
                  l.principalOutstanding,
                  l.interestOutstanding,
                  l.loanStatus,
                ])
              )
            }
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Loan Report</span>
          </button>
        }
      />

      {/* Segmented Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1.5 bg-slate-100 rounded-xl no-print">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => {
              setActiveTab(tab.id);
              setFeedback(null);
            }}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-white text-[#002E6E] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {feedback && (
        <FormAlert
          type={feedback.type}
          message={feedback.message}
          onDismiss={() => setFeedback(null)}
        />
      )}

      {/* TAB 1: EMI COLLECTION */}
      {activeTab === 'emi_collect' && (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <form
            onSubmit={handleCollectEMI}
            className="lg:col-span-3 bg-white border border-slate-200 rounded-2xl p-6 space-y-5"
          >
            <h3 className="text-base font-bold text-[#002E6E] font-display">
              EMI Payment Collection (Partial &amp; Advance Supported)
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <FieldLabel label="Select Loan Account" required />
                <select
                  value={collectLoanId}
                  onChange={(e) => setCollectLoanId(e.target.value)}
                  className={inputBaseClass}
                >
                  {db.loans.length === 0 && <option value="">No loans registered</option>}
                  {db.loans.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.id} — {l.customerName} (EMI {formatINR(l.emiAmount)} · {l.loanStatus})
                    </option>
                  ))}
                </select>
              </div>

              {collectLoanData.loan && (
                <div className="sm:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-[#F4F7FB] border border-slate-200 rounded-xl text-xs">
                  <div>
                    <span className="text-slate-500">Next Due Date</span>
                    <p className="font-mono-num font-semibold text-slate-900 mt-0.5">
                      {collectLoanData.nextDueItem
                        ? formatDateOnly(collectLoanData.nextDueItem.dueDate)
                        : 'All Paid'}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-500">Overdue EMIs</span>
                    <p
                      className={`font-mono-num font-semibold mt-0.5 ${
                        collectLoanData.overdueItems.length > 0 ? 'text-red-600' : 'text-emerald-700'
                      }`}
                    >
                      {collectLoanData.overdueItems.length}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-500">Principal Bal</span>
                    <p className="font-mono-num font-semibold text-slate-900 mt-0.5">
                      {formatINR(collectLoanData.loan.principalOutstanding)}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-500">Total Remaining</span>
                    <p className="font-mono-num font-semibold text-[#002E6E] mt-0.5">
                      {formatINR(collectLoanData.remainingPayable)}
                    </p>
                  </div>
                </div>
              )}

              <div>
                <FieldLabel label="Payment Date" required />
                <input
                  type="date"
                  required
                  value={emiPayDate}
                  onChange={(e) => setEmiPayDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel
                  label="Amount Paid (₹)"
                  required
                  hint="Supports partial or advance"
                />
                <input
                  type="number"
                  min={1}
                  step="0.01"
                  required
                  value={emiPayAmount}
                  onChange={(e) => setEmiPayAmount(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>

              {collectLoanData.loan && collectLoanData.nextDueItem && (
                <div className="sm:col-span-2 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setEmiPayAmount(
                        Math.round(
                          (collectLoanData.nextDueItem!.emiAmount -
                            collectLoanData.nextDueItem!.paidAmount) *
                            100
                        ) / 100
                      )
                    }
                    className="px-3 py-1.5 text-xs font-medium text-[#0070E0] bg-blue-50 hover:bg-blue-100 rounded-lg"
                  >
                    1 Exact EMI
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setEmiPayAmount(Math.round(collectLoanData.loan!.emiAmount * 2 * 100) / 100)
                    }
                    className="px-3 py-1.5 text-xs font-medium text-[#0070E0] bg-blue-50 hover:bg-blue-100 rounded-lg"
                  >
                    2 EMIs (Advance)
                  </button>
                  <button
                    type="button"
                    onClick={() => setEmiPayAmount(collectLoanData.remainingPayable)}
                    className="px-3 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg"
                  >
                    Full Settlement ({formatINR(collectLoanData.remainingPayable)})
                  </button>
                </div>
              )}

              <div>
                <FieldLabel label="Late Fee (₹)" />
                <input
                  type="number"
                  min={0}
                  value={emiLateFee}
                  onChange={(e) => setEmiLateFee(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Payment Mode" required />
                <select
                  value={emiPayMode}
                  onChange={(e) => setEmiPayMode(e.target.value as PaymentMode)}
                  className={inputBaseClass}
                >
                  <option value="UPI">UPI</option>
                  <option value="Cash">Cash</option>
                  <option value="Bank">Bank</option>
                </select>
              </div>

              <div>
                <FieldLabel label="Transaction Reference" />
                <input
                  type="text"
                  value={emiTxnRef}
                  onChange={(e) => setEmiTxnRef(e.target.value)}
                  placeholder="UPI / Bank Ref #"
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Remarks" />
                <input
                  type="text"
                  value={emiRemarks}
                  onChange={(e) => setEmiRemarks(e.target.value)}
                  placeholder="Optional note"
                  className={inputBaseClass}
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pt-4 border-t border-slate-200">
              <div>
                <span className="text-xs text-slate-500">Total Collected</span>
                <p className="text-xl font-bold text-emerald-700 font-mono-num">
                  {formatINR(emiPayAmount + emiLateFee)}
                </p>
              </div>
              <button
                type="submit"
                disabled={!collectLoanData.loan || collectLoanData.loan.loanStatus === 'Closed'}
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl transition-colors disabled:opacity-50"
              >
                Record EMI &amp; Issue Receipt
              </button>
            </div>
          </form>

          {/* Active Loans Quick Summary */}
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
            <h3 className="text-sm font-bold text-[#002E6E] font-display">
              Loan Portfolio ({db.loans.length})
            </h3>
            <div className="divide-y divide-slate-100">
              {db.loans.map((l) => {
                const led = getLoanLedger(l.id);
                return (
                  <div
                    key={l.id}
                    className="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="text-sm font-semibold text-slate-900">{l.customerName}</div>
                      <div className="text-[11px] text-slate-500">
                        {l.id} · {l.interestType} {l.interestRate}% · {l.loanStatus}
                      </div>
                      {led.overdueItems.length > 0 && (
                        <div className="text-[11px] font-medium text-red-600 mt-0.5">
                          {led.overdueItems.length} Overdue EMI(s)
                        </div>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-mono-num font-bold text-[#002E6E]">
                        {formatINR(l.principalOutstanding)}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setInspectLoanId(l.id);
                          setActiveTab('schedule');
                        }}
                        className="text-[11px] font-semibold text-[#0070E0] hover:underline mt-0.5"
                      >
                        Schedule
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: NEW LOAN REGISTRATION */}
      {activeTab === 'new_loan' && (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <form
            onSubmit={handleCreateLoan}
            className="lg:col-span-3 bg-white border border-slate-200 rounded-2xl p-6 space-y-4"
          >
            <h3 className="text-base font-bold text-[#002E6E] font-display">
              New Loan Registration Form
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <FieldLabel label="Loan ID (Auto Generated)" />
                <input type="text" readOnly value={nextLoanId} className={monoInputClass} />
              </div>

              <div>
                <FieldLabel label="Link Existing Member (Optional)" />
                <select
                  value={linkMemberId}
                  onChange={(e) => setLinkMemberId(e.target.value)}
                  className={inputBaseClass}
                >
                  <option value="">Walk-in / External Customer</option>
                  {db.members
                    .filter((m) => !m.isDeleted)
                    .map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.id})
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <FieldLabel label="Customer Name" required />
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Borrower full name"
                  className={inputBaseClass}
                />
              </div>

              <div>
                <FieldLabel label="Mobile Number" required />
                <input
                  type="tel"
                  required
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="10-digit mobile"
                  className={monoInputClass}
                />
              </div>

              <div className="sm:col-span-2">
                <FieldLabel label="Address" required />
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Full residential/business address"
                  className={inputBaseClass}
                />
              </div>

              <div>
                <FieldLabel label="Loan Type" required />
                <select
                  value={loanType}
                  onChange={(e) => setLoanType(e.target.value as LoanType)}
                  className={inputBaseClass}
                >
                  <option value="Personal Loan">Personal Loan</option>
                  <option value="Business Loan">Business Loan</option>
                  <option value="Gold / Collateral">Gold / Collateral</option>
                  <option value="Emergency Loan">Emergency Loan</option>
                </select>
              </div>

              <div>
                <FieldLabel label="Loan Amount (₹)" required />
                <input
                  type="number"
                  min={500}
                  required
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Interest Rate (% p.a.)" required />
                <input
                  type="number"
                  min={0}
                  step="0.1"
                  required
                  value={interestRate}
                  onChange={(e) => setInterestRate(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Interest Type" required />
                <select
                  value={interestType}
                  onChange={(e) => setInterestType(e.target.value as InterestType)}
                  className={inputBaseClass}
                >
                  <option value="Reducing Balance">Reducing Balance</option>
                  <option value="Flat">Flat Interest</option>
                </select>
              </div>

              <div>
                <FieldLabel label="Loan Date" required />
                <input
                  type="date"
                  required
                  value={loanDate}
                  onChange={(e) => setLoanDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="EMI Start Date" required />
                <input
                  type="date"
                  required
                  value={emiStartDate}
                  onChange={(e) => setEmiStartDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="EMI Frequency" required />
                <select
                  value={emiFrequency}
                  onChange={(e) => setEmiFrequency(e.target.value as EMIFrequency)}
                  className={inputBaseClass}
                >
                  <option value="Monthly">Monthly</option>
                  <option value="Weekly">Weekly</option>
                </select>
              </div>

              <div>
                <FieldLabel label="Total Installments" required />
                <input
                  type="number"
                  min={1}
                  required
                  value={totalInstallments}
                  onChange={(e) => setTotalInstallments(Math.max(1, Number(e.target.value)))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Processing Fee (₹)" />
                <input
                  type="number"
                  min={0}
                  value={processingFee}
                  onChange={(e) => setProcessingFee(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Disbursement Mode" required />
                <select
                  value={disbursementMode}
                  onChange={(e) => setDisbursementMode(e.target.value as PaymentMode)}
                  className={inputBaseClass}
                >
                  <option value="Bank">Bank</option>
                  <option value="UPI">UPI</option>
                  <option value="Cash">Cash</option>
                </select>
              </div>

              <div>
                <FieldLabel label="Loan Status" required />
                <select
                  value={loanStatus}
                  onChange={(e) => setLoanStatus(e.target.value as LoanApprovalStatus)}
                  className={inputBaseClass}
                >
                  <option value="Active">Active (Disbursed)</option>
                  <option value="Approved">Approved</option>
                  <option value="Pending">Pending Approval</option>
                </select>
              </div>

              <div>
                <FieldLabel label="Remarks" />
                <input
                  type="text"
                  value={loanRemarks}
                  onChange={(e) => setLoanRemarks(e.target.value)}
                  placeholder="Guarantor / collateral note"
                  className={inputBaseClass}
                />
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl transition-colors"
              >
                Register Loan &amp; Generate Schedule
              </button>
            </div>
          </form>

          {/* Live EMI Preview Panel */}
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-6 space-y-4 self-start">
            <h3 className="text-sm font-bold text-[#002E6E] font-display">
              Live EMI Calculator Preview ({interestType})
            </h3>
            <div className="p-4 bg-[#002E6E] text-white rounded-xl">
              <p className="text-xs text-blue-200">Calculated {emiFrequency} EMI</p>
              <p className="text-2xl font-bold font-mono-num mt-1">
                {formatINR(liveCalc.emiAmount)}
              </p>
            </div>
            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Loan Principal</span>
                <span className="font-mono-num font-semibold">{formatINR(loanAmount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Total Interest Payable</span>
                <span className="font-mono-num font-semibold text-amber-700">
                  {formatINR(liveCalc.totalInterest)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Net Disbursed (After Fee)</span>
                <span className="font-mono-num font-semibold">
                  {formatINR(Math.max(0, loanAmount - processingFee))}
                </span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200">
                <span className="font-semibold text-slate-900">Total Repayable</span>
                <span className="font-mono-num font-bold text-[#002E6E]">
                  {formatINR(liveCalc.totalPayable)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: EMI SCHEDULE & LOAN LEDGER */}
      {activeTab === 'schedule' && (
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 bg-white border border-slate-200 rounded-2xl p-5">
            <div className="min-w-[260px]">
              <FieldLabel label="Select Loan Account" />
              <select
                value={inspectLoanId}
                onChange={(e) => setInspectLoanId(e.target.value)}
                className={inputBaseClass}
              >
                {db.loans.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.id} — {l.customerName} ({formatINR(l.loanAmount)})
                  </option>
                ))}
              </select>
            </div>
            <button
              type="button"
              onClick={() =>
                exportToCSV(
                  `loan_schedule_${inspectLoanId}`,
                  ['EMI #', 'Due Date', 'Opening Bal', 'Principal', 'Interest', 'EMI Amount', 'Paid', 'Status'],
                  inspectData.schedules.map((s) => [
                    s.installmentNumber,
                    s.dueDate,
                    s.openingBalance,
                    s.principalComponent,
                    s.interestComponent,
                    s.emiAmount,
                    s.paidAmount,
                    s.status !== 'Paid' && s.dueDate < today ? 'Overdue' : s.status,
                  ])
                )
              }
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Schedule CSV</span>
            </button>
          </div>

          {inspectData.loan && (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-white border border-slate-200 rounded-2xl p-4">
                  <p className="text-xs text-slate-500">Principal Outstanding</p>
                  <p className="text-lg font-bold text-[#002E6E] font-mono-num mt-1">
                    {formatINR(inspectData.loan.principalOutstanding)}
                  </p>
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl p-4">
                  <p className="text-xs text-slate-500">Interest Outstanding</p>
                  <p className="text-lg font-bold text-amber-700 font-mono-num mt-1">
                    {formatINR(inspectData.loan.interestOutstanding)}
                  </p>
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl p-4">
                  <p className="text-xs text-slate-500">Total Paid So Far</p>
                  <p className="text-lg font-bold text-emerald-700 font-mono-num mt-1">
                    {formatINR(inspectData.totalPaid)}
                  </p>
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl p-4">
                  <p className="text-xs text-slate-500">Overdue Installments</p>
                  <p className="text-lg font-bold text-red-600 font-mono-num mt-1">
                    {inspectData.overdueItems.length}
                  </p>
                </div>
              </div>

              {/* Amortization Schedule */}
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                <div className="px-5 py-3.5 border-b border-slate-200">
                  <h4 className="text-sm font-bold text-[#002E6E]">
                    Complete EMI Installment Schedule ({inspectData.loan.interestType})
                  </h4>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                        <th className="py-2.5 px-4">EMI #</th>
                        <th className="py-2.5 px-4">Due Date</th>
                        <th className="py-2.5 px-4 text-right">Opening Bal</th>
                        <th className="py-2.5 px-4 text-right">Principal</th>
                        <th className="py-2.5 px-4 text-right">Interest</th>
                        <th className="py-2.5 px-4 text-right">EMI Amount</th>
                        <th className="py-2.5 px-4 text-right">Paid</th>
                        <th className="py-2.5 px-4">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {inspectData.schedules.map((s) => {
                        const isOverdue = s.status !== 'Paid' && s.dueDate < today;
                        return (
                          <tr key={s.id} className="hover:bg-slate-50/70">
                            <td className="py-2.5 px-4 font-mono-num font-semibold">
                              #{s.installmentNumber}
                            </td>
                            <td className="py-2.5 px-4 font-mono-num">{formatDateOnly(s.dueDate)}</td>
                            <td className="py-2.5 px-4 text-right font-mono-num">
                              {formatINR(s.openingBalance)}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono-num">
                              {formatINR(s.principalComponent)}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono-num">
                              {formatINR(s.interestComponent)}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono-num font-semibold">
                              {formatINR(s.emiAmount)}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono-num text-emerald-700">
                              {formatINR(s.paidAmount)}
                            </td>
                            <td className="py-2.5 px-4 font-semibold">
                              {s.status === 'Paid' ? (
                                <span className="text-emerald-700">Paid</span>
                              ) : isOverdue ? (
                                <span className="text-red-600">Overdue</span>
                              ) : s.status === 'Partial' ? (
                                <span className="text-amber-700">Partial</span>
                              ) : (
                                <span className="text-slate-500">Pending</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Customer Payment History */}
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                <div className="px-5 py-3.5 border-b border-slate-200">
                  <h4 className="text-sm font-bold text-[#002E6E]">Customer EMI Payment History</h4>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                        <th className="py-2.5 px-4">Receipt #</th>
                        <th className="py-2.5 px-4">Payment Date</th>
                        <th className="py-2.5 px-4">EMI #</th>
                        <th className="py-2.5 px-4">Mode</th>
                        <th className="py-2.5 px-4 text-right">Amount</th>
                        <th className="py-2.5 px-4 text-right">Receipt</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {inspectData.payments.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-6 text-center text-slate-500">
                            No EMI payments collected for this loan yet.
                          </td>
                        </tr>
                      ) : (
                        inspectData.payments.map((p) => (
                          <tr key={p.id} className="hover:bg-slate-50/70">
                            <td className="py-2.5 px-4 font-mono-num font-medium">{p.receiptNumber}</td>
                            <td className="py-2.5 px-4 font-mono-num">{formatDateOnly(p.paymentDate)}</td>
                            <td className="py-2.5 px-4 font-mono-num">
                              EMI #{p.installmentNumber} {p.isAdvance ? '· Advance' : ''}
                            </td>
                            <td className="py-2.5 px-4">{p.paymentMode}</td>
                            <td className="py-2.5 px-4 text-right font-mono-num font-semibold text-emerald-700">
                              {formatINR(p.totalReceived)}
                            </td>
                            <td className="py-2.5 px-4 text-right">
                              <button
                                type="button"
                                onClick={() => {
                                  const match = db.receipts.find(
                                    (r) => r.receiptNumber === p.receiptNumber
                                  );
                                  if (match) setActiveReceipt(match);
                                }}
                                className="inline-flex items-center gap-1 text-[#0070E0] font-medium hover:underline"
                              >
                                <ReceiptText className="w-3.5 h-3.5" />
                                <span>Reprint</span>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Independent Loan Account Ledger */}
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                <div className="px-5 py-3.5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-bold text-[#002E6E]">
                      {lang === 'mr'
                        ? `स्वतंत्र कर्ज खातेवही (Loan Ledger — ${inspectData.loan.id})`
                        : `Independent Loan Account Ledger (${inspectData.loan.id})`}
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-0.5 font-mono-num">
                      Disbursed: {formatINR(inspectData.totalDisbursed)} · Collected:{' '}
                      {formatINR(inspectData.totalCollection)} · Expenses:{' '}
                      {formatINR(inspectData.totalExpenses)} · Net Cashflow:{' '}
                      {formatINR(inspectData.netAccountBalance)}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      exportToCSV(
                        `loan_ledger_${inspectLoanId}`,
                        ['Ref #', 'Date', 'Description', 'Mode', 'Direction', 'Amount'],
                        inspectData.entries.map((e) => [
                          e.referenceNumber,
                          e.date,
                          e.description,
                          e.paymentMode,
                          e.direction,
                          e.amount,
                        ])
                      )
                    }
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export Loan Ledger</span>
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                        <th className="py-2.5 px-4">Ref #</th>
                        <th className="py-2.5 px-4">Date</th>
                        <th className="py-2.5 px-4">Description</th>
                        <th className="py-2.5 px-4">Mode</th>
                        <th className="py-2.5 px-4 text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {inspectData.entries.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-6 text-center text-slate-500">
                            No ledger entries recorded for this loan yet.
                          </td>
                        </tr>
                      ) : (
                        inspectData.entries.map((e) => (
                          <tr key={`${e.id}-${e.referenceNumber}`} className="hover:bg-slate-50/70">
                            <td className="py-2.5 px-4 font-mono-num font-medium">{e.referenceNumber}</td>
                            <td className="py-2.5 px-4 font-mono-num">{formatDateOnly(e.date)}</td>
                            <td className="py-2.5 px-4 text-slate-700">{e.description}</td>
                            <td className="py-2.5 px-4">{e.paymentMode}</td>
                            <td
                              className={`py-2.5 px-4 text-right font-mono-num font-semibold ${
                                e.direction === 'credit' ? 'text-emerald-700' : 'text-red-600'
                              }`}
                            >
                              {e.direction === 'credit' ? '+' : '-'} {formatINR(e.amount)}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* TAB 4: MODIFY / CLOSE LOAN */}
      {activeTab === 'modify' && (
        <form
          onSubmit={handleModifyLoan}
          className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 max-w-2xl"
        >
          <h3 className="text-base font-bold text-[#002E6E] font-display">
            Loan Modification &amp; Closure
          </h3>
          <p className="text-xs text-slate-500">
            Modifying interest rate or future installments only recalculates unpaid future EMIs. Historical paid records are never altered.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <FieldLabel label="Select Loan Account" required />
              <select
                value={modLoanId}
                onChange={(e) => setModLoanId(e.target.value)}
                className={inputBaseClass}
              >
                {db.loans.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.id} — {l.customerName} ({l.loanStatus})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <FieldLabel label="Loan Status" required />
              <select
                value={modStatus}
                onChange={(e) => setModStatus(e.target.value as LoanApprovalStatus)}
                className={inputBaseClass}
              >
                <option value="Pending">Pending</option>
                <option value="Approved">Approved</option>
                <option value="Active">Active</option>
                <option value="Closed">Closed</option>
              </select>
            </div>

            <div>
              <FieldLabel label="Future Interest Rate (% p.a.)" required />
              <input
                type="number"
                min={0}
                step="0.1"
                required
                value={modRate}
                onChange={(e) => setModRate(Number(e.target.value))}
                className={monoInputClass}
              />
            </div>

            <div>
              <FieldLabel label="Total Installments" required />
              <input
                type="number"
                min={1}
                required
                value={modTenure}
                onChange={(e) => setModTenure(Math.max(1, Number(e.target.value)))}
                className={monoInputClass}
              />
            </div>

            <div>
              <FieldLabel label="Remarks" />
              <input
                type="text"
                value={modRemarks}
                onChange={(e) => setModRemarks(e.target.value)}
                className={inputBaseClass}
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={!modLoan}
              className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl disabled:opacity-50"
            >
              Update Loan Settings
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
