import React, { useEffect, useMemo, useState } from 'react';
import { Download, ReceiptText, Edit3, Trash2 } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { BCStatus, BCType, PaymentMode, PaymentStatus, RecordStatus } from '../types/finance';
import { exportToCSV, formatDateOnly, formatDateTime, formatINR, generateNextId, todayISO } from '../utils/formatters';
import { FieldLabel, FormAlert, SectionHeader, inputBaseClass, monoInputClass } from './FormControls';

type BCTab = 'collection' | 'auction' | 'payout' | 'member' | 'new_bc' | 'ledger';

export const BCManagementView: React.FC = () => {
  const {
    db,
    lang,
    getNextReceiptNumber,
    getNextVoucherNumber,
    getBCLedger,
    addBCGroup,
    updateBCGroup,
    softDeleteBCGroup,
    addMember,
    enrollExistingMember,
    addBCCollection,
    addBCAuction,
    addBCPayout,
    setActiveReceipt,
  } = useFinance();

  const activeBCs = useMemo(() => db.bcGroups.filter((g) => !g.isDeleted), [db.bcGroups]);

  const [activeTab, setActiveTab] = useState<BCTab>('collection');
  const [feedback, setFeedback] = useState<{ type: 'error' | 'success'; message: string } | null>(null);

  // --- Form 1A: Add / Modify / Soft-Delete BC ---
  const [editingBcId, setEditingBcId] = useState<string | null>(null);
  const [bcName, setBcName] = useState('');
  const [bcType, setBcType] = useState<BCType>('20 Members BC');
  const [totalMembers, setTotalMembers] = useState(20);
  const [monthlyInst, setMonthlyInst] = useState(5000);
  const [totalBCAmount, setTotalBCAmount] = useState(100000);
  const [bcStartDate, setBcStartDate] = useState(todayISO());
  const [monthlyDueDate, setMonthlyDueDate] = useState(5);
  const [auctionDate, setAuctionDate] = useState(5);
  const [dividendRules, setDividendRules] = useState('Bid divided equally among active members.');
  const [bcStatus, setBcStatus] = useState<BCStatus>('Active');
  const [bcDesc, setBcDesc] = useState('');
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);
  const [deleteReason, setDeleteReason] = useState('');

  const nextAutoBCId = useMemo(
    () => generateNextId('BC', db.bcGroups.map((g) => g.id), 3),
    [db.bcGroups]
  );

  const handleBcTypeChange = (nextType: BCType) => {
    setBcType(nextType);
    const preset =
      nextType === '15 Members BC'
        ? 15
        : nextType === '20 Members BC'
          ? 20
          : nextType === '50 Members BC'
            ? 50
            : totalMembers;
    setTotalMembers(preset);
    setTotalBCAmount(preset * monthlyInst);
  };

  const resetBCForm = () => {
    setEditingBcId(null);
    setBcName('');
    setBcType('20 Members BC');
    setTotalMembers(20);
    setMonthlyInst(5000);
    setTotalBCAmount(100000);
    setBcStartDate(todayISO());
    setMonthlyDueDate(5);
    setAuctionDate(5);
    setDividendRules('Bid divided equally among active members.');
    setBcStatus('Active');
    setBcDesc('');
  };

  const handleSaveOrUpdateBC = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (editingBcId) {
      const res = updateBCGroup(editingBcId, {
        name: bcName,
        bcType,
        totalMembers,
        monthlyInstallment: monthlyInst,
        totalAmount: totalBCAmount,
        startDate: bcStartDate,
        monthlyDueDate,
        auctionDate,
        dividendRules,
        status: bcStatus,
        description: bcDesc,
      });
      if (res.ok) {
        setFeedback({ type: 'success', message: `BC ${editingBcId} updated successfully.` });
        resetBCForm();
      } else {
        setFeedback({ type: 'error', message: res.error ?? 'Update failed.' });
      }
      return;
    }

    const res = addBCGroup({
      name: bcName,
      bcType,
      totalMembers,
      monthlyInstallment: monthlyInst,
      totalAmount: totalBCAmount,
      startDate: bcStartDate,
      monthlyDueDate,
      auctionDate,
      dividendRules,
      status: bcStatus,
      description: bcDesc,
    });
    if (res.ok) {
      setFeedback({ type: 'success', message: `New BC "${bcName}" (${res.id}) created.` });
      resetBCForm();
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Could not create BC.' });
    }
  };

  const handleConfirmSoftDeleteBC = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deleteTargetId) return;
    const res = softDeleteBCGroup(deleteTargetId, deleteReason);
    if (res.ok) {
      setFeedback({ type: 'success', message: `BC ${deleteTargetId} soft-deleted with audit log.` });
      setDeleteTargetId(null);
      setDeleteReason('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Soft delete failed.' });
    }
  };

  // --- Form 1B: BC Member Registration ---
  const [regMode, setRegMode] = useState<'new' | 'existing'>('new');
  const [existingMemberId, setExistingMemberId] = useState(db.members[0]?.id ?? '');
  const [memName, setMemName] = useState('');
  const [memMobile, setMemMobile] = useState('');
  const [memAddress, setMemAddress] = useState('');
  const [memAadhaar, setMemAadhaar] = useState('');
  const [memBcGroupId, setMemBcGroupId] = useState(activeBCs[0]?.id ?? '');
  const [memJoinDate, setMemJoinDate] = useState(todayISO());
  const [memInstAmount, setMemInstAmount] = useState(activeBCs[0]?.monthlyInstallment ?? 5000);
  const [memTotalInst, setMemTotalInst] = useState(activeBCs[0]?.totalMembers ?? 20);
  const [memNominee, setMemNominee] = useState('');
  const [memStatus, setMemStatus] = useState<RecordStatus>('Active');

  useEffect(() => {
    const grp = activeBCs.find((g) => g.id === memBcGroupId);
    if (grp) {
      setMemInstAmount(grp.monthlyInstallment);
      setMemTotalInst(grp.totalMembers);
    }
  }, [memBcGroupId, activeBCs]);

  const nextAutoMemberId = useMemo(
    () => generateNextId('MEM', db.members.map((m) => m.id), 4),
    [db.members]
  );

  const handleRegisterBCMember = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!memBcGroupId) {
      setFeedback({ type: 'error', message: 'Please select a BC Group first.' });
      return;
    }
    if (regMode === 'existing') {
      const res = enrollExistingMember({
        groupKind: 'bc',
        groupId: memBcGroupId,
        memberId: existingMemberId,
        joiningDate: memJoinDate,
        monthlyInstallment: memInstAmount,
        totalInstallments: memTotalInst,
        status: memStatus,
      });
      setFeedback(
        res.ok
          ? { type: 'success', message: 'Existing member enrolled into BC group.' }
          : { type: 'error', message: res.error ?? 'Failed to enroll.' }
      );
      return;
    }

    const res = addMember(
      {
        name: memName,
        mobile: memMobile,
        address: memAddress,
        joiningDate: memJoinDate,
        category: 'BC Member',
        aadhaar: memAadhaar || undefined,
        nomineeName: memNominee || undefined,
        initialBalance: 0,
        status: memStatus,
      },
      {
        groupKind: 'bc',
        groupId: memBcGroupId,
        joiningDate: memJoinDate,
        monthlyInstallment: memInstAmount,
        totalInstallments: memTotalInst,
      }
    );
    if (res.ok) {
      setFeedback({ type: 'success', message: `Member ${memName} (${res.id}) added to BC.` });
      setMemName('');
      setMemMobile('');
      setMemAddress('');
      setMemAadhaar('');
      setMemNominee('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Could not register member.' });
    }
  };

  // --- Form 1C: BC Collection + Pending Installment Tracker ---
  const [colBcId, setColBcId] = useState(activeBCs[0]?.id ?? '');
  const [colMemberId, setColMemberId] = useState('');
  const [colInstNo, setColInstNo] = useState(1);
  const [colDate, setColDate] = useState(todayISO());
  const [colInstAmt, setColInstAmt] = useState(5000);
  const [colDividend, setColDividend] = useState(0);
  const [colLateFee, setColLateFee] = useState(0);
  const [colMode, setColMode] = useState<PaymentMode>('Cash');
  const [colTxnRef, setColTxnRef] = useState('');
  const [colRemarks, setColRemarks] = useState('');

  const colEnrolledMembers = useMemo(() => {
    const ids = new Set(
      db.enrollments.filter((e) => e.groupKind === 'bc' && e.groupId === colBcId).map((e) => e.memberId)
    );
    return db.members.filter((m) => !m.isDeleted && ids.has(m.id));
  }, [db.enrollments, db.members, colBcId]);

  const pendingForInstallment = useMemo(() => {
    const paidSet = new Set(
      db.bcCollections
        .filter((c) => c.bcGroupId === colBcId && c.installmentNumber === colInstNo)
        .map((c) => c.memberId)
    );
    return colEnrolledMembers.filter((m) => !paidSet.has(m.id));
  }, [db.bcCollections, colBcId, colInstNo, colEnrolledMembers]);

  useEffect(() => {
    const grp = activeBCs.find((g) => g.id === colBcId);
    if (grp) setColInstAmt(grp.monthlyInstallment);
    if (colEnrolledMembers.length > 0 && !colEnrolledMembers.some((m) => m.id === colMemberId)) {
      setColMemberId(colEnrolledMembers[0].id);
    }
  }, [colBcId, activeBCs, colEnrolledMembers, colMemberId]);

  const colTotalReceived = Math.max(0, colInstAmt - colDividend + colLateFee);

  const handleSaveCollection = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!colBcId || !colMemberId) {
      setFeedback({ type: 'error', message: 'Please select BC Group and Member.' });
      return;
    }
    const res = addBCCollection({
      bcGroupId: colBcId,
      memberId: colMemberId,
      installmentNumber: colInstNo,
      collectionDate: colDate,
      installmentAmount: colInstAmt,
      dividendDeduction: colDividend,
      lateFee: colLateFee,
      totalReceived: colTotalReceived,
      paymentMode: colMode,
      transactionRef: colTxnRef,
      remarks: colRemarks,
    });
    if (res.ok) {
      setFeedback({
        type: 'success',
        message: `Collection saved (${res.receipt?.receiptNumber}). Receipt ready.`,
      });
      setColTxnRef('');
      setColRemarks('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Failed to save collection.' });
    }
  };

  // --- Form 1D: BC Auction / Lilaav ---
  const [aucBcId, setAucBcId] = useState(activeBCs[0]?.id ?? '');
  const [aucDate, setAucDate] = useState(todayISO());
  const [aucInstNo, setAucInstNo] = useState(1);
  const [aucTotalBC, setAucTotalBC] = useState(100000);
  const [aucWinnerId, setAucWinnerId] = useState('');
  const [aucBidAmt, setAucBidAmt] = useState(8000);
  const [aucOtherDed, setAucOtherDed] = useState(0);
  const [aucRemarks, setAucRemarks] = useState('');

  const aucGroup = activeBCs.find((g) => g.id === aucBcId);
  const aucMembers = useMemo(() => {
    const ids = new Set(
      db.enrollments.filter((e) => e.groupKind === 'bc' && e.groupId === aucBcId).map((e) => e.memberId)
    );
    return db.members.filter((m) => !m.isDeleted && ids.has(m.id));
  }, [db.enrollments, db.members, aucBcId]);

  useEffect(() => {
    if (aucGroup) setAucTotalBC(aucGroup.totalAmount);
    if (aucMembers.length > 0 && !aucMembers.some((m) => m.id === aucWinnerId)) {
      setAucWinnerId(aucMembers[0].id);
    }
  }, [aucGroup, aucMembers, aucWinnerId]);

  const aucDividendPerMember =
    aucGroup && aucGroup.totalMembers > 0 ? Math.round(aucBidAmt / aucGroup.totalMembers) : 0;
  const aucWinnerPayable = Math.max(0, aucTotalBC - aucBidAmt);
  const aucFinalPayout = Math.max(0, aucWinnerPayable - aucOtherDed);

  const handleSaveAuction = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!aucBcId || !aucWinnerId) {
      setFeedback({ type: 'error', message: 'Please select BC Group and Winner.' });
      return;
    }
    const res = addBCAuction({
      bcGroupId: aucBcId,
      auctionDate: aucDate,
      installmentNumber: aucInstNo,
      totalBCAmount: aucTotalBC,
      winnerMemberId: aucWinnerId,
      auctionBidAmount: aucBidAmt,
      dividendAmount: aucDividendPerMember,
      winnerPayableAmount: aucWinnerPayable,
      otherDeduction: aucOtherDed,
      finalPayout: aucFinalPayout,
      remarks: aucRemarks,
    });
    if (res.ok) {
      setFeedback({
        type: 'success',
        message: `Auction #${aucInstNo} recorded (${res.id}). Dividend/member: ${formatINR(aucDividendPerMember)}.`,
      });
      setAucRemarks('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Failed to save auction.' });
    }
  };

  // --- Form 1E: BC Payout ---
  const [payBcId, setPayBcId] = useState(activeBCs[0]?.id ?? '');
  const [payWinnerId, setPayWinnerId] = useState('');
  const [payDate, setPayDate] = useState(todayISO());
  const [payTotalAmt, setPayTotalAmt] = useState(92000);
  const [payDeduction, setPayDeduction] = useState(0);
  const [payMode, setPayMode] = useState<PaymentMode>('Bank');
  const [payTxnId, setPayTxnId] = useState('');
  const [payStatus, setPayStatus] = useState<PaymentStatus>('Paid');
  const [payRemarks, setPayRemarks] = useState('');

  const payMembers = useMemo(() => {
    const ids = new Set(
      db.enrollments.filter((e) => e.groupKind === 'bc' && e.groupId === payBcId).map((e) => e.memberId)
    );
    const list = db.members.filter((m) => !m.isDeleted && ids.has(m.id));
    return list.length > 0 ? list : db.members.filter((m) => !m.isDeleted);
  }, [db.enrollments, db.members, payBcId]);

  useEffect(() => {
    if (payMembers.length > 0 && !payMembers.some((m) => m.id === payWinnerId)) {
      setPayWinnerId(payMembers[0].id);
    }
  }, [payMembers, payWinnerId]);

  const payNetPaid = Math.max(0, payTotalAmt - payDeduction);

  const handleSavePayout = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!payBcId || !payWinnerId) {
      setFeedback({ type: 'error', message: 'Please select BC Group and Winner.' });
      return;
    }
    const res = addBCPayout({
      bcGroupId: payBcId,
      winnerMemberId: payWinnerId,
      payoutDate: payDate,
      totalAmount: payTotalAmt,
      deduction: payDeduction,
      netPaidAmount: payNetPaid,
      paymentMode: payMode,
      transactionId: payTxnId,
      paymentStatus: payStatus,
      remarks: payRemarks,
    });
    if (res.ok) {
      setFeedback({ type: 'success', message: `BC Payout recorded (${res.receipt?.receiptNumber}).` });
      setPayTxnId('');
      setPayRemarks('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Failed to save payout.' });
    }
  };

  // --- Tab 6: Independent BC Ledger ---
  const [ledgerBcId, setLedgerBcId] = useState(activeBCs[0]?.id ?? '');
  const selectedLedgerData = getBCLedger(ledgerBcId);

  const tabs: { id: BCTab; label: string }[] = [
    { id: 'collection', label: lang === 'mr' ? 'हप्ता वसुली व बाकी' : 'Collection & Pending' },
    { id: 'auction', label: lang === 'mr' ? 'लिलाव (Auction)' : 'Auction / Lilaav' },
    { id: 'payout', label: lang === 'mr' ? 'विजेता वाटप (Payout)' : 'Winner Payout' },
    { id: 'member', label: lang === 'mr' ? 'सभासद नोंदणी' : 'BC Members' },
    { id: 'new_bc', label: lang === 'mr' ? 'नवीन / बदल / डिलीट BC' : 'Add / Edit BC' },
    { id: 'ledger', label: lang === 'mr' ? 'स्वतंत्र BC खातेवही' : 'BC Ledger' },
  ];

  return (
    <div className="space-y-6">
      <SectionHeader
        title={lang === 'mr' ? 'BC व्यवस्थापन (BC Management)' : 'BC Management System'}
        subtitle={
          lang === 'mr'
            ? 'BC ग्रुप तयार/बदल/डिलीट करा, सभासद नोंदणी, हप्ता वसुली, प्रलंबित हप्ते, लिलाव, वाटप आणि स्वतंत्र खातेवही'
            : 'Add, modify & soft-delete BC groups, track pending installments, run auctions, issue payouts & inspect independent BC ledgers'
        }
      />

      <div className="flex flex-wrap gap-1.5 p-1.5 bg-slate-100 rounded-xl no-print">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => {
              setActiveTab(tab.id);
              setFeedback(null);
            }}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-white text-[#002E6E] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {feedback && (
        <FormAlert
          type={feedback.type}
          message={feedback.message}
          onDismiss={() => setFeedback(null)}
        />
      )}

      {/* TAB: ADD / MODIFY / SOFT-DELETE BC */}
      {activeTab === 'new_bc' && (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <form
            onSubmit={handleSaveOrUpdateBC}
            className="lg:col-span-3 bg-white border border-slate-200 rounded-2xl p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-[#002E6E] font-display">
                {editingBcId ? `Modify BC (${editingBcId})` : 'BC Group Creation Form'}
              </h3>
              {editingBcId && (
                <button
                  type="button"
                  onClick={resetBCForm}
                  className="text-xs font-medium text-slate-500 hover:text-slate-900 underline"
                >
                  Cancel Edit
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <FieldLabel label="BC ID (Auto Generated)" />
                <input
                  type="text"
                  readOnly
                  value={editingBcId ?? nextAutoBCId}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Status" required />
                <select
                  value={bcStatus}
                  onChange={(e) => setBcStatus(e.target.value as BCStatus)}
                  className={inputBaseClass}
                >
                  <option value="Active">Active</option>
                  <option value="Completed">Completed</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <FieldLabel label="BC Group Name" required />
                <input
                  type="text"
                  required
                  value={bcName}
                  onChange={(e) => setBcName(e.target.value)}
                  placeholder="e.g. Ganesh 20-Member BC"
                  className={inputBaseClass}
                />
              </div>

              <div>
                <FieldLabel label="BC Type" required />
                <select
                  value={bcType}
                  onChange={(e) => handleBcTypeChange(e.target.value as BCType)}
                  className={inputBaseClass}
                >
                  <option value="15 Members BC">15 Members BC</option>
                  <option value="20 Members BC">20 Members BC</option>
                  <option value="50 Members BC">50 Members BC</option>
                  <option value="Custom">Custom</option>
                </select>
              </div>

              <div>
                <FieldLabel label="Total Members" required />
                <input
                  type="number"
                  min={2}
                  required
                  value={totalMembers}
                  onChange={(e) => {
                    const m = Math.max(2, Number(e.target.value));
                    setTotalMembers(m);
                    setTotalBCAmount(m * monthlyInst);
                  }}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Monthly Installment (₹)" required />
                <input
                  type="number"
                  min={100}
                  required
                  value={monthlyInst}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value));
                    setMonthlyInst(val);
                    setTotalBCAmount(totalMembers * val);
                  }}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Total BC Amount (₹)" required />
                <input
                  type="number"
                  min={100}
                  required
                  value={totalBCAmount}
                  onChange={(e) => setTotalBCAmount(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Start Date" required />
                <input
                  type="date"
                  required
                  value={bcStartDate}
                  onChange={(e) => setBcStartDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <FieldLabel label="Due Day (1–28)" required />
                  <input
                    type="number"
                    min={1}
                    max={28}
                    required
                    value={monthlyDueDate}
                    onChange={(e) =>
                      setMonthlyDueDate(Math.min(28, Math.max(1, Number(e.target.value))))
                    }
                    className={monoInputClass}
                  />
                </div>
                <div>
                  <FieldLabel label="Auction Day" required />
                  <input
                    type="number"
                    min={1}
                    max={28}
                    required
                    value={auctionDate}
                    onChange={(e) =>
                      setAuctionDate(Math.min(28, Math.max(1, Number(e.target.value))))
                    }
                    className={monoInputClass}
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <FieldLabel label="Dividend Rules" />
                <input
                  type="text"
                  value={dividendRules}
                  onChange={(e) => setDividendRules(e.target.value)}
                  className={inputBaseClass}
                />
              </div>

              <div className="sm:col-span-2">
                <FieldLabel label="Description" />
                <textarea
                  rows={2}
                  value={bcDesc}
                  onChange={(e) => setBcDesc(e.target.value)}
                  className={`${inputBaseClass} min-h-[68px]`}
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl transition-colors"
              >
                {editingBcId ? 'Update BC Group' : 'Save BC Group'}
              </button>
            </div>
          </form>

          {/* BC Directory with Edit / Soft Delete */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
              <h3 className="text-sm font-bold text-[#002E6E] font-display">
                Active BC Groups ({activeBCs.length})
              </h3>
              <div className="divide-y divide-slate-100">
                {activeBCs.map((g) => (
                  <div key={g.id} className="py-3 first:pt-0 last:pb-0 space-y-1.5">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-sm font-semibold text-slate-900">{g.name}</span>
                        <div className="text-xs text-slate-500">
                          {g.id} · {g.bcType} · {g.status}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingBcId(g.id);
                            setBcName(g.name);
                            setBcType(g.bcType);
                            setTotalMembers(g.totalMembers);
                            setMonthlyInst(g.monthlyInstallment);
                            setTotalBCAmount(g.totalAmount);
                            setBcStartDate(g.startDate);
                            setMonthlyDueDate(g.monthlyDueDate);
                            setAuctionDate(g.auctionDate);
                            setDividendRules(g.dividendRules);
                            setBcStatus(g.status);
                            setBcDesc(g.description);
                          }}
                          className="p-2 text-slate-500 hover:text-[#0070E0] rounded-lg hover:bg-blue-50"
                          aria-label={`Modify ${g.name}`}
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteTargetId(g.id)}
                          className="p-2 text-slate-500 hover:text-red-600 rounded-lg hover:bg-red-50"
                          aria-label={`Delete ${g.name}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                    <div className="text-xs text-slate-600 font-mono-num">
                      {formatINR(g.monthlyInstallment)}/mo · Pool {formatINR(g.totalAmount)} · Due {g.monthlyDueDate}th
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {deleteTargetId && (
              <form
                onSubmit={handleConfirmSoftDeleteBC}
                className="bg-red-50 border border-red-200 rounded-2xl p-4 space-y-3"
              >
                <p className="text-xs font-bold text-red-800">
                  Confirm Soft Delete ({deleteTargetId})
                </p>
                <p className="text-[11px] text-red-700">
                  Historical receipts &amp; cash book entries stay preserved in audit history.
                </p>
                <input
                  type="text"
                  required
                  value={deleteReason}
                  onChange={(e) => setDeleteReason(e.target.value)}
                  placeholder="Enter reason for deleting BC..."
                  className={inputBaseClass}
                />
                <div className="flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setDeleteTargetId(null);
                      setDeleteReason('');
                    }}
                    className="px-3 py-1.5 text-xs font-medium text-slate-700"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-3.5 py-1.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg"
                  >
                    Confirm Delete
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* TAB: BC MEMBER REGISTRATION */}
      {activeTab === 'member' && (
        <form
          onSubmit={handleRegisterBCMember}
          className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5 max-w-3xl"
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <h3 className="text-base font-bold text-[#002E6E] font-display">
              BC Member Registration
            </h3>
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl self-start">
              <button
                type="button"
                onClick={() => setRegMode('new')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg ${
                  regMode === 'new' ? 'bg-white text-[#002E6E] shadow-xs' : 'text-slate-600'
                }`}
              >
                New Member
              </button>
              <button
                type="button"
                onClick={() => setRegMode('existing')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg ${
                  regMode === 'existing' ? 'bg-white text-[#002E6E] shadow-xs' : 'text-slate-600'
                }`}
              >
                Enroll Existing
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {regMode === 'new' ? (
              <>
                <div>
                  <FieldLabel label="Member ID (Auto)" />
                  <input type="text" readOnly value={nextAutoMemberId} className={monoInputClass} />
                </div>
                <div>
                  <FieldLabel label="Full Name" required />
                  <input
                    type="text"
                    required
                    value={memName}
                    onChange={(e) => setMemName(e.target.value)}
                    className={inputBaseClass}
                  />
                </div>
                <div>
                  <FieldLabel label="Mobile Number" required />
                  <input
                    type="tel"
                    required
                    value={memMobile}
                    onChange={(e) => setMemMobile(e.target.value)}
                    className={monoInputClass}
                  />
                </div>
                <div>
                  <FieldLabel label="Aadhaar (Optional)" />
                  <input
                    type="text"
                    value={memAadhaar}
                    onChange={(e) => setMemAadhaar(e.target.value)}
                    className={monoInputClass}
                  />
                </div>
                <div className="sm:col-span-2">
                  <FieldLabel label="Address" required />
                  <input
                    type="text"
                    required
                    value={memAddress}
                    onChange={(e) => setMemAddress(e.target.value)}
                    className={inputBaseClass}
                  />
                </div>
                <div>
                  <FieldLabel label="Nominee Name" />
                  <input
                    type="text"
                    value={memNominee}
                    onChange={(e) => setMemNominee(e.target.value)}
                    className={inputBaseClass}
                  />
                </div>
              </>
            ) : (
              <div className="sm:col-span-2">
                <FieldLabel label="Select Existing Member" required />
                <select
                  value={existingMemberId}
                  onChange={(e) => setExistingMemberId(e.target.value)}
                  className={inputBaseClass}
                >
                  {db.members
                    .filter((m) => !m.isDeleted)
                    .map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.id} · {m.mobile})
                      </option>
                    ))}
                </select>
              </div>
            )}

            <div>
              <FieldLabel label="BC Group" required />
              <select
                value={memBcGroupId}
                onChange={(e) => setMemBcGroupId(e.target.value)}
                className={inputBaseClass}
              >
                {activeBCs.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name} ({g.id})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <FieldLabel label="Joining Date" required />
              <input
                type="date"
                required
                value={memJoinDate}
                onChange={(e) => setMemJoinDate(e.target.value)}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Monthly Installment (₹)" required />
              <input
                type="number"
                required
                value={memInstAmount}
                onChange={(e) => setMemInstAmount(Number(e.target.value))}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Total Installments" required />
              <input
                type="number"
                required
                value={memTotalInst}
                onChange={(e) => setMemTotalInst(Number(e.target.value))}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="Status" required />
              <select
                value={memStatus}
                onChange={(e) => setMemStatus(e.target.value as RecordStatus)}
                className={inputBaseClass}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
            >
              Save BC Member
            </button>
          </div>
        </form>
      )}

      {/* TAB: BC COLLECTION & PENDING INSTALLMENT TRACKER */}
      {activeTab === 'collection' && (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <form
            onSubmit={handleSaveCollection}
            className="lg:col-span-3 bg-white border border-slate-200 rounded-2xl p-6 space-y-5"
          >
            <h3 className="text-base font-bold text-[#002E6E] font-display">
              BC Monthly Collection Form
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <FieldLabel label="Receipt Number (Auto)" />
                <input type="text" readOnly value={getNextReceiptNumber()} className={monoInputClass} />
              </div>

              <div>
                <FieldLabel label="Collection Date" required />
                <input
                  type="date"
                  required
                  value={colDate}
                  onChange={(e) => setColDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="BC Group Name" required />
                <select
                  value={colBcId}
                  onChange={(e) => setColBcId(e.target.value)}
                  className={inputBaseClass}
                >
                  {activeBCs.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <FieldLabel label="Member Name" required />
                <select
                  value={colMemberId}
                  onChange={(e) => setColMemberId(e.target.value)}
                  className={inputBaseClass}
                >
                  {colEnrolledMembers.length === 0 && <option value="">No enrolled members</option>}
                  {colEnrolledMembers.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.id})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <FieldLabel label="Installment Number" required />
                <input
                  type="number"
                  min={1}
                  required
                  value={colInstNo}
                  onChange={(e) => setColInstNo(Math.max(1, Number(e.target.value)))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Installment Amount (₹)" required />
                <input
                  type="number"
                  min={0}
                  required
                  value={colInstAmt}
                  onChange={(e) => setColInstAmt(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Dividend Deduction (₹)" />
                <input
                  type="number"
                  min={0}
                  value={colDividend}
                  onChange={(e) => setColDividend(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Late Fee (₹)" />
                <input
                  type="number"
                  min={0}
                  value={colLateFee}
                  onChange={(e) => setColLateFee(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>

              <div>
                <FieldLabel label="Payment Mode" required />
                <select
                  value={colMode}
                  onChange={(e) => setColMode(e.target.value as PaymentMode)}
                  className={inputBaseClass}
                >
                  <option value="Cash">Cash</option>
                  <option value="UPI">UPI</option>
                  <option value="Bank">Bank</option>
                </select>
              </div>

              <div>
                <FieldLabel label="Transaction Reference" />
                <input
                  type="text"
                  value={colTxnRef}
                  onChange={(e) => setColTxnRef(e.target.value)}
                  placeholder="UPI / NEFT Ref #"
                  className={monoInputClass}
                />
              </div>

              <div className="sm:col-span-2">
                <FieldLabel label="Remarks" />
                <input
                  type="text"
                  value={colRemarks}
                  onChange={(e) => setColRemarks(e.target.value)}
                  className={inputBaseClass}
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pt-4 border-t border-slate-200">
              <div>
                <span className="text-xs text-slate-500">Total Received</span>
                <p className="text-xl font-bold text-emerald-700 font-mono-num">
                  {formatINR(colTotalReceived)}
                </p>
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
              >
                Save &amp; Issue Receipt
              </button>
            </div>
          </form>

          {/* Pending Collection Tracker for selected BC & Installment */}
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 space-y-3 self-start">
            <h3 className="text-sm font-bold text-[#002E6E] font-display">
              Pending Members — Installment #{colInstNo}
            </h3>
            <p className="text-xs text-slate-500">
              {pendingForInstallment.length} of {colEnrolledMembers.length} enrolled members pending
            </p>
            <div className="divide-y divide-slate-100 max-h-[360px] overflow-y-auto">
              {pendingForInstallment.length === 0 ? (
                <p className="py-4 text-xs text-emerald-700 font-medium">
                  All enrolled members have paid Installment #{colInstNo}.
                </p>
              ) : (
                pendingForInstallment.map((m) => (
                  <div key={m.id} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                    <div>
                      <div className="font-semibold text-slate-900">{m.name}</div>
                      <div className="text-slate-500 font-mono-num">
                        {m.id} · {m.mobile}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setColMemberId(m.id)}
                      className="px-3 py-1.5 text-xs font-semibold text-[#0070E0] bg-blue-50 hover:bg-blue-100 rounded-lg"
                    >
                      Collect
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB: BC AUCTION */}
      {activeTab === 'auction' && (
        <div className="space-y-6">
          <form
            onSubmit={handleSaveAuction}
            className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5 max-w-3xl"
          >
            <h3 className="text-base font-bold text-[#002E6E] font-display">
              BC Auction / Lilaav Form
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <FieldLabel label="BC Group" required />
                <select
                  value={aucBcId}
                  onChange={(e) => setAucBcId(e.target.value)}
                  className={inputBaseClass}
                >
                  {activeBCs.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <FieldLabel label="Auction Date" required />
                <input
                  type="date"
                  required
                  value={aucDate}
                  onChange={(e) => setAucDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Installment Number" required />
                <input
                  type="number"
                  min={1}
                  required
                  value={aucInstNo}
                  onChange={(e) => setAucInstNo(Math.max(1, Number(e.target.value)))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Total BC Amount (₹)" required />
                <input
                  type="number"
                  required
                  value={aucTotalBC}
                  onChange={(e) => setAucTotalBC(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Auction Winner" required />
                <select
                  value={aucWinnerId}
                  onChange={(e) => setAucWinnerId(e.target.value)}
                  className={inputBaseClass}
                >
                  {aucMembers.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.id})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <FieldLabel label="Auction Bid Amount (₹)" required />
                <input
                  type="number"
                  min={0}
                  required
                  value={aucBidAmt}
                  onChange={(e) => setAucBidAmt(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Dividend / Member (Auto)" />
                <input
                  type="text"
                  readOnly
                  value={formatINR(aucDividendPerMember)}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Winner Payable (Auto)" />
                <input
                  type="text"
                  readOnly
                  value={formatINR(aucWinnerPayable)}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Other Deduction (₹)" />
                <input
                  type="number"
                  min={0}
                  value={aucOtherDed}
                  onChange={(e) => setAucOtherDed(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Remarks" />
                <input
                  type="text"
                  value={aucRemarks}
                  onChange={(e) => setAucRemarks(e.target.value)}
                  className={inputBaseClass}
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pt-4 border-t border-slate-200">
              <div>
                <span className="text-xs text-slate-500">Final Payout</span>
                <p className="text-xl font-bold text-[#002E6E] font-mono-num">
                  {formatINR(aucFinalPayout)}
                </p>
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
              >
                Save Auction
              </button>
            </div>
          </form>

          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200">
              <h4 className="text-sm font-bold text-[#002E6E]">BC Auction History</h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                    <th className="py-2.5 px-4">Date</th>
                    <th className="py-2.5 px-4">BC Group</th>
                    <th className="py-2.5 px-4">Inst #</th>
                    <th className="py-2.5 px-4">Winner</th>
                    <th className="py-2.5 px-4 text-right">Bid</th>
                    <th className="py-2.5 px-4 text-right">Dividend</th>
                    <th className="py-2.5 px-4 text-right">Final Payout</th>
                    <th className="py-2.5 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {db.bcAuctions.map((a) => {
                    const grp = db.bcGroups.find((g) => g.id === a.bcGroupId);
                    const win = db.members.find((m) => m.id === a.winnerMemberId);
                    return (
                      <tr key={a.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono-num">{formatDateOnly(a.auctionDate)}</td>
                        <td className="py-3 px-4 font-medium">{grp?.name ?? a.bcGroupId}</td>
                        <td className="py-3 px-4 font-mono-num">#{a.installmentNumber}</td>
                        <td className="py-3 px-4 font-medium">{win?.name ?? a.winnerMemberId}</td>
                        <td className="py-3 px-4 text-right font-mono-num">
                          {formatINR(a.auctionBidAmount)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono-num text-emerald-700">
                          {formatINR(a.dividendAmount)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono-num font-semibold">
                          {formatINR(a.finalPayout)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => {
                              setPayBcId(a.bcGroupId);
                              setPayWinnerId(a.winnerMemberId);
                              setPayTotalAmt(a.winnerPayableAmount);
                              setPayDeduction(a.otherDeduction);
                              setActiveTab('payout');
                            }}
                            className="text-[#0070E0] font-semibold hover:underline"
                          >
                            Pay Winner
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB: BC PAYOUT */}
      {activeTab === 'payout' && (
        <div className="space-y-6">
          <form
            onSubmit={handleSavePayout}
            className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5 max-w-3xl"
          >
            <h3 className="text-base font-bold text-[#002E6E] font-display">BC Winner Payout Form</h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <FieldLabel label="Auto Voucher #" />
                <input type="text" readOnly value={getNextVoucherNumber()} className={monoInputClass} />
              </div>
              <div>
                <FieldLabel label="Payout Date" required />
                <input
                  type="date"
                  required
                  value={payDate}
                  onChange={(e) => setPayDate(e.target.value)}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="BC Group" required />
                <select
                  value={payBcId}
                  onChange={(e) => setPayBcId(e.target.value)}
                  className={inputBaseClass}
                >
                  {activeBCs.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <FieldLabel label="Winner Name" required />
                <select
                  value={payWinnerId}
                  onChange={(e) => setPayWinnerId(e.target.value)}
                  className={inputBaseClass}
                >
                  {payMembers.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.id})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <FieldLabel label="Total Amount (₹)" required />
                <input
                  type="number"
                  min={0}
                  required
                  value={payTotalAmt}
                  onChange={(e) => setPayTotalAmt(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Deduction (₹)" />
                <input
                  type="number"
                  min={0}
                  value={payDeduction}
                  onChange={(e) => setPayDeduction(Number(e.target.value))}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Payment Mode" required />
                <select
                  value={payMode}
                  onChange={(e) => setPayMode(e.target.value as PaymentMode)}
                  className={inputBaseClass}
                >
                  <option value="Bank">Bank</option>
                  <option value="UPI">UPI</option>
                  <option value="Cash">Cash</option>
                </select>
              </div>
              <div>
                <FieldLabel label="Transaction ID / UTR" />
                <input
                  type="text"
                  value={payTxnId}
                  onChange={(e) => setPayTxnId(e.target.value)}
                  className={monoInputClass}
                />
              </div>
              <div>
                <FieldLabel label="Payment Status" required />
                <select
                  value={payStatus}
                  onChange={(e) => setPayStatus(e.target.value as PaymentStatus)}
                  className={inputBaseClass}
                >
                  <option value="Paid">Paid</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>
              <div>
                <FieldLabel label="Remarks" />
                <input
                  type="text"
                  value={payRemarks}
                  onChange={(e) => setPayRemarks(e.target.value)}
                  className={inputBaseClass}
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pt-4 border-t border-slate-200">
              <div>
                <span className="text-xs text-slate-500">Net Paid Amount</span>
                <p className="text-xl font-bold text-[#002E6E] font-mono-num">
                  {formatINR(payNetPaid)}
                </p>
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
              >
                Save Payout &amp; Issue Voucher
              </button>
            </div>
          </form>

          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200">
              <h4 className="text-sm font-bold text-[#002E6E]">BC Payout History</h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                    <th className="py-2.5 px-4">Voucher #</th>
                    <th className="py-2.5 px-4">Date</th>
                    <th className="py-2.5 px-4">BC Group</th>
                    <th className="py-2.5 px-4">Winner</th>
                    <th className="py-2.5 px-4">Status</th>
                    <th className="py-2.5 px-4 text-right">Net Paid</th>
                    <th className="py-2.5 px-4 text-right">Voucher</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {db.bcPayouts.map((p) => {
                    const grp = db.bcGroups.find((g) => g.id === p.bcGroupId);
                    const win = db.members.find((m) => m.id === p.winnerMemberId);
                    return (
                      <tr key={p.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono-num font-medium">{p.voucherNumber}</td>
                        <td className="py-3 px-4 font-mono-num">{formatDateOnly(p.payoutDate)}</td>
                        <td className="py-3 px-4">{grp?.name ?? p.bcGroupId}</td>
                        <td className="py-3 px-4 font-medium">{win?.name ?? p.winnerMemberId}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`font-semibold ${
                              p.paymentStatus === 'Paid' ? 'text-emerald-700' : 'text-amber-700'
                            }`}
                          >
                            {p.paymentStatus}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right font-mono-num font-semibold">
                          {formatINR(p.netPaidAmount)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => {
                              const found = db.receipts.find(
                                (r) => r.receiptNumber === p.voucherNumber
                              );
                              if (found) setActiveReceipt(found);
                            }}
                            className="inline-flex items-center gap-1 text-[#0070E0] font-semibold hover:underline"
                          >
                            <ReceiptText className="w-3.5 h-3.5" />
                            <span>View</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB: INDEPENDENT BC LEDGER */}
      {activeTab === 'ledger' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 bg-white border border-slate-200 rounded-2xl p-5">
            <div className="min-w-[260px]">
              <FieldLabel label="Select BC Group for Independent Ledger" />
              <select
                value={ledgerBcId}
                onChange={(e) => setLedgerBcId(e.target.value)}
                className={inputBaseClass}
              >
                {db.bcGroups.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name} ({g.id}) {g.isDeleted ? '· Deleted' : ''}
                  </option>
                ))}
              </select>
            </div>
            <button
              type="button"
              onClick={() =>
                exportToCSV(
                  `bc_ledger_${ledgerBcId}`,
                  ['Ref #', 'Date', 'Timestamp', 'Member', 'Description', 'Mode', 'Direction', 'Amount'],
                  selectedLedgerData.entries.map((e) => [
                    e.referenceNumber,
                    e.date,
                    formatDateTime(e.timestamp),
                    e.memberName ?? '',
                    e.description,
                    e.paymentMode,
                    e.direction,
                    e.amount,
                  ])
                )
              }
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export BC Ledger CSV</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-4">
              <p className="text-xs text-slate-500">BC Collection</p>
              <p className="text-lg font-bold text-emerald-700 font-mono-num mt-1">
                {formatINR(selectedLedgerData.totalCollection)}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-4">
              <p className="text-xs text-slate-500">BC Payouts</p>
              <p className="text-lg font-bold text-slate-900 font-mono-num mt-1">
                {formatINR(selectedLedgerData.totalPayout)}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-4">
              <p className="text-xs text-slate-500">BC Expenses</p>
              <p className="text-lg font-bold text-red-600 font-mono-num mt-1">
                {formatINR(selectedLedgerData.totalExpenses)}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-4">
              <p className="text-xs text-slate-500">Net BC Balance</p>
              <p className="text-lg font-bold text-[#002E6E] font-mono-num mt-1">
                {formatINR(selectedLedgerData.balance)}
              </p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                    <th className="py-2.5 px-4">Ref #</th>
                    <th className="py-2.5 px-4">Date &amp; Time</th>
                    <th className="py-2.5 px-4">Member / Item</th>
                    <th className="py-2.5 px-4">Description</th>
                    <th className="py-2.5 px-4">Mode</th>
                    <th className="py-2.5 px-4 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {selectedLedgerData.entries.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        No transactions recorded for this BC yet.
                      </td>
                    </tr>
                  ) : (
                    selectedLedgerData.entries.map((e) => (
                      <tr key={e.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono-num font-medium">{e.referenceNumber}</td>
                        <td className="py-3 px-4 font-mono-num">{formatDateTime(e.timestamp)}</td>
                        <td className="py-3 px-4 font-medium">{e.memberName ?? 'BC Group'}</td>
                        <td className="py-3 px-4 text-slate-600">{e.description}</td>
                        <td className="py-3 px-4">{e.paymentMode}</td>
                        <td
                          className={`py-3 px-4 text-right font-mono-num font-semibold ${
                            e.direction === 'credit' ? 'text-emerald-700' : 'text-red-600'
                          }`}
                        >
                          {e.direction === 'credit' ? '+' : '-'} {formatINR(e.amount)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
