import React from 'react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

export const FieldLabel: React.FC<{
  label: string;
  required?: boolean;
  hint?: string;
}> = ({ label, required, hint }) => (
  <div className="flex items-baseline justify-between gap-2 mb-1.5">
    <label className="text-xs font-medium text-slate-700">
      {label}
      {required && <span className="text-red-600 ml-0.5">*</span>}
    </label>
    {hint && <span className="text-[11px] text-slate-400">{hint}</span>}
  </div>
);

export const inputBaseClass =
  'w-full min-h-[44px] px-3.5 py-2 text-sm text-slate-900 bg-white border border-slate-200 rounded-xl transition-colors focus:outline-none focus:border-[#0070E0] focus:ring-2 focus:ring-[#0070E0]/15 disabled:bg-slate-50 disabled:text-slate-500';

export const monoInputClass = `${inputBaseClass} font-mono-num`;

export const FormAlert: React.FC<{
  type: 'error' | 'success';
  message: string;
  onDismiss?: () => void;
}> = ({ type, message, onDismiss }) => {
  const isError = type === 'error';
  return (
    <div
      role="alert"
      className={`flex items-start justify-between gap-3 px-4 py-3 rounded-xl border text-sm ${
        isError
          ? 'bg-red-50 border-red-200 text-red-800'
          : 'bg-emerald-50 border-emerald-200 text-emerald-800'
      }`}
    >
      <div className="flex items-start gap-2.5">
        {isError ? (
          <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-red-600" />
        ) : (
          <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0 text-emerald-600" />
        )}
        <span>{message}</span>
      </div>
      {onDismiss && (
        <button
          type="button"
          onClick={onDismiss}
          className="text-xs font-medium underline underline-offset-2 shrink-0 hover:opacity-75"
        >
          Dismiss
        </button>
      )}
    </div>
  );
};

export const SectionHeader: React.FC<{
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}> = ({ title, subtitle, actions }) => (
  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-200">
    <div>
      <h2 className="text-lg font-bold text-[#002E6E] font-display">{title}</h2>
      {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
    </div>
    {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
  </div>
);

export const EmptyState: React.FC<{
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}> = ({ title, description, actionLabel, onAction }) => (
  <div className="py-12 px-6 text-center bg-white border border-slate-200 rounded-2xl">
    <p className="text-sm font-semibold text-slate-900">{title}</p>
    <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">{description}</p>
    {actionLabel && onAction && (
      <button
        type="button"
        onClick={onAction}
        className="mt-4 px-5 py-2.5 text-xs font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl transition-colors whitespace-nowrap"
      >
        {actionLabel}
      </button>
    )}
  </div>
);
