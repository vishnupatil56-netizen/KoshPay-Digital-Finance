import React, { useState } from 'react';
import {
  LayoutDashboard,
  ArrowLeftRight,
  Layers,
  Gift,
  Users,
  CreditCard,
  Receipt,
  BookOpen,
  PieChart,
  Settings,
  Plus,
  Menu,
  X,
  Languages,
  Lock,
  Smartphone,
} from 'lucide-react';
import { FinanceProvider, useFinance } from './context/FinanceContext';
import { translations } from './i18n/translations';
import { DashboardView } from './components/DashboardView';
import { UniversalTransactionView } from './components/UniversalTransactionView';
import { BCManagementView } from './components/BCManagementView';
import { LuckyDrawView } from './components/LuckyDrawView';
import { MemberManagementView } from './components/MemberManagementView';
import { LoanManagementView } from './components/LoanManagementView';
import { ExpenseManagementView } from './components/ExpenseManagementView';
import { CashBankBookView } from './components/CashBankBookView';
import { ReportsBackupView } from './components/ReportsBackupView';
import { SettingsView } from './components/SettingsView';
import { ReceiptModal } from './components/ReceiptModal';
import { PinLockScreen } from './components/PinLockScreen';
import { OfflineIndicator, PWAInstallButton } from './components/PWAInstallButton';

type NavId =
  | 'home'
  | 'members'
  | 'payments'
  | 'bc'
  | 'luckydraw'
  | 'loans'
  | 'expenses'
  | 'cashbank'
  | 'reports'
  | 'settings';

const AppShell: React.FC = () => {
  const { db, lang, setLang, isLocked, lockApp } = useFinance();
  const t = translations[lang];
  const [activeNav, setActiveNav] = useState<NavId>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (isLocked) {
    return <PinLockScreen />;
  }

  const navItems: { id: NavId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'home', label: t.navHome, icon: LayoutDashboard },
    { id: 'payments', label: t.navPayments, icon: ArrowLeftRight },
    { id: 'bc', label: t.navBC, icon: Layers },
    { id: 'luckydraw', label: t.navLuckyDraw, icon: Gift },
    { id: 'loans', label: t.navLoans, icon: CreditCard },
    { id: 'members', label: t.navMembers, icon: Users },
    { id: 'expenses', label: t.navExpenses, icon: Receipt },
    { id: 'cashbank', label: t.navCashBank, icon: BookOpen },
    { id: 'reports', label: t.navReports, icon: PieChart },
    { id: 'settings', label: t.navSettings, icon: Settings },
  ];

  const bottomNavItems: { id: NavId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'home', label: t.navHome, icon: LayoutDashboard },
    { id: 'members', label: t.navMembers, icon: Users },
    { id: 'payments', label: t.navPayments, icon: ArrowLeftRight },
    { id: 'reports', label: t.navReports, icon: PieChart },
    { id: 'settings', label: t.navSettings, icon: Settings },
  ];

  const activeItem = navItems.find((n) => n.id === activeNav) ?? navItems[0];

  const handleSelectNav = (rawId: string) => {
    const mapped: NavId = rawId === 'universal' || rawId === 'dashboard'
      ? rawId === 'universal'
        ? 'payments'
        : 'home'
      : (rawId as NavId);
    setActiveNav(mapped);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen flex bg-[#F4F7FB] text-slate-900">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-white border-r border-slate-200 no-print">
        <div className="h-16 flex items-center justify-between px-5 bg-[#002E6E] text-white">
          <div className="min-w-0">
            <span className="text-base font-bold tracking-tight font-display block truncate">
              {t.brandName}
            </span>
            <span className="text-[11px] text-blue-200 block truncate">
              {db.settings.businessName}
            </span>
          </div>
          {db.settings.pinEnabled && (
            <button
              type="button"
              onClick={lockApp}
              title="Lock App"
              className="p-2 rounded-lg text-blue-100 hover:bg-white/10 hover:text-white transition-colors shrink-0"
              aria-label="Lock App"
            >
              <Lock className="w-4 h-4" />
            </button>
          )}
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto" aria-label="Primary Navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeNav === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectNav(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-xl transition-colors text-left whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-50 text-[#002E6E]'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-[#002E6E]'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#0070E0]' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200">
          <button
            type="button"
            onClick={() => setLang(lang === 'mr' ? 'en' : 'mr')}
            className="w-full flex items-center justify-between px-3 py-2.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-blue-50 border border-slate-200 rounded-xl transition-colors"
          >
            <span className="inline-flex items-center gap-2">
              <Languages className="w-3.5 h-3.5 text-[#0070E0]" />
              <span>{lang === 'mr' ? 'भाषा: मराठी' : 'Language: English'}</span>
            </span>
            <span className="text-[#0070E0] font-semibold">{t.languageToggle}</span>
          </button>
        </div>
      </aside>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex no-print">
          <div
            className="fixed inset-0 bg-slate-900/45"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-72 max-w-[82vw] bg-white h-full border-r border-slate-200 flex flex-col z-50">
            <div className="h-14 flex items-center justify-between px-4 bg-[#002E6E] text-white">
              <span className="text-base font-bold font-display truncate">{t.brandName}</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 text-blue-100 hover:text-white rounded-lg min-h-[44px] min-w-[44px] flex items-center justify-center"
                aria-label="Close navigation"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeNav === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectNav(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-3 text-sm font-medium rounded-xl transition-colors text-left min-h-[44px] ${
                      isActive
                        ? 'bg-blue-50 text-[#002E6E]'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#0070E0]' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-slate-200 space-y-2">
              {db.settings.pinEnabled && (
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    lockApp();
                  }}
                  className="w-full flex items-center justify-center gap-2 px-3 py-2.5 text-xs font-semibold text-[#002E6E] bg-blue-50 border border-blue-200 rounded-xl min-h-[44px]"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Lock App</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => setLang(lang === 'mr' ? 'en' : 'mr')}
                className="w-full flex items-center justify-between px-3 py-2.5 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-xl min-h-[44px]"
              >
                <span>{lang === 'mr' ? 'भाषा: मराठी' : 'Language: English'}</span>
                <span className="text-[#0070E0] font-semibold">{t.languageToggle}</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Shell */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="h-14 lg:h-16 sticky top-0 z-20 bg-white/95 backdrop-blur-xs border-b border-slate-200 px-4 lg:px-8 flex items-center justify-between gap-3 no-print">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 -ml-2 text-[#002E6E] hover:bg-blue-50 rounded-xl min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Open menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-xs sm:text-sm min-w-0">
              <span className="hidden sm:inline text-slate-400 whitespace-nowrap">{t.brandName}</span>
              <span className="hidden sm:inline text-slate-300">/</span>
              <span className="font-bold text-[#002E6E] truncate">{activeItem.label}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton variant="compact" />
            <button
              type="button"
              onClick={() => handleSelectNav('settings')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#002E6E] bg-slate-100 hover:bg-blue-50 rounded-xl transition-colors whitespace-nowrap min-h-[36px]"
              title="Download Android APK Project"
            >
              <Smartphone className="w-3.5 h-3.5 text-[#0070E0]" />
              <span>APK Project</span>
            </button>
            <button
              type="button"
              onClick={() => setLang(lang === 'mr' ? 'en' : 'mr')}
              className="lg:hidden px-2.5 py-1.5 text-xs font-semibold text-[#0070E0] bg-blue-50 rounded-lg min-h-[36px]"
            >
              {t.languageToggle}
            </button>
            <button
              type="button"
              onClick={() => handleSelectNav('payments')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#0070E0] hover:bg-[#005BB8] rounded-xl transition-colors whitespace-nowrap min-h-[40px]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t.quickEntry}</span>
            </button>
          </div>
        </header>

        {/* Active Module Viewport */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-5 pb-20 lg:pb-10 max-w-7xl w-full mx-auto">
          {activeNav === 'home' && (
            <DashboardView onNavigate={(tab) => handleSelectNav(tab)} />
          )}
          {activeNav === 'payments' && <UniversalTransactionView />}
          {activeNav === 'bc' && <BCManagementView />}
          {activeNav === 'luckydraw' && <LuckyDrawView />}
          {activeNav === 'loans' && <LoanManagementView />}
          {activeNav === 'members' && <MemberManagementView />}
          {activeNav === 'expenses' && <ExpenseManagementView />}
          {activeNav === 'cashbank' && <CashBankBookView />}
          {activeNav === 'reports' && <ReportsBackupView />}
          {activeNav === 'settings' && <SettingsView />}
        </main>

        {/* Mobile Bottom Navigation (5 primary tabs: Home, Members, Payments, Reports, Settings) */}
        <nav
          className="lg:hidden fixed bottom-0 inset-x-0 z-20 h-14 bg-white border-t border-slate-200 grid grid-cols-5 no-print"
          aria-label="Mobile Quick Navigation"
        >
          {bottomNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeNav === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectNav(item.id)}
                className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-semibold transition-colors min-h-[44px] ${
                  isActive ? 'text-[#0070E0]' : 'text-slate-500'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="truncate max-w-[68px]">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Printable Receipt / Voucher Modal */}
      <ReceiptModal />
      <OfflineIndicator />
    </div>
  );
};

export default function App() {
  return (
    <FinanceProvider>
      <AppShell />
    </FinanceProvider>
  );
}
