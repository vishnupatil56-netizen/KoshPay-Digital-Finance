package com.koshpay.finance;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
